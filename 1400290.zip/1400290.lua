-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(1400290) -- Hanako | 花子さん

-- MAIN APP DEPOTS
addappid(1400291, 1, "87b1d0bcdabbdbfea7f6a931dcf993a2efb8f23424c241d307d5e165d0a68fee") -- Hanako | 花子さん Content
setManifestid(1400291, "1173830559995254616", 0)
