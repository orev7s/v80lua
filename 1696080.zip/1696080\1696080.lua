addappid(1696080)
addappid(1696081,0,"7480f6af448e9a51461e9df5ce7c156f803a1c556ec1150ccab4859f3e2ecd9f")
setManifestid(1696081,"7776489115464512231")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]