-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(3159330) -- Assassin's Creed Shadows

-- MAIN APP DEPOTS
addappid(3159331, 1, "a1a2865a35a1aa7255e0d1a8d6cedab23f2b34346e4a359a283f1a5ceb826ddf") -- Depot 3159331
setManifestid(3159331, "2627174286402456816", 0)
addappid(3159333, 1, "24bbf4e14d616c7df7c56696e444569bcf5689554a6a79f731426e4fac7d66ea") -- Depot 3159333
setManifestid(3159333, "2890497842286120105", 0)
addappid(3159334, 1, "919bdf5d6752a3dfc2cf5f76c6800e25059aeab0489c2ec656e1bb938fef0f13") -- Depot 3159334
setManifestid(3159334, "4089506801826452583", 0)
addappid(3159335, 1, "843ebde3282fd10fe2204126d7be3c471c849e01618fd2419fd56be6a2e4fc72") -- Depot 3159335
setManifestid(3159335, "7433144042915746485", 0)
addappid(3159336, 1, "10867627410a4ed3756f1263fe75741717e2c6f7797ff9af89cd7c5749a14f2b") -- Depot 3159336
setManifestid(3159336, "1120211533521827360", 0)
addappid(3159337, 1, "e4e59c05f264ffc35d4c0629f2f887bee3dc7848b240411d65a8f2e2d793843b") -- Depot 3159337
setManifestid(3159337, "8152455803407100798", 0)

-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "550968249685141759", 0)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
setManifestid(1716751, "818295193716041715", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3159340) -- Assassins Creed Shadows - Ubisoft Activation
addappid(3362520) -- Assassins Creed Shadows - Standard Edition - JP (Ubisoft Activation)
addappid(3362530) -- Assassins Creed Shadows - Digital Deluxe Edition - WW (Ubisoft Activation)
addappid(3362540) -- Assassins Creed Shadows - Digital Deluxe Edition - JP (Ubisoft Activation)
addappid(3362570) -- Assassins Creed Shadows - Premium Starter Pack
addappid(3362580) -- Assassins Creed Shadows - Premium Starter Pack (Ubisoft Activation)
addappid(3362610) -- Assassins Creed Shadows - Standard Edition - WW Prepurchase - Ubisoft Activation
addappid(3362620) -- Assassins Creed Shadows - Digital Deluxe Edition - WW  Prepurchase - Ubisoft Activation
addappid(3362630) -- Assassins Creed Shadows - Standard Edition - JP Prepurchase - Ubisoft Activation
addappid(3362640) -- Assassins Creed Shadows - Digital Deluxe Edition - JP Prepurchase - Ubisoft Activation
