-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(3159330)
addappid(3159331,0,"a1a2865a35a1aa7255e0d1a8d6cedab23f2b34346e4a359a283f1a5ceb826ddf")
setManifestid(3159331,"8425171215530266379")
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
setManifestid(1716751,"818295193716041715")
addappid(3159332)
addappid(3159333,0,"24bbf4e14d616c7df7c56696e444569bcf5689554a6a79f731426e4fac7d66ea")
setManifestid(3159333,"3184875874046556946")
addappid(3159334,0,"919bdf5d6752a3dfc2cf5f76c6800e25059aeab0489c2ec656e1bb938fef0f13")
setManifestid(3159334,"5068826368210157238")
addappid(3159335,0,"843ebde3282fd10fe2204126d7be3c471c849e01618fd2419fd56be6a2e4fc72")
setManifestid(3159335,"3306157129468657009")
addappid(3159336,0,"10867627410a4ed3756f1263fe75741717e2c6f7797ff9af89cd7c5749a14f2b")
setManifestid(3159336,"1119663958392831094")
addappid(3159337,0,"e4e59c05f264ffc35d4c0629f2f887bee3dc7848b240411d65a8f2e2d793843b")
setManifestid(3159337,"1767432884557737661")
addappid(3159338)