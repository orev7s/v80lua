-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(2736490) -- Mob Control

-- MAIN APP DEPOTS
addappid(2736491, 1, "30a4d19cc3183ed51e5ff97631295c53d8a9eeb2182783de84a524452c6f08fd") -- Main Game Content (Windows Content)
setManifestid(2736491, "2192696339611369098", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Mob Control Champions (AppID: 2749200)
addappid(2749200)
addappid(2749200, 1, "ccd397efb50dca9d2ff453bc1e70bded2452c80d68d2b401f7db289dc30dfb97") -- Mob Control Champions - Main Content
setManifestid(2749200, "3540122743920681730", 0)

-- Mob Control Triple Backup (AppID: 2749210)
addappid(2749210)
addappid(2749210, 1, "23ef1d80879386b4a9063d2d9773aac5476efa5a7507fd27456032de03fa4fee") -- Mob Control Triple Backup - Main Content
setManifestid(2749210, "5996949689521910977", 0)
