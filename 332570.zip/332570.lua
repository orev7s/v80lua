-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(332570) -- Amazing Frog?

-- MAIN APP DEPOTS
addappid(332571, 1, "914497bf7253dae27e380c140c5f34a17a7b0be144e186b299df16cd38673402") -- Amazing Frog? Content
setManifestid(332571, "3992388060818286377", 0)
addappid(332572, 1, "ef05975e6a5e7e1b2319bc118cb199d4a6beb3c20979157e6eb3cc65c8ff93a0") -- Amazing Frog? Depot windows
setManifestid(332572, "4939773282211970225", 0)
addappid(332573, 1, "46e402f3b495e25ea0e9f1be5ee4689c0f97c9d3536cc697784118cb89109a6a") -- Amazing Frog? Depot osx
setManifestid(332573, "6692749551789274955", 0)
addappid(332574, 1, "8e6d00dbdfa286c81765c135bb5da8054e182ad8f5e56f2d8765ad785bc0cfa3") -- Amazing Frog? Depot Linux
setManifestid(332574, "4065819225728495654", 0)
addappid(332575, 1, "3b209ff0cb6e0bf31debc839a99e15c5e101f97f398c9076f0445202db777b01") -- Amazing Frog? Depot Windows 32 bit
setManifestid(332575, "3118825949492263093", 0)
