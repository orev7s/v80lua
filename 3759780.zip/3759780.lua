-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(3759780)
addappid(3759781,0,"3b59647da6155ef294ae11572d6c9680b213d6e5b0f3326de5d66445f09b7a3f")
setManifestid(3759781,"8813446765004088463")
addappid(3759783,0,"e28d8d4bfd89dd09c1f909c90b5a53563e05b9fecbca5a087d8d479065a7ecb5")
setManifestid(3759783,"6773537137555404850")