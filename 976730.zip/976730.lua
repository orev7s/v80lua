-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪username - f1uxin, on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy / https://discord.gg/m8PxjTwrnv
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(976730) -- Halo: The Master Chief Collection

-- MAIN APP DEPOTS
addappid(976731, 1, "e877debc3a91a6d843e9828dbb89dd67611541ea3794963e24bf0ee96ba550d9") -- MCC - Base Depot
setManifestid(976731, "5290165787340864952", 0)

-- SHARED DEPOTS (from other apps)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- .NET 4.6 Redist (Shared from App 228980)
setManifestid(229005, "7992454656023763365", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Halo Reach (AppID: 1064220)
addappid(1064220)
addappid(1064225, 1, "90afd6a2b72722120fd9096bac881d25d598fb19bbe3787bf7ca715336ece14b") -- Halo Reach - MCC - Reach: Campaign Depot
setManifestid(1064225, "5405451961243857828", 0)

-- Halo Combat Evolved Anniversary (AppID: 1064221)
addappid(1064221)
addappid(976733, 1, "6be42af36216470c4dd76f02aa8dcbb7fb616bc1ea81121e94e11bc4980abf55") -- Halo Combat Evolved Anniversary - MCC - H1: Campaign Depot
setManifestid(976733, "3707800111240260880", 0)

-- Halo 2 Anniversary (AppID: 1064270)
addappid(1064270)
addappid(976735, 1, "c6639bef3cdcf9bf27644c31d10c4735c28a17bc7ca32a52ddd10f189dc70c75") -- Halo 2 Anniversary - MCC - H2: Campaign Depot
setManifestid(976735, "5039352284328524592", 0)

-- Halo 3 (AppID: 1064271)
addappid(1064271)
addappid(976738, 1, "b01b615b4689becd286be89f3b324b9a6537cd21c352c4d922abf59d0e0ba241") -- Halo 3 - MCC - H3: Campaign Depot
setManifestid(976738, "416966153344393370", 0)

-- Halo 3 ODST (AppID: 1064272)
addappid(1064272)
addappid(1064222, 1, "fe97b6cd8f90c44e0944c52eb85a2b77dc24b87e7d0b472d4e3047e7e4ecc22e") -- Halo 3 ODST - MCC - ODST: Campaign Depot
setManifestid(1064222, "7005256099688173306", 0)

-- Halo 4 (AppID: 1064273)
addappid(1064273)
addappid(1064223, 1, "468a5cc3d2fe62537017351460d269ee33cd6f06b4cf8d62bd1ddc83dd758610") -- Halo 4 - MCC - H4: Campaign Depot
setManifestid(1064223, "5087052781705646847", 0)

-- MCC - H1 Multiplayer (AppID: 1080080)
addappid(1080080)
addtoken(1080080, "16757144231569661271")
addappid(976734, 1, "c912351548ff554431c1dda0ce05515bdb2251fe6fdf30dbfb70fb6f85dbf2ad") -- MCC - H1 Multiplayer - MCC - H1: Multiplayer Depot
setManifestid(976734, "2629009254710728848", 0)

-- MCC - H4 Multiplayer (AppID: 1097220)
addappid(1097220)
addappid(1064224, 1, "e6880c811ede7146b056ae9a93ea9da2fd5f25e0eecbdec0c503ab407486e97a") -- MCC - H4 Multiplayer - MCC - H4: Multiplayer Depot
setManifestid(1064224, "4730177311666266408", 0)

-- MCC - H3 Multiplayer (AppID: 1097222)
addappid(1097222)
addtoken(1097222, "2791348385504549869")
addappid(976739, 1, "fe5f4c78a180f1896e8d82f03ee942d48a2df63ba5ee39438f3c89b675c55926") -- MCC - H3 Multiplayer - MCC - H3: Multiplayer Depot
setManifestid(976739, "411871384308362488", 0)

-- MCC - H2 Multiplayer (AppID: 1097223)
addappid(1097223)
addappid(976736, 1, "17d2adb7c2c423be7b4326040b85c0a0261e3608bd0cd93f2a2f83aee9f73e78") -- MCC - H2 Multiplayer - MCC - H2: Multiplayer Depot
setManifestid(976736, "695922209183061679", 0)
addappid(976737, 1, "454193d47f594693dedcd4efc6dabf1330834e1e7f9bd2476893fb22bdba8bd1") -- MCC - H2 Multiplayer - MCC - H2A: Multiplayer Depot
setManifestid(976737, "3483532909773741488", 0)

-- MCC - Reach (Content Pack 2) (AppID: 1097224)
addappid(1097224)
addtoken(1097224, "11572389741647076")
addappid(1064226, 1, "29b66b00377f450613be6976878fd65f1ad1690a447955a9193209aefa8b79f1") -- MCC - Reach (Content Pack 2) - MCC - Reach: Multiplayer Depot
setManifestid(1064226, "7799837789059377967", 0)

-- MCC - H1 Extended Language Pack (AppID: 1108760)
addappid(1108760)
addappid(1064228, 1, "db8da685c10ff2529ce5c1463257efe2bfa7c696659c61a79cfa681dfdebc412") -- MCC - H1 Extended Language Pack - MCC - H1: Extended Language Pack
setManifestid(1064228, "6740673267375754218", 0)

-- MCC - H2 Extended Language Pack (AppID: 1108761)
addappid(1108761)
addappid(1064229, 1, "048f45b36d0322ff371ef021c2b129fd5978efcb30069bc5c5c837755735cbf2") -- MCC - H2 Extended Language Pack - MCC - H2: Extended Language Pack
setManifestid(1064229, "4496935266254945644", 0)

-- MCC - H3 Extended Language Pack (AppID: 1108762)
addappid(1108762)
addtoken(1108762, "16279060983445300922")
addappid(1064274, 1, "988e24b4710ed5e80835a2d5247657503c2763a0d68639c5d15fdee0272eb71d") -- MCC - H3 Extended Language Pack - MCC - H3 Extended Language Depot
setManifestid(1064274, "1012731833906676734", 0)

-- MCC - ODST Extended Language Pack (AppID: 1108763)
addappid(1108763)
addappid(1064275, 1, "39eb442343708c7c58460969f157d25779630c6cf0997712e2a1840b8436651d") -- MCC - ODST Extended Language Pack - MCC - ODST Extended Language Pack
setManifestid(1064275, "7410615082723943400", 0)

-- MCC - H4 Extended Language Pack (AppID: 1109620)
addappid(1109620)
addappid(1064276, 1, "63fd98d1855f6f4df7af9606096267823059a5c0102e1c68b5c1897757781de5") -- MCC - H4 Extended Language Pack - MCC - H4 Extended Language Pack
setManifestid(1064276, "8919231023149142163", 0)

-- MCC - Reach Extended Language Pack (AppID: 1109621)
addappid(1109621)
addtoken(1109621, "12870953071227487373")
addappid(1064227, 1, "b6a746262310138d6b402da8bda7e51ae43500dc08a97c44a832d6fb61c3d832") -- MCC - Reach Extended Language Pack - MCC - Reach: Extended Language Pack
setManifestid(1064227, "2902300282061187148", 0)
