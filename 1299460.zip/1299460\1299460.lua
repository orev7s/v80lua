addappid(1299460)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1299461,0,"d17456022f048ed4e2819c267b7442a6fc81b5a8b031710e23d704f284d251b3")
setManifestid(1299461,"3606109380897154204")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]