-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(873840) -- Truck and Logistics Simulator

-- MAIN APP DEPOTS
addappid(873841, 1, "30b2c3f522af72ce2cd442603a860f70c745e193edd37f4fc12c502862dd162e") -- Ausliefern macht Spaß Content
setManifestid(873841, "82000782646201457", 0)
