-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(823500) -- BONEWORKS

-- MAIN APP DEPOTS
addappid(823501, 1, "bd62786d436b7bc794ccc6f50cdcfc4c47c11029fbbc4751de27d12fb8fe8622") -- BONEWORKS Content
setManifestid(823501, "5927460188866243002", 0)

-- DLCS WITH DEDICATED DEPOTS
-- BONETONES - Official BONEWORKS OST (AppID: 1162380)
addappid(1162380)
addappid(1162380, 1, "35ec85be012d69a14fb151b5e2a418fc1c6d06ee4a4aba6e39e43b3291dd42d7") -- BONETONES - Official BONEWORKS OST - BONETONES - Official BONEWORKS OST (1162380) Depot
setManifestid(1162380, "8903954427738922260", 0)
