-- Made by f1uxin, please read the read me TXT file
-- MAIN APPLICATION
addappid(25890) -- Hearts of Iron III

-- MAIN APP DEPOTS
addappid(25961, 1, "70a7861fa88ffc8ca83f448780167088be2a9686adfd59ce6d6dd35e27ab7553") -- hearts of iron 3 mac content
setManifestid(25961, "6424689831017791129", 0)
addappid(25891, 1, "cdaccbe87d7e725792a06fd3a996d6274589cd98ef5190c7c08e36417d9da56d") -- hearts_of_iron_3_content
setManifestid(25891, "2513892506803504902", 0)
addappid(25894, 1, "3f06734e688805b93f440e09a8ab562651e351cd5644d04d7d5f91790f33b2d3") -- Hearts of Iron III French
setManifestid(25894, "4623794100236350182", 0)
addappid(25895, 1, "7084940055e2221ef1faea058f928e6cded5b0f695f40932d22858ccb3f57c17") -- Hearts of Iron III German
setManifestid(25895, "4545359711172689196", 0)

-- SHARED DEPOTS (from other apps)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- VC 2005 Redist (Shared from App 228980)
setManifestid(228981, "7613356809904826842", 0)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Hearts of Iron III US Sprite Pack (AppID: 25892)
addappid(25892)
addappid(25892, 1, "6af189844daf1633bbf17fc4ca9a3a61ae8a14776187131d0a8679d6724adda1") -- Hearts of Iron III US Sprite Pack - US Sprite Pack
setManifestid(25892, "50406710641847165", 0)

-- Hearts of Iron III German Sprite Pack (AppID: 25893)
addappid(25893)
addappid(25893, 1, "1417da64fede722f069b6a04b2f82eb5cd7323662354e5342cda2bf55c44511f") -- Hearts of Iron III German Sprite Pack - German Sprite Pack
setManifestid(25893, "4705755598926764945", 0)

-- Hearts of Iron III German Infantry Sprite Pack (AppID: 25896)
addappid(25896)
addappid(25896, 1, "6a0034df1259c06825061ea513f32af277f9d7e8e3d2cbd5232294c8a8f2f896") -- Hearts of Iron III German Infantry Sprite Pack - German Infantry Sprite Pack
setManifestid(25896, "7565397338628807783", 0)

-- Hearts of Iron III Japanese Infantry Sprite Pack (AppID: 25897)
addappid(25897)
addappid(25897, 1, "352a155bce48b5e2e4cab25274a24ff94c4fe016070a417fc9958954774897b0") -- Hearts of Iron III Japanese Infantry Sprite Pack - Japanese Infantry Sprite Pack
setManifestid(25897, "7773909633232931608", 0)

-- Hearts of Iron III Soviet Sprite Pack (AppID: 25898)
addappid(25898)
addappid(25898, 1, "a7a6a42870b980720e151096227201c2f5d1a0abe66c111bfc8e0d3fad5c6d14") -- Hearts of Iron III Soviet Sprite Pack - Soviet Sprite Pack
setManifestid(25898, "2547594168573985372", 0)

-- Hearts of Iron 3 Soviet Music Pack (AppID: 25899)
addappid(25899)
addappid(25899, 1, "c6d3ebafe6614c4c1e41a1f501e1ece750290ee927d0063a012efd4c76e6ea65") -- Hearts of Iron 3 Soviet Music Pack - Soviet Music Pack
setManifestid(25899, "7512165040282614865", 0)

-- Hearts of Iron III Soviet Infantry Spritepack (AppID: 25960)
addappid(25960)
addappid(25960, 1, "85a2c4fb4ef70b520b7509a78f9c2f0f12cf5bfa2ff5d79546639f3f0ee69017") -- Hearts of Iron III Soviet Infantry Spritepack - hearts_of_iron_3_soviet_infantry_pack
setManifestid(25960, "5551487700470795045", 0)

-- Hearts of Iron III German II Sprite Pack (AppID: 25962)
addappid(25962)
addappid(25962, 1, "124e2c4fcce592f9e1735bdc22a884bbc0e34c23cfe0671cd15384e42cb6999d") -- Hearts of Iron III German II Sprite Pack - German II Sprite Pack
setManifestid(25962, "8527507761012169230", 0)

-- Hearts of Iron III Semper Fi Expansion (AppID: 42900)
addappid(42900)
addappid(42900, 1, "4ee92618aa09d0df1ff03ec58d6c5de7c75947aacb563050efc1c27c51a8cdb6") -- Hearts of Iron III Semper Fi Expansion - Semper Fi Expansion
setManifestid(42900, "1855835899462633469", 0)

-- Hearts of Iron III Semper Fi Secret Weapons of WWII DLC (AppID: 42901)
addappid(42901)
addappid(42901, 1, "311b56025117c376222b13b0f5425f4aba74268f89f9997c5c62a7501a817bc6") -- Hearts of Iron III Semper Fi Secret Weapons of WWII DLC - Semper Fi Secret Weapons of WWII DLC
setManifestid(42901, "1255865836393834372", 0)

-- Hearts of Iron III Semper Fi Dies Irae Gotterdammerung (AppID: 42902)
addappid(42902)
addappid(42902, 1, "1de38982535bd81734642c6070c9030024dce5abebceda0f3d3a3ee0182f3257") -- Hearts of Iron III Semper Fi Dies Irae Gotterdammerung - Hearts of Iron III Semper Fi: Dies Irae Gotterdammerung
setManifestid(42902, "5426754798465974894", 0)

-- Hearts of Iron III For the Motherland (AppID: 42903)
addappid(42903)
addappid(42903, 1, "e8db585d12413c01d5be30477e88a5d4777a85319fd5b4abeae5649dc6a8b779") -- Hearts of Iron III For the Motherland - Hearts of Iron III: For the Motherland
setManifestid(42903, "6430736121255200418", 0)

-- Hearts of Iron III Mega German Sprite Pack (AppID: 42904)
addappid(42904)
addappid(42904, 1, "028475a5d48eab5539ef8c1a44a7e3073640b92837a09127c61e279de722c42a") -- Hearts of Iron III Mega German Sprite Pack - Mega German Sprite Pack
setManifestid(42904, "7509533740653211543", 0)

-- Hearts of Iron III Stars and Stripes (AppID: 42905)
addappid(42905)
addappid(42905, 1, "ecfb3e96d427ebbbe63fc27f79b81deaed5ecba856a65e44289a7e4a416db935") -- Hearts of Iron III Stars and Stripes - Hearts of Iron III - Stars and Stripes
setManifestid(42905, "5474615522294339540", 0)

-- Hearts of Iron III US Infantry Sprite Pack (AppID: 214980)
addappid(214980)
addappid(214980, 1, "73bc1f8d7b867e5924aa9995769feaff938af366f0757b517c4aa92b29b6adb7") -- Hearts of Iron III US Infantry Sprite Pack - US Infantry Unit Pack
setManifestid(214980, "3706615496181770735", 0)

-- Hearts of Iron III Sounds of Conflict (AppID: 214981)
addappid(214981)
addappid(214981, 1, "1a41659084cad00c2ca1d47cdcfb0c0790cffa207a31809bda5b4fb31e69efff") -- Hearts of Iron III Sounds of Conflict - Allies of the West
setManifestid(214981, "664090848878810105", 0)

-- Hearts of Iron 3 DLC 3 (AppID: 214982)
addappid(214982)
addappid(214982, 1, "14a3d0fca42f13c7f156a54ecf16047683af5c74e9c03277bd587d1ea35291f4") -- Hearts of Iron 3 DLC 3 - Changing Fronts
setManifestid(214982, "5372283731607045757", 0)

-- Peace in Our Time (AppID: 214983)
addappid(214983)
addappid(214983, 1, "5c592a7fca0642ef541cdeb5ca96433d69102e7e72c5f0e4f515799fd98396b3") -- Peace in Our Time - Peace in Our Time
setManifestid(214983, "6896356259100596822", 0)

-- Hearts of Iron 3 DLC 4 (AppID: 214984)
addappid(214984)
addappid(214984, 1, "ddd3c63a99c4e28642a51349dde60548a0b8b317aff71642f1a9ad4838fe0df0") -- Hearts of Iron 3 DLC 4 - The Good Fight
setManifestid(214984, "3396567794791945067", 0)

-- Hearts of Iron 3 DLC 6 (AppID: 214985)
addappid(214985)
addappid(214985, 1, "b844ba4ae808be0f056e73c1c31b4e05f89d3f31b6bf759f389ff0f403e28adf") -- Hearts of Iron 3 DLC 6 - War to the End
setManifestid(214985, "3007769912101639399", 0)

-- Hearts of Iron III Their Finest Hour (AppID: 214986)
addappid(214986)
addappid(214986, 1, "c098725d786b3b6615f8978e40d9a7135b9d24aa04406c4c89af2bb62c331e67") -- Hearts of Iron III Their Finest Hour - Hearts of Iron III: Their Finest Hour
setManifestid(214986, "828655048627823019", 0)

-- Hearts of Iron III British Vehicle Pack (AppID: 214987)
addappid(214987)
addappid(214987, 1, "ccaf8671374fe4e23d4ed7242bb00f31bf780d495c019a43730f78bf6ac305f4") -- Hearts of Iron III British Vehicle Pack - British Vehicles Unit Pack
setManifestid(214987, "4623528516467753912", 0)

-- Hearts of Iron III Japanese Vehicle Pack (AppID: 214988)
addappid(214988)
addappid(214988, 1, "f334305eced01a14deb6121cebd1cde34841608ac76e6610417358eeaffd23e5") -- Hearts of Iron III Japanese Vehicle Pack - Japan Vehicles Unit Pack
setManifestid(214988, "3530110353496810585", 0)

-- Hearts of Iron III Italian Vehicle Pack (AppID: 214990)
addappid(214990)
addappid(214990, 1, "b512a41bc78190779426fd4115f1effe3e661399ca33e1860ba5ecf1fcf26b5b") -- Hearts of Iron III Italian Vehicle Pack - Italian Vehicles Unit Pack
setManifestid(214990, "3037174550594464475", 0)

-- Hearts of Iron III Axis Minors Vehicle Pack (AppID: 214991)
addappid(214991)
addappid(214991, 1, "f042dc7a0fab931d7615fcc04b899985914d44fe1c4ead320160947a33b82fc8") -- Hearts of Iron III Axis Minors Vehicle Pack - Axis Minors Vehicle Unit Pack
setManifestid(214991, "7029755342251150540", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(25970) -- ValveTestApp25970
addappid(214989) -- Hearts of Iron 3 DLC 10
