addappid(1347030)
addappid(1347031,0,"8ca7cbdedf485930a4e80a0ca31e08ba2e509a06df72baf8efa20d8b266668d6")
setManifestid(1347031,"1345534326872594532")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]