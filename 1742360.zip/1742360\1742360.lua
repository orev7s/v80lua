addappid(1742360)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1742361,0,"29986ba78fc92bb73f5c899c4684f29e9f221bed3c75ef5154accd4f442d5afb")
setManifestid(1742361,"373875860533333718")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]