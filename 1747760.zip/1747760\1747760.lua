addappid(1747760)
addappid(1747761,0,"b4e8d739f24007acda65e481ee1fba73d4e6b00f695ae8f352b686041b016432")
setManifestid(1747761,"7011437170973657941")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]