-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(2669380, 1, "0bdf4d33c3597d7c40fc6bf747755c888d9ec2167aec2dac298b0766e49f03ab") -- BRUTALISTICK VR

-- MAIN APP DEPOTS
addappid(2669381, 1, "090e1bcded479bdd950b9884d5966cfa9ee95438a9857d823c3d288f80a7ac70") -- Depot 2669381
setManifestid(2669381, "4953974861575988672", 0)
