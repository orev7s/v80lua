-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(2368930) -- ISLANDERS: New Shores

-- MAIN APP DEPOTS
addappid(2368931, 1, "924f9db27c7400a1185ba793bbd54719c53dd4c3e1e55aaeb340ab7a34bfd73f") -- Depot 2368931
setManifestid(2368931, "8653319417832538342", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3508640) -- Filters DLC

-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- ISLANDERS New Shores Soundtrack (AppID: 3478830) - missing depot keys
-- addappid(3478830)
