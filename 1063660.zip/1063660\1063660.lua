addappid(1063660)
addappid(1063661,0,"8a02dd866fcac446855a005dfc59832198ac2fb120e81c22295e9cbdd47443f5")
setManifestid(1063661,"7582027202212706040")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]