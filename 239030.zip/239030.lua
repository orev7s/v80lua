-- Made by f1uxin, please read the read me TXT file.
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(239030) -- Papers, Please

-- MAIN APP DEPOTS
addappid(239031, 1, "0d3295b4cb4eb5ac0f3bc40478fb875d708b49b80617988ba1751e471bf46253") -- Papers, Please Windows
setManifestid(239031, "6905656874083880948", 0)
addappid(239032, 1, "43355768d8e7be51631d0390e4d71e6ac233bd7e2803b10fc2e5c93cae960a88") -- Papers, Please OSX
setManifestid(239032, "6188834483198805795", 0)
addappid(239033, 1, "069690842a264d22828b8465895a14b83467482ab765dfcdcb9da6dd25e292b6") -- Papers, Please Linux
setManifestid(239033, "7577473921595950709", 0)
