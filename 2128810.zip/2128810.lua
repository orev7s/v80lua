-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(2128810) -- Dinosaurs Dominion

-- MAIN APP DEPOTS
addappid(2128811, 1, "418c23c4c5d815840cdd37a33a9e1b2baa611c0f6f1bc65684aea2ef49802b19") -- Depot 2128811
setManifestid(2128811, "6542500421523301057", 0)
