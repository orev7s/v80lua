-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(962400) -- Granny

-- MAIN APP DEPOTS
addappid(962401, 1, "62b8ae3bb8c880952382aaaeeeac3d2f87bc304a2e24d0a07709ab9124f6548d") -- Granny Content
setManifestid(962401, "4116798528376785568", 0)
