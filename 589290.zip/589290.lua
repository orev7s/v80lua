-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(589290, 1, "58a30bb608730ed424304e2b8ded677da7ae400499e692e37118d61fadbd6e4a") -- Holdfast: Nations At War

-- MAIN APP DEPOTS
addappid(589291, 1, "a7c1417721600265bba5c83ede099119af0a65f1e2f3b341cc26c5cc7987b7b3") -- Holdfast: Nations At War Content
setManifestid(589291, "8431713055018134867", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Holdfast Nations At War - Loyalist Edition Upgrade (AppID: 1243770)
addappid(1243770)
addappid(1243771, 1, "889f1fb0c89f83e6b5940bd922810c574affb5f838d6cd81d85a1f3fcf6b25cb") -- Holdfast Nations At War - Loyalist Edition Upgrade - Holdfast: Nations At War - Loyalist Edition Upgrade Depot
setManifestid(1243771, "992992171677795901", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1324000) -- Holdfast Nations At War - Regiments of the Line
addappid(1415510) -- Holdfast Nations At War - High Command
addappid(1489800) -- Holdfast Nations At War - Regiments of the Guard
addappid(1906770) -- Holdfast Frontlines WW1
addappid(1906771) -- Holdfast Frontlines WW1 - American Forces
addappid(1960210) -- Holdfast Frontlines WW1 - Ottoman Forces
addappid(1960220) -- Holdfast Frontlines WW1 - Australian Forces
addappid(2107250) -- Holdfast Nations At War - Grenadier Regiments
addappid(2692480) -- Holdfast Nations At War - Napoleons Rise
addappid(3320400) -- Holdfast Nations At War - Blackpowder Firearms

-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Holdfast OST - The Plight of War (AppID: 2692500) - missing depot keys
-- addappid(2692500)
