-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2075070)
setManifestid(229006,"1784011429307107530")
addappid(2075071,0,"add3aec9cb7617a6460aaafda50ed1df8a1529fe3b88cd858796ace96aaefce6")
setManifestid(2075071,"1248367819829409595")
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416")