-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(1817800, 1, "5b713a6995db88c78277eda45ff02db74276d6f0eb4b594e939217a23970a6e3") -- Oddsparks: An Automation Adventure
-- MAIN APP DEPOTS
addappid(1817801, 1, "b59ebe145d953e10adb462fd930cbf0da37483e64c0896babf1861638f87b6a5") -- Depot 1817801
setManifestid(1817801, "8285197237956512603", 6308727509)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
setManifestid(229007, "4477590687906973371", 117381405)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3073500) -- Oddsparks An Automation Adventure - Deluxe Upgrade
addappid(3678620) -- Oddsparks - Tailors Animal Costumes Pack
addappid(3678640) -- Oddsparks An Automation Adventure - Making Music