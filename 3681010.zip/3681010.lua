-- 3681010's Lua and Manifest Created by Morrenus
-- Nioh 3
-- Created: February 13, 2026 at 06:38:06 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 10
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(3681010, 1, "accea0016c6c5df7d031a08df7a460e90673b8da5c7cfb57432bb7e962893897") -- Nioh 3
-- MAIN APP DEPOTS
addappid(3681011, 1, "1c16eb875f0bd40521cc0ddb2ff4eb5772f0b1976252122abc5f9a09ddaaf995") -- Depot 3681011
setManifestid(3681011, "8739291190166375876", 121881659140)
addappid(3681013, 1, "b97a4048032dc27c3cf1c6887e6069b0f0d51da2c352c671278b00eb4423de35") -- Depot 3681013
setManifestid(3681013, "3120992644566989993", 319584)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4003880) -- Nioh 3 - Hellfire Equipment Set (Hellfire Warrior Armor set  Hellfire Ninja Attire set)
addappid(4003890) -- Nioh 3 - Scampuss Furball Netsuke Charm
addappid(4003900) -- Nioh 3 - Hellfrost Equipment Set (Hellfrost Warrior Armor set  Hellfrost Ninja Attire set)
addappid(4003910) -- Nioh 3 - Infernal Weapons Set
addappid(4003920) -- Nioh 3 - Kodama Netsuke Charm
addappid(4003930) -- Nioh 3 Season Pass
addappid(4003940) -- Nioh 3 - Chijiko Netsuke Charm
addappid(4232000) -- Nioh 3 - Kusanagi Netsuke Charm
addappid(4232020) -- Nioh 3 - Youngblood Armor
addappid(4232030) -- Nioh 3 - Lone Wolfs Armor