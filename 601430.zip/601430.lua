-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(601430) -- The Evil Within 2

-- MAIN APP DEPOTS
addappid(601431, 1, "11ab2f6c4c169c9c448bdf0a31fcd33b6ca4f1d029ac4cc4c2f1c744aaafb3ef") -- Main Game Content
setManifestid(601431, "4218428381380554759", 0)
addappid(601432, 1, "0509a3fe26f284297c9723525f8afb61daee6e620f7ae3cea05fd8065a0a279c") -- DNU
setManifestid(601432, "1120099795141866630", 0)
addappid(601433, 1, "9f0bebc08c2393ed83f25f935fea2fd9203258e466cdefe758037c32c0b59038") -- DNU
setManifestid(601433, "4602555954584755041", 0)
addappid(601434, 1, "47e9bba75d7dc876877610ca2a1dbc2b2d17516d9624a63562766e379dfe358e") -- DNU
setManifestid(601434, "3636660755850054562", 0)
addappid(601435, 1, "74375919bb0af12c20c40995ac7208808e9a11db3712db8199ebe47b1cce1514") -- DNU
setManifestid(601435, "1445536761025249627", 0)
addappid(601436, 1, "a1ac4e01217fe84194abb9da3c0de37806d5a69ab40ac61405aa3604f9c07c4d") -- DNU
setManifestid(601436, "6512736077719469113", 0)
addappid(601437, 1, "70d4f399162d1ed8885189aeac944f4b45a95ffe2618c4ba07cb89aa8222e9e8") -- DNU
setManifestid(601437, "5641903423042399874", 0)
addappid(601438, 1, "07bbfb78175dc3409c0e4c4c6da0d274f2edf5c47d25b5aa5a3511bae5a25276") -- DNU
setManifestid(601438, "2993071823528953938", 0)
addappid(601439, 1, "97549c2fdeff3e4287b76045297c026e5e2e26e52fb2d4385c473656a3badc89") -- Patch content share with Demo
setManifestid(601439, "560434929887469", 0)
addappid(679711, 1, "b2e75333e96da8dafbd0a483c0dd7541747c81b181604b3e791b5558fe5ada21") -- patch exe
setManifestid(679711, "3345706604275720989", 0)
addappid(679712, 1, "36ae93ecd511e227f5c1b772de8eb7fd86bc182d2395c00943b06e98c516a8f3") -- patch contents
setManifestid(679712, "8503336973653239442", 0)

-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(679710) -- The Evil Within 2 The Last Chance Pack
