-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(738060) -- Freddy Fazbear's Pizzeria Simulator

-- MAIN APP DEPOTS
addappid(738061, 1, "51b7bc204a3706259c7bd67fe0d8d1108402ec4c747106dbf1927ebf9d507d47") -- Freddy Fazbear's Pizzeria Simulator Content
setManifestid(738061, "4218731758964588750", 0)
