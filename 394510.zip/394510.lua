-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(394510) -- HELLDIVERS™

-- MAIN APP DEPOTS
addappid(394511, 1, "9354a50886239c53583780315103fac2c9ca6d9e6c4b80ec921a1b49c653e51a") -- binaries x86
setManifestid(394511, "9144075105577600930", 0)
addappid(394513, 1, "1760bb243e446b5591684d821d4bfd318c8ba76d0af39f454786e7bfe01f3e9f") -- binaries x64
setManifestid(394513, "2709807232204005293", 0)
addappid(394512, 1, "1094ae83b6e8a79e54aa77393680801204d7ab74e4556a08b6ced06933afdb68") -- content
setManifestid(394512, "5350944372617472127", 0)

-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
addappid(229031, 1, "98d01f1eaa90ae08f978994e043bcbbf1f23fc72a325528ca7d722c827c0eb54") -- PhysX System Software 9.12.1031 (Shared from App 228980)
setManifestid(229031, "7746630274301172884", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(395230) -- HELLDIVERS - Ranger Pack
addappid(395231) -- HELLDIVERS - Commando Pack
addappid(395232) -- HELLDIVERS - Defender Pack
addappid(395233) -- HELLDIVERS - Support Pack
addappid(395234) -- HELLDIVERS - Pilot Pack
addappid(395235) -- HELLDIVERS - Demolitionist Pack
addappid(395236) -- HELLDIVERS - Hazard Ops Pack
addappid(395237) -- HELLDIVERS - Specialist Pack
addappid(395238) -- HELLDIVERS - Weapons Pack
addappid(395239) -- HELLDIVERS - Vehicles Pack
addappid(396170) -- HELLDIVERS - Entrenched Pack
addappid(396171) -- HELLDIVERS - Pistols Perk Pack
addappid(396172) -- HELLDIVERS - Terrain Specialist Pack
addappid(396173) -- HELLDIVERS - Precision Expert Pack
addappid(542760) -- Community Cape
addappid(542761) -- Developer Cape
addappid(1329700) -- Proven Bug Expert I Cape
addappid(1329701) -- Proven Bug Expert II Cape
addappid(1329702) -- Proven Bug Expert III Cape
addappid(1329703) -- Proven Cyborg Expert I Cape
addappid(1329704) -- Proven Cyborg Expert II Cape
addappid(1329705) -- Proven Cyborg Expert III Cape
addappid(1329706) -- Proven Illuminate Expert I Cape
addappid(1329707) -- Proven Illuminate Expert II Cape
addappid(1329708) -- Proven Illuminate Expert III Cape
