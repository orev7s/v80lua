-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(1184770) -- The Political Process

-- MAIN APP DEPOTS
addappid(1184771, 1, "0e04445810a9e2966305c43ec0a2c8c692ccdf5456ba0935bcae277bf4c2eadf") -- The Political Process Content
setManifestid(1184771, "2232540559173077115", 0)
