-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(236430) -- DARK SOULS™ II

-- MAIN APP DEPOTS
addappid(236432, 1, "eda018a11af0a6a37b59a60dadcbfca12bd721227868fcff4053b8b85e67bd05") -- DARK SOULS™ II TechDev Depot
setManifestid(236432, "4547260915165328308", 0)

-- SHARED DEPOTS (from other apps)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
setManifestid(228982, "6413394087650432851", 0)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Dark Souls II - Pre-Order DLC ROW (AppID: 271940)
addappid(271940)
addappid(271940, 1, "591c3310fabae8ea378bcd7de0d2d6e51021ff65de92140c0869f2a90df0e3ce") -- Dark Souls II - Pre-Order DLC ROW - Dark Souls II - Pre-Order DLC (271940) Depot
setManifestid(271940, "3404732443660876107", 0)

-- Dark Souls II - Digital Extras (AppID: 271941)
addappid(271941)
addappid(271941, 1, "e6c617c30eb9d95791592e9fb5200627d32cb74264e74e58d55ffd04d01b0ff6") -- Dark Souls II - Digital Extras - Dark Souls II - Digital Extras (271941) Depot
setManifestid(271941, "8479411515924661579", 0)

-- Dark Souls II Crown of the Sunken King (AppID: 271942)
addappid(271942)
addappid(271942, 1, "a1965b62e56b19e4ff236ec31cef3b501ea253fd4d0f958b9f3db502e7e92e86") -- Dark Souls II Crown of the Sunken King - Dark Souls II - DLC 1 (271942) Depot
setManifestid(271942, "1308165959807529893", 0)

-- DARK SOULS II Crown of the Old Iron King (AppID: 271943)
addappid(271943)
addappid(271943, 1, "03066e42170eb2798cc95b53972b74fc6ad4e994b1f0ad1c62720136abbd954a") -- DARK SOULS II Crown of the Old Iron King - Dark Souls II - DLC 2 (271943) Depot
setManifestid(271943, "7128319083619969881", 0)

--  DARK SOULS II Crown of the Ivory King  (AppID: 271944)
addappid(271944)
addappid(271944, 1, "cce41eba79f1afc8fe13f0c97724e9bf9e1fbe22782a2eb17582fdc3a8b5780e") --  DARK SOULS II Crown of the Ivory King  - Dark Souls II - DLC 3 (271944) Depot
setManifestid(271944, "633989536178537058", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(284450) -- DARK SOULS II - Season Pass
addappid(355700) -- Dark Souls II Upgrade to DX11 (no content)
