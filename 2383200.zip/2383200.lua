-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(2383200) -- PATAPON 1+2 REPLAY

-- MAIN APP DEPOTS
addappid(2383201, 1, "e6ab327b2ce7b1d4a38492ab781adbe69841ef9b0a99d0d939c6c9d65eed4950") -- Depot 2383201
setManifestid(2383201, "4584414798360174724", 0)
