-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(2589500, 1, "5163fe41419ecfe3e90105d7df21b63bea613635c470bc40684a61343139d02a") -- Whisper of the House
-- MAIN APP DEPOTS
addappid(2589501, 1, "6f51226f61dd888511279cdc32b68f2eafddb79f8d92998ffcac30e6dae73021") -- Depot 2589501
setManifestid(2589501, "9155670716029015917", 1685625635)
addappid(2589502, 1, "4b0d0eb017d111efc9280dba6335288de7d0c691d506d8ab30559a254745f0c2") -- Depot 2589502
setManifestid(2589502, "7969160053225832203", 1271134796)