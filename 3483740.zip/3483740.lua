-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(3483740) -- Cast n Chill

-- MAIN APP DEPOTS
addappid(3483741, 1, "0085e2ab6e91d273c72748b41db876429a43a28e359be3bd5519ddfa4d8ac501") -- Depot 3483741
setManifestid(3483741, "1867447625032413701", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3817870) -- Cast n Chill - Supporter Pack
