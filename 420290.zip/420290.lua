-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @F1uxin on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!)

-- MAIN APPLICATION
addappid(420290) -- Blackwake

-- MAIN APP DEPOTS
addappid(420291, 1, "715fd5227f70d1cd22ebc1ee84cd5dc7ece7398557f1895cdb6ae86d77bd937b") -- Blackwake Content
setManifestid(420291, "1592912621462898970", 0)
addappid(420292, 1, "f9387a752c8e42a7e244c2cca172c937cc79252cb41ee42988880da6231116ed") -- Blackwake Mac Content
setManifestid(420292, "2828512673510155885", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Blackwake Official Soundtrack (AppID: 594184)
addappid(594184)
addappid(594184, 1, "de765848c0372d68ce1cc5f2e1b8481cc9368757d01834a9e637a2acacf1c8c4") -- Blackwake Official Soundtrack - Blackwake Official Soundtrack (594184) Depot
setManifestid(594184, "541769012033032750", 0)
