-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪username - f1uxin, on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy / https://discord.gg/m8PxjTwrnv
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(268910) -- Cuphead

-- MAIN APP DEPOTS
addappid(268911, 1, "5f5e2d0105e9fcfbd0c7151658efd92af0181865fe434192f8e2c5d24d4940da") -- Cuphead
setManifestid(268911, "6818141525323043853", 0)
addappid(268912, 1, "6378a6f3808fd925e8fdc2cd115d7b60f1908a6dff6b5f6c1fb0af7f392db1e4") -- Cuphead Depot MacOS
setManifestid(268912, "8633535714830637397", 0)

-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Cuphead - Official Soundtrack (AppID: 704710)
addappid(704710)
addappid(704711, 1, "355f7a6485745876ae337f59efb63a2a7c2012d8cfcbaf99fe6e93b511184b03") -- Cuphead - Official Soundtrack - Cuphead - Official Soundtrack Depot FLAC
setManifestid(704711, "4630179950063277534", 0)
addappid(704712, 1, "1d311725ca119b72edfa849cbbe123b72e39cdaef19dc8a22f15529d8ef2a556") -- Cuphead - Official Soundtrack - Main Content
setManifestid(704712, "7905790265200937644", 0)

-- Cuphead - The Delicious Last Course (AppID: 1117850)
addappid(1117850)
addappid(1117850, 1, "c40d10dcd40756563a4956777e0bb4333e48d34c00e2836edd3d5fdbc0eba095") -- Cuphead - The Delicious Last Course - Cuphead - The Delicious Last Course (1117850) Depot
setManifestid(1117850, "468317947627682665", 0)
addappid(1117851, 1, "1d08dafb023ed4a43d3def619d54ace53b3b4bced035e744da83b4449f26cac7") -- Cuphead - The Delicious Last Course - Cuphead - The Delicious Last Course macOS
setManifestid(1117851, "819870908970387521", 0)

-- Cuphead DLC - Official Soundtrack (AppID: 2072990)
addappid(2072990)
addappid(2072991, 1, "2b53c9cd8ecf62cc469ee5f1f0cecb6e1217f9c766e5c58eb95084107868da66") -- Cuphead DLC - Official Soundtrack - Main Content
setManifestid(2072991, "7794271606339901763", 0)
addappid(2072992, 1, "fff30d5cdd3c7b9f7436ac0f2c962ec5ab80282ddb8cf0129eaa6723909c9724") -- Cuphead DLC - Official Soundtrack - Main Content
setManifestid(2072992, "6626318741336770131", 0)
