-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(270850) -- Car Mechanic Simulator 2014

-- MAIN APP DEPOTS
addappid(270851, 1, "d520abba588b2738105316385169d81f779791970ac561ed56dad9d94df67d8c") -- Car Mechanic Simulator Content
setManifestid(270851, "7518239275915052170", 0)
addappid(270852, 1, "b04a091ea2482e57489d2df2e81be96e0cc67d954db688906a61fee8b6526dd5") -- Car Mechanic Simulator 2014 Mac Content
setManifestid(270852, "6239589292338307389", 0)

-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
