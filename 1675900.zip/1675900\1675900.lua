addappid(1675900)
addappid(1675901,0,"fe75a2e006426eb8247eec627743412480cd31a19944415300eb79a9047aec39")
setManifestid(1675901,"8840344246572852116")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]