addappid(1417930)
addappid(1417931,1,"5b76612a1259cbc965a2eceef7a1d4d160d6b2e65c2b4fc5681e750fbb003bfe")
setManifestid(1417931,"5532433508306036786")
addappid(1417932,1,"57e8e6ac342d60b8ba99ddaf768cbce52669d6db3ad312825820a8771452d426")
setManifestid(1417932,"4678430555601243672")
addappid(1417933,1,"bb4851151182643573b804a9cd9b106581aa0f7a4ad5f7e793f8d3c9064be280")
setManifestid(1417933,"397158387591264421")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]