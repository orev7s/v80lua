-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy

-- MAIN APPLICATION
addappid(3243190) -- Psychopomp GOLD

-- MAIN APP DEPOTS
addappid(3243191, 1, "1d824266375cee6f4a2a806d88eacb83417e0ceb562e70c4fc14c85ebe87394f") -- Main Game Content (Windows Content)
setManifestid(3243191, "553130103415772762", 0)

-- DLCS EXCLUDED (NO DEPOT KEYS, NO DEDICATED DEPOTS)
-- addappid(3316520) -- Psychopomp OST Vol. 1  2 (no keys available)
