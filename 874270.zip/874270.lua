-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(874270) -- Sphaera

-- MAIN APP DEPOTS
addappid(874271, 1, "eeae667f987b3dde51bf4b496b53a804b100f1c4c0d9309fcabf3e0a9ab99ff3") -- Sphaera Content
setManifestid(874271, "512303366590803899", 0)
