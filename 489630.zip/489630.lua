-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @f1uxin on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy / https://discord.gg/m8PxjTwrnv
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(489630, 1, "de35a1a75ebf92e40ea43bb11248f578291c59f64eea9582935a1206eee600cc") -- Warhammer 40,000: Gladius - Relics of War
-- MAIN APP DEPOTS
addappid(489633, 1, "6bfeeddc0c7c9ab4c84e53df522ca4caf4b1613a43e564d36b986ec55f5463f8") -- Warhammer 40,000: Gladius - Relics of War - Shared
setManifestid(489633, "1017373402554168713", 3609432737)
addappid(489631, 1, "98cad733831ba87cf9c07a92272afbcfcf98b22daea917ab778b0f46ac6473b8") -- Warhammer 40,000: Gladius - Relics of War - Windows
setManifestid(489631, "709918767035615746", 154937726)
addappid(489632, 1, "2181cc760c11eec2b2088e83099b893bbef7db3b725ab0f437942b2f6a6042b6") -- Warhammer 40,000: Gladius - Relics of War - Linux
setManifestid(489632, "4080589862810097164", 156164226)
addappid(870530, 1, "4e12760f62e2227d48295b0f3b0422870e19f58cb4fb97f5a845b2b36f4aa30a") -- Warhammer 40,000: Gladius - Relics of War - Soundtrack (870530) Depot
setManifestid(870530, "8903843273179332056", 1278386096)
-- SHARED DEPOTS (from other apps)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- .NET 4.7 Redist (Shared from App 228980)
setManifestid(229006, "1784011429307107530", 83944258)
-- DLCS WITH DEDICATED DEPOTS
-- Warhammer 40,000 Gladius - Lord of Skulls (AppID: 870540)
addappid(870540)
addtoken(870540, "3316042410707366797")
addappid(870540, 1, "6e0cd7069ff1bb92e841c6045af49df24f0012760cbfa2b36a6baea8e8648e33") -- Warhammer 40,000 Gladius - Lord of Skulls - Warhammer 40,000: Gladius - Relics of War - Lord of Skulls exclusive unit (870540) Depot
setManifestid(870540, "442301573797662394", 12)
-- Warhammer 40,000 Gladius - Relics of War - Wallpapers (AppID: 870550)
addappid(870550)
addtoken(870550, "7595109318970487055")
addappid(870550, 1, "8f35ba8a63d84bb32165ffd1c934a166e581becffc9e3908a561c927f605caac") -- Warhammer 40,000 Gladius - Relics of War - Wallpapers - Warhammer 40,000: Gladius - Relics of War - Wallpapers (870550) Depot
setManifestid(870550, "7813621408118342533", 27471194)
-- Warhammer 40,000 Gladius - Reinforcement Pack (AppID: 961840)
addappid(961840)
addappid(961840, 1, "e04d4e06fffc382f6c245d339f0c0b761d3813b94f38e9a69135b828ecd1ed6f") -- Warhammer 40,000 Gladius - Reinforcement Pack - Warhammer 40,000: Gladius - Reinforcement Pack (961840) Depot
setManifestid(961840, "7296323810134405176", 11)
-- Warhammer 40,000 Gladius - Tyranids (AppID: 995860)
addappid(995860)
addappid(995860, 1, "2c8c2a78b1d4c6d478c7de8f44bd9fae8f9199cc5fd003a203005136d53ce006") -- Warhammer 40,000 Gladius - Tyranids - Warhammer 40,000: Gladius - Tyranids (995860) Depot
setManifestid(995860, "4144015961261623394", 11)
-- Warhammer 40,000 Gladius - Chaos Space Marines (AppID: 1084820)
addappid(1084820)
addappid(1084820, 1, "ee313c687835e5166562e269b36572e89de3a45cafbeaf1879db587d5681bd49") -- Warhammer 40,000 Gladius - Chaos Space Marines - Warhammer 40,000: Gladius - Chaos Space Marines (1084820) Depot
setManifestid(1084820, "4214815001978544993", 11)
-- Warhammer 40,000 Gladius - Fortification Pack (AppID: 1170010)
addappid(1170010)
addappid(1170010, 1, "78a8474c3c6a3d4d0437cd808aeaa18fc4e4e923f0f58988c2887c12b6e1e949") -- Warhammer 40,000 Gladius - Fortification Pack - Warhammer 40,000: Gladius - Fortification Pack (1170010) Depot
setManifestid(1170010, "8986672640384167430", 11)
-- Warhammer 40,000 Gladius - Tau (AppID: 1239450)
addappid(1239450)
addappid(1239450, 1, "06a825d11874fb9ccec98d4720b93362b1401cd05e30f240b6c64d1cdcd302dc") -- Warhammer 40,000 Gladius - Tau - Warhammer 40,000: Gladius - Tau (1239450) Depot
setManifestid(1239450, "1412725218929693043", 11)
-- Warhammer 40,000 Gladius - Assault Pack (AppID: 1330480)
addappid(1330480)
addappid(1330480, 1, "dc33d113a2f943b9be884c2817828603859f93972619902dab7c39d0ecb8b649") -- Warhammer 40,000 Gladius - Assault Pack - Warhammer 40,000: Gladius - Assault Pack (1330480) Depot
setManifestid(1330480, "8560968486342641530", 11)
-- Warhammer 40,000 Gladius - Craftworld Aeldari (AppID: 1425820)
addappid(1425820)
addappid(1425820, 1, "be8694de13023b51c4cad8d672e68571f20dd0072714424f5fbf97dc9e0ac4a7") -- Warhammer 40,000 Gladius - Craftworld Aeldari - Warhammer 40,000: Gladius - Craftworld Aeldari (1425820) Depot
setManifestid(1425820, "7181811712912349053", 11)
-- Warhammer 40,000 Gladius - Specialist Pack (AppID: 1640850)
addappid(1640850)
addappid(1640850, 1, "d69f24faedae1efb5695169b70140cc649be555e18e2be643ee324a617fe7294") -- Warhammer 40,000 Gladius - Specialist Pack - Warhammer 40,000: Gladius - Specialist Pack (1640850) Depot
setManifestid(1640850, "9212576765883138281", 128)
-- Warhammer 40,000 Gladius - Adeptus Mechanicus (AppID: 1788210)
addappid(1788210)
addappid(1788210, 1, "85a2c84a029166be6e595e081b6bf9f39a8f98652b0c8c01d0bc35e7d91f9a60") -- Warhammer 40,000 Gladius - Adeptus Mechanicus - Warhammer 40,000: Gladius - Adeptus Mechanicus (1788210) Depot
setManifestid(1788210, "6718914060557802407", 128)
-- Warhammer 40,000 Gladius - Escalation Pack (AppID: 2006870)
addappid(2006870)
addappid(2006870, 1, "541a5c3ccb66295018e90753817508bd11691d17aa4d894379b0dfdbf433f2ab") -- Warhammer 40,000 Gladius - Escalation Pack - Depot 2006870
setManifestid(2006870, "4076941040674822771", 128)
-- Warhammer 40,000 Gladius - Adepta Sororitas (AppID: 2130960)
addappid(2130960)
addappid(2130960, 1, "2e41d3eb51b475a717f4526395d8cf7bbbbc09ee871cd5ecc6efdfafdf2481b6") -- Warhammer 40,000 Gladius - Adepta Sororitas - Depot 2130960
setManifestid(2130960, "8813317415370242721", 128)
-- Warhammer 40,000 Gladius - Firepower Pack (AppID: 2399890)
addappid(2399890)
addappid(2399890, 1, "2d8288c197415cced529152df9e87700f628d56e35db913c1549eaecca674086") -- Warhammer 40,000 Gladius - Firepower Pack - Depot 2399890
setManifestid(2399890, "4892800493497001049", 128)
-- Warhammer 40,000 Gladius - Drukhari (AppID: 2668040)
addappid(2668040)
addappid(2668040, 1, "d994cddf0661503e891556f8a8dc28f74586be3c16c9520fa5ba392dd2dbcea2") -- Warhammer 40,000 Gladius - Drukhari - Depot 2668040
setManifestid(2668040, "7709192808205830515", 128)
-- Warhammer 40,000 Gladius - Demolition Pack (AppID: 2932380)
addappid(2932380)
addappid(2932380, 1, "cbe017581e8b542a1262cbd153e731d294da59db188801a36647944a080b9d52") -- Warhammer 40,000 Gladius - Demolition Pack - Depot 2932380
setManifestid(2932380, "8151899288165800345", 128)
-- Warhammer 40,000 Gladius - Ultima Founding (AppID: 3326080)
addappid(3326080)
addappid(3326080, 1, "5a032138ec68be28197d6e03a29eb1c99e8c7f392838b8ea170ac329111040cc") -- Warhammer 40,000 Gladius - Ultima Founding - Depot 3326080
setManifestid(3326080, "7375851679082319866", 128)
-- Warhammer 40,000 Gladius - Onslaught Pack (AppID: 3743110)
addappid(3743110)
addappid(3743110, 1, "126dd0c29b9af92ee931d376f40a6b77e15602a53c6c4ff3e4963c427853d1f5") -- Warhammer 40,000 Gladius - Onslaught Pack - Depot 3743110
setManifestid(3743110, "8622599070272747958", 128)