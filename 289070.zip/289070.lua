-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(289070) -- Sid Meier's Civilization VI

-- MAIN APP DEPOTS
addappid(289071, 1, "32741972cb390fe0fb0253da0e76fb113c9f92280b55093fb4c901b0c84e1a8d") -- Madrid Content
setManifestid(289071, "8544233926751202622", 0)
addappid(289072, 1, "3d2108e73f87d05885853ba5e72d9fc0d80c7f4a834e3fec557479960a6f12e8") -- Madrid EXE
setManifestid(289072, "6099197820122050814", 0)
addappid(533500, 1, "ee43c4a838717e3a4bd9973e4038155c27a9ebd0f0d9b9de4de50e272491b313") -- Mac Madrid Content
setManifestid(533500, "3582333838161073165", 0)
addappid(533501, 1, "c9865d5c2a00f794d06e91b982f882e0b2cf9ca6bea37b5eb37d35cd83955b67") -- Mac Madrid EXE
setManifestid(533501, "7747155898342983879", 0)
addappid(533502, 1, "6a28697b6e29d111b9b2789d8740b1e0d36cbf949a0ed00b500d438cf6ca81b1") -- Linux Content
setManifestid(533502, "731801825977417543", 0)
addappid(533503, 1, "ba65f8252337d21a1861ece22ebd5d5a8b6e0afec40e5ba20cb30d363a59afee") -- Linux Exe
setManifestid(533503, "4174395120133247913", 0)
addappid(289089, 1, "a1cab903cd10b15478bc455b931245ef42becf828cbefc19bb922dfaf06776b2") -- Launcher Test
setManifestid(289089, "2262196785766153034", 0)
addappid(289085, 1, "993eb4eff10f1f76852177fcd3e668b202059359f3f854085a162a269eb12e51") -- Game Content (Depot 289085)
setManifestid(289085, "3736787343973544061", 0)
addappid(289086, 1, "4bcd85f1a6e269ac65b7637fcc6b922bf2cab229cc8a5f55e34a1a890490997d") -- Game Content (Depot 289086)
setManifestid(289086, "4181354221225583522", 0)

-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 0)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Sid Meiers Civilization VI Aztec Civilization Pack (AppID: 512030)
addappid(512030)
addappid(512030, 1, "8414f9daababcb658bab729cfe1713cae6cc02e8418e12139132c6ca49275dce") -- Sid Meiers Civilization VI Aztec Civilization Pack - Aztec Pre-Order (512030) Depot
setManifestid(512030, "1307444271017398491", 0)
addappid(533513, 1, "25c9aa2d1ad239ea2f131216fb0917f5ab8005af6ea35a468a4dfabee16fc1ee") -- Sid Meiers Civilization VI Aztec Civilization Pack - Mac Pre-Order DLC Aztec Civ Pack
setManifestid(533513, "4883015003824094634", 0)
addappid(533504, 1, "5cfb7c534d8154a04622b21e0fd86b6f43338f9bbf96e42ff7e32d23a21fb258") -- Sid Meiers Civilization VI Aztec Civilization Pack - Linux DLC Aztec Civ Pack
setManifestid(533504, "4730013291139588863", 0)

-- Sid Meiers Civilization VI 25th Anniversary Soundtrack (AppID: 512031)
addappid(512031)
addtoken(512031, "7126022563837032702")
addappid(512031, 1, "bf4e034745cadce7e2deadbe49f0295fabda3bb4d53cb81245dedd8b4f864932") -- Sid Meiers Civilization VI 25th Anniversary Soundtrack - Madrid Soundtrack (512031) Depot
setManifestid(512031, "935919882264911440", 0)

-- Sid Meiers Civilization VI Vikings Scenario Pack (AppID: 512032)
addappid(512032)
addappid(512032, 1, "96db6adf9acfd23efac126a1b390566ce3d60c9383c8a12277a3364a0c9825b3") -- Sid Meiers Civilization VI Vikings Scenario Pack - Madrid DLC01 (512032) Depot
setManifestid(512032, "289731471744368186", 0)
addappid(533514, 1, "96bc216f9252b61f705d823293ed0a8cc7243021a3e9c914292525f3f8f654d3") -- Sid Meiers Civilization VI Vikings Scenario Pack - Mac Madrid DLC01
setManifestid(533514, "7612473275221842603", 0)
addappid(533505, 1, "83feda3eccf1abb7cba2ab01bd2c9fa4c121b508ead25162c7e2ca9b6db56488") -- Sid Meiers Civilization VI Vikings Scenario Pack - Linux DLC 01
setManifestid(533505, "7075230729490869604", 0)

-- Sid Meiers Civilization VI Poland Civilization  Scenario Pack (AppID: 512033)
addappid(512033)
addappid(512033, 1, "119999ebe1538e1bceacbccbd0a33aaab47cd471ef2dba9bae58afdeaf298c7f") -- Sid Meiers Civilization VI Poland Civilization  Scenario Pack - Madrid DLC02 (512033) Depot
setManifestid(512033, "6543787341305416944", 0)
addappid(533515, 1, "fa7c250de971db52d1cc11d0ab324e83060acab493717015a0cb18b6805f5f3b") -- Sid Meiers Civilization VI Poland Civilization  Scenario Pack - Mac Madrid DLC02
setManifestid(533515, "3777915635781502631", 0)
addappid(533506, 1, "f7d95d7da09211df4822cd1bf907b5677bb04a133d60fdd0048cd3b2954ae855") -- Sid Meiers Civilization VI Poland Civilization  Scenario Pack - Linux DLC 02
setManifestid(533506, "4883125394190134028", 0)

-- Sid Meiers Civilization VI Australia Civilization  Scenario Pack (AppID: 512034)
addappid(512034)
addappid(512034, 1, "f1b7b50ee592be7ea3f70a78001aee65d745768a549fe125274c9c68377fe19d") -- Sid Meiers Civilization VI Australia Civilization  Scenario Pack - Madrid DLC03 (512034) Depot
setManifestid(512034, "2152869585815545599", 0)
addappid(533516, 1, "8072993ec1d1f3c20674e14aca28a5cbbc462beaf45c771111381e434a184779") -- Sid Meiers Civilization VI Australia Civilization  Scenario Pack - Mac Madrid DLC03
setManifestid(533516, "7646238166100862470", 0)
addappid(533507, 1, "acec8d06a13af1db888b52f8d7fe8848e03d8d1ec03e139c2ed8af0a7aafd9b5") -- Sid Meiers Civilization VI Australia Civilization  Scenario Pack - Linux DLC 03
setManifestid(533507, "6138702642890809933", 0)

-- Sid Meiers Civilization VI Persia and Macedon Civilization  Scenario Pack (AppID: 512035)
addappid(512035)
addappid(512035, 1, "13581afaf8e722ba3a7eeec875c1214d186c9c139b7baf2fde68c13e928fe7c4") -- Sid Meiers Civilization VI Persia and Macedon Civilization  Scenario Pack - Madrid DLC04 (512035) Depot
setManifestid(512035, "1790067132481013428", 0)
addappid(533517, 1, "ef85623de67473f14590612adf8e79f14c404895c4a4b86897581cbddd63c749") -- Sid Meiers Civilization VI Persia and Macedon Civilization  Scenario Pack - Mac Madrid DLC04
setManifestid(533517, "1796892286900093121", 0)
addappid(533508, 1, "b014e8ca6d7083f95aa5885a5797716e3691f43341c3a9636c9ca731489d76c5") -- Sid Meiers Civilization VI Persia and Macedon Civilization  Scenario Pack - Linux DLC 04
setManifestid(533508, "6046355588939991635", 0)

-- Sid Meiers Civilization VI Nubia Civilization  Scenario Pack (AppID: 645400)
addappid(645400)
addappid(645400, 1, "8a46441e5fdfc733e511fc579168bcd03791875c78251afb120f6a6ca8f58333") -- Sid Meiers Civilization VI Nubia Civilization  Scenario Pack - Madrid DLC05 (645400) Depot
setManifestid(645400, "6669591788022875766", 0)
addappid(533518, 1, "d8def9e6eedd435729f252b4b7baab2108e2ca8136a1c777c011405d293740d2") -- Sid Meiers Civilization VI Nubia Civilization  Scenario Pack - Mac Madrid DLC05
setManifestid(533518, "4753960813384213451", 0)
addappid(533509, 1, "c33fffb83594745bb85ebabafe952225ce80fe20b05bb6cc2c81ebf44d34198c") -- Sid Meiers Civilization VI Nubia Civilization  Scenario Pack - Linux DLC 05
setManifestid(533509, "6788302695122360131", 0)

-- Sid Meiers Civilization VI Khmer and Indonesia Civilization  Scenario Pack (AppID: 645401)
addappid(645401)
addappid(645401, 1, "6ea08c1c060dcd07c457e12d8149ca548da5b9a40ef543fcd15691a3d1ba7784") -- Sid Meiers Civilization VI Khmer and Indonesia Civilization  Scenario Pack - Madrid DLC06 (645401) Depot
setManifestid(645401, "1323691328654612056", 0)
addappid(533519, 1, "e7563567a842cfd82717ee1543b45c93430d81d01008c882b7d3418616ca6530") -- Sid Meiers Civilization VI Khmer and Indonesia Civilization  Scenario Pack - Mac Madrid DLC06
setManifestid(533519, "6954487309733964639", 0)
addappid(533510, 1, "64e4e71723d9d13db750f4df85bfc5a0cb331d48c3aa4cd81091f39bea3c09a9") -- Sid Meiers Civilization VI Khmer and Indonesia Civilization  Scenario Pack - Linux DLC 06
setManifestid(533510, "6004862015692629805", 0)

-- Sid Meiers Civilization VI Rise and Fall (AppID: 645402)
addappid(645402)
addappid(645402, 1, "9e2251ad6d619d6ac2645cdcc17ac9493f2fc9777a68ab304e211f5bf8b018d4") -- Sid Meiers Civilization VI Rise and Fall - Civ GH (645402) Depot
setManifestid(645402, "1533123057189778450", 0)
addappid(533512, 1, "33a4921125ef9ce860aa0bbec3a0dc994171a3058be7e6d7ba868ece88742db7") -- Sid Meiers Civilization VI Rise and Fall - Mac Madrid Expansion1
setManifestid(533512, "1157918082164175537", 0)
addappid(533511, 1, "5e295ec44b83955f08f49cf8884f4cb7f138461da3aad081e4649ddcfc7d268d") -- Sid Meiers Civilization VI Rise and Fall - Linux Expansion1
setManifestid(533511, "4086532032936568200", 0)

-- Sid Meiers Civilization VI Gathering Storm (AppID: 947510)
addappid(947510)
addappid(947510, 1, "12ed67821997d2ff92e4155d8735d254c5f20f27abba7ba4eb1dde6759ec8e4e") -- Sid Meiers Civilization VI Gathering Storm - DepotTest (947510) Depot
setManifestid(947510, "63266334988112509", 0)
addappid(947518, 1, "5cc97a451ab6835a9748d42855586c4f83fef8581f0be62d55ab82963822d2c7") -- Sid Meiers Civilization VI Gathering Storm - Mac Madrid Expansion2
setManifestid(947518, "8161718464020064952", 0)
addappid(947519, 1, "654ac94cedb0a52d9fa38d7231b8f4b4dfd62b821ea78c3a59f7d74242d331ca") -- Sid Meiers Civilization VI Gathering Storm - Linux Expansion2
setManifestid(947519, "5584778302079664846", 0)

-- Sid Meiers Civilization VI Catherine de Medici Persona Pack (AppID: 1342010)
addappid(1342010)
addtoken(1342010, "9041882688234722446")
addappid(1342011, 1, "ea124a7e31d2d3282d894a902771c1c879f1c3f6fd3d9fe48a6a6bc50dfaea42") -- Sid Meiers Civilization VI Catherine de Medici Persona Pack - Mac TinyCar
setManifestid(1342011, "1414305630544405034", 0)
addappid(1342012, 1, "70a1293d4491b8f45130bab379017d6d3cccbdfaa892a6ef610ea3762c0ee39b") -- Sid Meiers Civilization VI Catherine de Medici Persona Pack - Linux TinyCar
setManifestid(1342012, "822199356429897707", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(521770) -- Sid Meiers Civilization VI Digital Deluxe Extras
addappid(1308090) -- Sid Meiers Civilization VI New Frontier Pass
addappid(2158250) -- Sid Meiers Civilization VI Leader Pass

-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Sid Meiers Civilization VI Maya  Gran Colombia Pack (AppID: 1253990) - missing keys for depots: [1253991, 1253991, 1253992, 1253992]
-- addappid(1253990)
-- addappid(1253991, 1, "e902367397b6079f60002946cc17e4d8caea4114f74f60d225be0004e721017d") -- Sid Meiers Civilization VI Maya  Gran Colombia Pack - Mac Runner (excluded with DLC)
-- setManifestid(1253991, "69626392930517475", 0)
-- addappid(1253991, 1, "e902367397b6079f60002946cc17e4d8caea4114f74f60d225be0004e721017d") -- Sid Meiers Civilization VI Maya  Gran Colombia Pack - Mac Runner (excluded with DLC)
-- setManifestid(1253991, "69626392930517475", 0)
-- addappid(1253992, 1, "6673a545570835463a5750d1ce4a4cbc7c696b7ab4dae26255c86fdfe91705d9") -- Sid Meiers Civilization VI Maya  Gran Colombia Pack - Linux Runner (excluded with DLC)
-- setManifestid(1253992, "190753679128426469", 0)
-- addappid(1253992, 1, "6673a545570835463a5750d1ce4a4cbc7c696b7ab4dae26255c86fdfe91705d9") -- Sid Meiers Civilization VI Maya  Gran Colombia Pack - Linux Runner (excluded with DLC)
-- setManifestid(1253992, "190753679128426469", 0)

-- Sid Meiers Civilization VI Ethiopia Pack (AppID: 1270540) - missing keys for depots: [1270541, 1270541, 1270542, 1270542]
-- addappid(1270540)
-- addappid(1270541, 1, "d863b54dcb049ec6e1efe4567b6a9a96c3b0a25d1262d267b9d75e99bb30ffdd") -- Sid Meiers Civilization VI Ethiopia Pack - Mac Plaid (excluded with DLC)
-- setManifestid(1270541, "4965920854392412262", 0)
-- addappid(1270541, 1, "d863b54dcb049ec6e1efe4567b6a9a96c3b0a25d1262d267b9d75e99bb30ffdd") -- Sid Meiers Civilization VI Ethiopia Pack - Mac Plaid (excluded with DLC)
-- setManifestid(1270541, "4965920854392412262", 0)
-- addappid(1270542, 1, "33500db5f561604706815a311f6c5340d247317b07f3335895163a3d06b97467") -- Sid Meiers Civilization VI Ethiopia Pack - Linux Plaid (excluded with DLC)
-- setManifestid(1270542, "740044253414621401", 0)
-- addappid(1270542, 1, "33500db5f561604706815a311f6c5340d247317b07f3335895163a3d06b97467") -- Sid Meiers Civilization VI Ethiopia Pack - Linux Plaid (excluded with DLC)
-- setManifestid(1270542, "740044253414621401", 0)

-- Sid Meiers Civilization VI Teddy Roosevelt Persona Pack (AppID: 1281820) - missing keys for depots: [1281821, 1281821, 1281822, 1281822]
-- addappid(1281820)
-- addtoken(1281820, "13286021469407624402")
-- addappid(1281821, 1, "bf4cad76e34f172e797fc09967c5f110d26cf7636bf832f7bc2184a0072b8bc5") -- Sid Meiers Civilization VI Teddy Roosevelt Persona Pack - Mac Zoomzoom (excluded with DLC)
-- setManifestid(1281821, "2667616415541059397", 0)
-- addappid(1281821, 1, "bf4cad76e34f172e797fc09967c5f110d26cf7636bf832f7bc2184a0072b8bc5") -- Sid Meiers Civilization VI Teddy Roosevelt Persona Pack - Mac Zoomzoom (excluded with DLC)
-- setManifestid(1281821, "2667616415541059397", 0)
-- addappid(1281822, 1, "06a9093294fc2dbd7335093ed9510aa44b3bdb0ba53157b86ba0b38703cc8a2a") -- Sid Meiers Civilization VI Teddy Roosevelt Persona Pack - Linux Zoomzoom (excluded with DLC)
-- setManifestid(1281822, "294718810747213782", 0)
-- addappid(1281822, 1, "06a9093294fc2dbd7335093ed9510aa44b3bdb0ba53157b86ba0b38703cc8a2a") -- Sid Meiers Civilization VI Teddy Roosevelt Persona Pack - Linux Zoomzoom (excluded with DLC)
-- setManifestid(1281822, "294718810747213782", 0)

-- Sid Meiers Civilization VI Byzantium  Gaul Pack (AppID: 1284470) - missing keys for depots: [1284471, 1284471, 1284472, 1284472]
-- addappid(1284470)
-- addtoken(1284470, "887974276820259093")
-- addappid(1284471, 1, "547ec1312d32f232e79c9a5ace35e93b454d517c48128f6d7a4d80355400c67b") -- Sid Meiers Civilization VI Byzantium  Gaul Pack - Mac SoonTM (excluded with DLC)
-- setManifestid(1284471, "7896478682364606", 0)
-- addappid(1284471, 1, "547ec1312d32f232e79c9a5ace35e93b454d517c48128f6d7a4d80355400c67b") -- Sid Meiers Civilization VI Byzantium  Gaul Pack - Mac SoonTM (excluded with DLC)
-- setManifestid(1284471, "7896478682364606", 0)
-- addappid(1284472, 1, "2a429b6c8ea5f7ca2c504765c250ae93114a2adbd711861692a6b2d6fbee0c21") -- Sid Meiers Civilization VI Byzantium  Gaul Pack - Linux SoonTM (excluded with DLC)
-- setManifestid(1284472, "3367499075511523244", 0)
-- addappid(1284472, 1, "2a429b6c8ea5f7ca2c504765c250ae93114a2adbd711861692a6b2d6fbee0c21") -- Sid Meiers Civilization VI Byzantium  Gaul Pack - Linux SoonTM (excluded with DLC)
-- setManifestid(1284472, "3367499075511523244", 0)

-- Sid Meiers Civilization VI Babylon Pack (AppID: 1388850) - missing keys for depots: [1388851, 1388851, 1388852, 1388852]
-- addappid(1388850)
-- addappid(1388851, 1, "9f241cb21ed61c3647868484c0cc309662fa50d0165c6c6b70c6950b1cd45dcf") -- Sid Meiers Civilization VI Babylon Pack - Mac MoorTires (excluded with DLC)
-- setManifestid(1388851, "2127854356908969923", 0)
-- addappid(1388851, 1, "9f241cb21ed61c3647868484c0cc309662fa50d0165c6c6b70c6950b1cd45dcf") -- Sid Meiers Civilization VI Babylon Pack - Mac MoorTires (excluded with DLC)
-- setManifestid(1388851, "2127854356908969923", 0)
-- addappid(1388852, 1, "cc7f9df4fc6dbc1a4f17bfa6ba387c9b7f33b1cdf1c1cb59e4f9a7ea235c4812") -- Sid Meiers Civilization VI Babylon Pack - Linux MoorTires (excluded with DLC)
-- setManifestid(1388852, "308938244455417956", 0)
-- addappid(1388852, 1, "cc7f9df4fc6dbc1a4f17bfa6ba387c9b7f33b1cdf1c1cb59e4f9a7ea235c4812") -- Sid Meiers Civilization VI Babylon Pack - Linux MoorTires (excluded with DLC)
-- setManifestid(1388852, "308938244455417956", 0)

-- Sid Meiers Civilization VI Vietnam  Kublai Khan Pack (AppID: 1436950) - missing keys for depots: [1436951, 1436951, 1436952, 1436952]
-- addappid(1436950)
-- addappid(1436951, 1, "60039cec493cb3168ba98eeb94de7f17f164dd0b991590ed284c132b076b2356") -- Sid Meiers Civilization VI Vietnam  Kublai Khan Pack - Mac MouthBag (excluded with DLC)
-- setManifestid(1436951, "1600972111400550396", 0)
-- addappid(1436951, 1, "60039cec493cb3168ba98eeb94de7f17f164dd0b991590ed284c132b076b2356") -- Sid Meiers Civilization VI Vietnam  Kublai Khan Pack - Mac MouthBag (excluded with DLC)
-- setManifestid(1436951, "1600972111400550396", 0)
-- addappid(1436952, 1, "7ca4ca99a22e220b5033af83fef6b2b576dfd6feeeb54ce32c4a3227828be8d2") -- Sid Meiers Civilization VI Vietnam  Kublai Khan Pack - Linux MouthBag (excluded with DLC)
-- setManifestid(1436952, "3599798167341808173", 0)
-- addappid(1436952, 1, "7ca4ca99a22e220b5033af83fef6b2b576dfd6feeeb54ce32c4a3227828be8d2") -- Sid Meiers Civilization VI Vietnam  Kublai Khan Pack - Linux MouthBag (excluded with DLC)
-- setManifestid(1436952, "3599798167341808173", 0)

-- Sid Meiers Civilization VI Portugal Pack (AppID: 1478300) - missing keys for depots: [1478301, 1478301, 1478302, 1478302]
-- addappid(1478300)
-- addappid(1478301, 1, "e5938fc09f846d85f360988efd1d6d1f27ae4fdeafcb9c1afe7106dd72ab5f4b") -- Sid Meiers Civilization VI Portugal Pack - Mac PeachNPoppy (excluded with DLC)
-- setManifestid(1478301, "3042920571069713939", 0)
-- addappid(1478301, 1, "e5938fc09f846d85f360988efd1d6d1f27ae4fdeafcb9c1afe7106dd72ab5f4b") -- Sid Meiers Civilization VI Portugal Pack - Mac PeachNPoppy (excluded with DLC)
-- setManifestid(1478301, "3042920571069713939", 0)
-- addappid(1478302, 1, "dac6b0d084e2419c74ece517da48803b2ef57aaf7d855d9c39c91dd8106ef1e1") -- Sid Meiers Civilization VI Portugal Pack - Linux PeachNPoppy (excluded with DLC)
-- setManifestid(1478302, "601989005490512875", 0)
-- addappid(1478302, 1, "dac6b0d084e2419c74ece517da48803b2ef57aaf7d855d9c39c91dd8106ef1e1") -- Sid Meiers Civilization VI Portugal Pack - Linux PeachNPoppy (excluded with DLC)
-- setManifestid(1478302, "601989005490512875", 0)

-- Great Negotiators (AppID: 2173131) - missing keys for depots: [2173133, 2173133]
-- addappid(2173131)
-- addappid(2173133, 1, "66330ed52cf95ee2ade74db13281d0c1ace4d44fae46be89dee64a565c5c5a1e") -- Great Negotiators - Main Content (excluded with DLC)
-- setManifestid(2173133, "186484919774529386", 0)
-- addappid(2173133, 1, "66330ed52cf95ee2ade74db13281d0c1ace4d44fae46be89dee64a565c5c5a1e") -- Great Negotiators - Main Content (excluded with DLC)
-- setManifestid(2173133, "186484919774529386", 0)

-- Great Commanders (AppID: 2222600) - missing keys for depots: [2222605, 2222605]
-- addappid(2222600)
-- addappid(2222605, 1, "cc93d280f3c6baab550228224611098ca46ecd76d84f5c3fb5511b6f788ce460") -- Great Commanders - Main Content (excluded with DLC)
-- setManifestid(2222605, "1123507097971278864", 0)
-- addappid(2222605, 1, "cc93d280f3c6baab550228224611098ca46ecd76d84f5c3fb5511b6f788ce460") -- Great Commanders - Main Content (excluded with DLC)
-- setManifestid(2222605, "1123507097971278864", 0)

-- Rulers of China (AppID: 2222601) - missing keys for depots: [2222606, 2222606]
-- addappid(2222601)
-- addappid(2222606, 1, "bef2ad041da59d4788214f7a01a3dbf7907819b0f4b591b41ecd1192eb5ffba1") -- Rulers of China - Main Content (excluded with DLC)
-- setManifestid(2222606, "8991379052256751445", 0)
-- addappid(2222606, 1, "bef2ad041da59d4788214f7a01a3dbf7907819b0f4b591b41ecd1192eb5ffba1") -- Rulers of China - Main Content (excluded with DLC)
-- setManifestid(2222606, "8991379052256751445", 0)

-- Rulers of the Sahara (AppID: 2222602) - missing keys for depots: [2222607, 2222607]
-- addappid(2222602)
-- addappid(2222607, 1, "69facab69f9fcda1656500a05d43b6e513b61bf73ea14145fc7aaaf204b94e6e") -- Rulers of the Sahara - Main Content (excluded with DLC)
-- setManifestid(2222607, "3509975586696906669", 0)
-- addappid(2222607, 1, "69facab69f9fcda1656500a05d43b6e513b61bf73ea14145fc7aaaf204b94e6e") -- Rulers of the Sahara - Main Content (excluded with DLC)
-- setManifestid(2222607, "3509975586696906669", 0)

-- Great Builders (AppID: 2222603) - missing keys for depots: [2222608, 2222608]
-- addappid(2222603)
-- addappid(2222608, 1, "232bdf85fd33ab840192f727dcdadb3c5cfd84346446611325acaf6197e204ef") -- Great Builders - Main Content (excluded with DLC)
-- setManifestid(2222608, "2315839665544527598", 0)
-- addappid(2222608, 1, "232bdf85fd33ab840192f727dcdadb3c5cfd84346446611325acaf6197e204ef") -- Great Builders - Main Content (excluded with DLC)
-- setManifestid(2222608, "2315839665544527598", 0)

-- DLCS EXCLUDED (NO DEPOT KEYS, NO DEDICATED DEPOTS)
-- addappid(2222604) -- Rulers of England (no keys available)
-- addappid(2297840) -- Julius Caesar (no keys available)
