-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(2527390) -- Dead Rising Deluxe Remaster
addappid(2527391, 1, "59f5483e65e1b578cfaea1da84860fc0988266ef8f2847637d6f2e9a3d9d3842") -- Depot 2527391
setManifestid(2527391, "6456215729820951574", 62788596273)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITH DEDICATED DEPOTS
-- Dead Rising Deluxe Remaster - Costume  BGM Licker (AppID: 2851890)
addappid(2851890)
addappid(2851890, 1, "051f8d3634eacd7215b22a3690863f2775d426b67f7d391c37ffc149c8129337") -- Dead Rising Deluxe Remaster - Costume  BGM Licker - Depot 2851890
setManifestid(2851890, "2838997632823256607", 306609559)
-- Dead Rising Deluxe Remaster - Costume  BGM Nemesis (AppID: 2851900)
addappid(2851900)
addappid(2851900, 1, "8a1835e29c15ae20fa73a08e65720b370e406d416a4cd2bd8b158227e4f6e9ac") -- Dead Rising Deluxe Remaster - Costume  BGM Nemesis - Depot 2851900
setManifestid(2851900, "6257492098345095446", 296018433)
-- Dead Rising Deluxe Remaster - Costume  BGM Chainsaw Villager (AppID: 2851910)
addappid(2851910)
addappid(2851910, 1, "9ae538cb36e5b31e2a5efc8bb2308e5eac6c092e4821b01681bd8168115b2416") -- Dead Rising Deluxe Remaster - Costume  BGM Chainsaw Villager - Depot 2851910
setManifestid(2851910, "398350625971252437", 545070377)
-- Dead Rising Deluxe Remaster - Costume  BGM Leon S. Kennedy (AppID: 2851920)
addappid(2851920)
addappid(2851920, 1, "7a6cda56c9e45752bd16b58ac73d075e04f37f7abfac654da8544c5581a2654b") -- Dead Rising Deluxe Remaster - Costume  BGM Leon S. Kennedy - Depot 2851920
setManifestid(2851920, "864990538913624128", 399457811)
-- Dead Rising Deluxe Remaster - Costume  BGM Ashley Graham (AppID: 2851930)
addappid(2851930)
addappid(2851930, 1, "2cfb7478360311fb64c9e6345175f6fda29df53216b19304a02449500a5ee2b4") -- Dead Rising Deluxe Remaster - Costume  BGM Ashley Graham - Depot 2851930
setManifestid(2851930, "2603911181444808394", 456655533)
-- Dead Rising Deluxe Remaster - Costume  BGM Chris Redfield (AppID: 2851940)
addappid(2851940)
addappid(2851940, 1, "fe01a976754281d9a58e2ca86f1f35484fb5be574f34e4eeef776062976fc273") -- Dead Rising Deluxe Remaster - Costume  BGM Chris Redfield - Depot 2851940
setManifestid(2851940, "7062497109575588491", 440826406)
-- Dead Rising Deluxe Remaster - Costume  BGM Tron Bonne (AppID: 2851950)
addappid(2851950)
addappid(2851950, 1, "69ee1ce0e7409e225f42465821dad21874700044b9f09d6e4a3f607139005839") -- Dead Rising Deluxe Remaster - Costume  BGM Tron Bonne - Depot 2851950
setManifestid(2851950, "2419054808632570107", 373716113)
-- Dead Rising Deluxe Remaster - Costume  BGM Lan Hikari (AppID: 2851960)
addappid(2851960)
addappid(2851960, 1, "a18fba1a2a938c18ed2f67b2316c1ad92e1fd884a14a6d22d00203d7710405cf") -- Dead Rising Deluxe Remaster - Costume  BGM Lan Hikari - Depot 2851960
setManifestid(2851960, "5808332576450104912", 442018339)
-- Dead Rising Deluxe Remaster - Costume  BGM Mega Man (AppID: 2851970)
addappid(2851970)
addappid(2851970, 1, "ae39d9f711c0054dfdee6e9da63e534cecf9b775e644d7da0022c8017879c133") -- Dead Rising Deluxe Remaster - Costume  BGM Mega Man - Depot 2851970
setManifestid(2851970, "5078903814512049183", 405126168)
-- Dead Rising Deluxe Remaster - Costume  BGM Sheriff (AppID: 2851980)
addappid(2851980)
addappid(2851980, 1, "3734b60984f2f19e7ac3cbf143f6ccd9179e615a25a2f7e3e6f6259c5bad3d8a") -- Dead Rising Deluxe Remaster - Costume  BGM Sheriff - Depot 2851980
setManifestid(2851980, "464154117115304242", 575674264)
-- Dead Rising Deluxe Remaster - Costume  BGM Clown (AppID: 2851990)
addappid(2851990)
addappid(2851990, 1, "16f7e64bbe2c99e6ab01f0a922d238b3329a1079e247e29811a1ecc6834c3a71") -- Dead Rising Deluxe Remaster - Costume  BGM Clown - Depot 2851990
setManifestid(2851990, "5062492328189608909", 425805633)
-- Dead Rising Deluxe Remaster - Costume  BGM War Photographer (AppID: 2852000)
addappid(2852000)
addappid(2852000, 1, "394d0e18c09d3e077bc69acbd973f7e4b0ac7f6a1347bc8409f5e216e769df30") -- Dead Rising Deluxe Remaster - Costume  BGM War Photographer - Depot 2852000
setManifestid(2852000, "6259717719910700149", 560138206)
-- Dead Rising Deluxe Remaster - Costume  BGM Creepy Rabbit (AppID: 2852010)
addappid(2852010)
addappid(2852010, 1, "3f99da66c79385012ead7db222f9b014596ab6aa6c95723ad1e3fa8beb5bfbb1") -- Dead Rising Deluxe Remaster - Costume  BGM Creepy Rabbit - Depot 2852010
setManifestid(2852010, "6016870974612061480", 243507989)
-- Dead Rising Deluxe Remaster - Costume  BGM Ken (AppID: 2852020)
addappid(2852020)
addappid(2852020, 1, "d7324bee6c82e7315392c72e905a8824a8d32df44faaf6050f90f924957bafda") -- Dead Rising Deluxe Remaster - Costume  BGM Ken - Depot 2852020
setManifestid(2852020, "2065756047348261848", 387830901)
-- Dead Rising Deluxe Remaster - Costume  BGM Blodia (AppID: 2852030)
addappid(2852030)
addappid(2852030, 1, "a0a05dc7ee0a017f074d2793448c4f161be8a20ab9c4af0846d5229e0e8aaed5") -- Dead Rising Deluxe Remaster - Costume  BGM Blodia - Depot 2852030
setManifestid(2852030, "647773269646878164", 487484675)
-- Dead Rising Deluxe Remaster - Costume  BGM Sodom (AppID: 2852040)
addappid(2852040)
addappid(2852040, 1, "bd6be2e6c4111b1fcaff2954da650db7ee03e3a0ff254521ba4c4375a845b674") -- Dead Rising Deluxe Remaster - Costume  BGM Sodom - Depot 2852040
setManifestid(2852040, "7839605775619642180", 465999150)
-- Dead Rising Deluxe Remaster - Costume  BGM Rikuo (AppID: 2852050)
addappid(2852050)
addappid(2852050, 1, "dfbc8ff76b92a0e7179f6efa67cc30b81ab6ee0a42f61da04e41e1825b2b27b6") -- Dead Rising Deluxe Remaster - Costume  BGM Rikuo - Depot 2852050
setManifestid(2852050, "36152520200139785", 292796079)
-- Dead Rising Deluxe Remaster - Costume  BGM Chuck Greene (AppID: 2852060)
addappid(2852060)
addappid(2852060, 1, "217699cde5a6f1b7e34481d957a325083aaf4e7bb52c629ae15b324d07469ff2") -- Dead Rising Deluxe Remaster - Costume  BGM Chuck Greene - Depot 2852060
setManifestid(2852060, "9055433864757893131", 472537689)
-- Dead Rising Deluxe Remaster - Costume  BGM Frank West 2006 (AppID: 2852070)
addappid(2852070)
addappid(2852070, 1, "db1c1d520c631d3a5e8a3d9e68c3c76540e98efcee75a666b0713b47f2f2ef46") -- Dead Rising Deluxe Remaster - Costume  BGM Frank West 2006 - Depot 2852070
setManifestid(2852070, "5005999552293999557", 54479461)
-- Dead Rising Deluxe Remaster - Costume  BGM Willamette Parkview Mall Bee (AppID: 2852080)
addappid(2852080)
addappid(2852080, 1, "c265f1c11629dd4f9a3d9f88c9d19c81fcd862cbcd6ef87afd0c553b94a79da1") -- Dead Rising Deluxe Remaster - Costume  BGM Willamette Parkview Mall Bee - Depot 2852080
setManifestid(2852080, "2980245427778872051", 302172060)