-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy

-- MAIN APPLICATION
addappid(3644120) -- Drunkn Bar Fight 2

-- MAIN APP DEPOTS
addappid(3644121, 1, "ef4113aaca0c50106c11746998e28dedd2ae833ba7eb9b6d6808d4abdbc71709") -- Depot 3644121
setManifestid(3644121, "4561987009138242487", 0)
