addappid(1495320)
addappid(228989)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1495321,0,"ca5070e2afd6a9665bbb4aaf33a228a623ac43c0c7b7a001a618a7cfcb2f6b53")
setManifestid(1495321,"4230704629318245812")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]