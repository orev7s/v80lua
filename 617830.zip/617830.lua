-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(617830) -- SUPERHOT VR

-- MAIN APP DEPOTS
addappid(617831, 1, "0d91b281f03773c142f8de489fdaa74c01946fd911e8cdf8ec81944393f210bf") -- SUPERHOT VR Content
setManifestid(617831, "7374925464745743374", 0)
