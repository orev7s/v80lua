-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(2116120) -- Incursion Red River
-- MAIN APP DEPOTS
addappid(2116121, 1, "8f80a1590d1be6bfdde9c800499b420fe786838c27c69a6572bbb75c85c48007") -- Depot 2116121
setManifestid(2116121, "4814876084224084700", 68676410451)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Incursion Red River - Supporter Edition (AppID: 3405150)
addappid(3405150)
addappid(3405150, 1, "66466595306f5647e00fca5435234afc25e2a2f757c1ab2d550917767e80b71e") -- Incursion Red River - Supporter Edition - Depot 3405150
setManifestid(3405150, "1887001357310105880", 29395505140)