-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(3408110) -- Cafemart Simulator

-- MAIN APP DEPOTS
addappid(3408111, 1, "2aef89bb87db60712d3e2c4b11326e22d215f62e1d19aca2105194e14dc865ac") -- Main Game Content (Windows Content)
setManifestid(3408111, "3114528197298818245", 0)

-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "550968249685141759", 0)
