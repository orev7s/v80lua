-- Made By @F1uxin
-- MAIN APPLICATION
addappid(3355800) -- Bank Simulator

-- MAIN APP DEPOTS
addappid(3355801, 1, "fabe54fdaf7a5a04910f223f36584ebb24fee7c50fa79167e55c6c5fcb1ecfa2") -- Main Game Content (Windows Content)
setManifestid(3355801, "8772994643005934085", 0)
