-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(829110) -- LEGO® DC Super-Villains

-- MAIN APP DEPOTS
addappid(829111, 1, "bffdf69eda1959abed59053ab3e64b4c9e29431a1921fbe24f3ece9d0334a6ba") -- Codename Diana Content
setManifestid(829111, "2704021274070142807", 0)
addappid(829112, 1, "8ff64a54da610801c615ff3ff1be0f4a51e673bd836b069b67b95cee0144fb3a") -- M - Diana Content
setManifestid(829112, "6568150567208105510", 0)
addappid(829113, 1, "fb92c59701e1ca1939739f6f9a53ef05757c81ee48c3b8b2c96336aa34654085") -- M - Diana Data
setManifestid(829113, "7064888161945058332", 0)

-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- DC Super-Villains TV Character Pack (AppID: 870271)
addappid(870271)
addappid(870271, 1, "41c32185773a4da7c59f045ce243cbed292e8d61c080b794881605d235188bd7") -- DC Super-Villains TV Character Pack - DC Super-Villains TV Series Character Pack (870271) Depot
setManifestid(870271, "9022694666871621338", 0)
addappid(829114, 1, "5b90d2b53b8ce1ff9eeab55aef6665d98a2737116b1d555884878e23ffe07add") -- DC Super-Villains TV Character Pack - Mac - DC Super-Villains TV Series Character Pack (870271)
setManifestid(829114, "6508832694875362777", 0)

-- DC Super Heroes TV Character Pack (AppID: 870272)
addappid(870272)
addappid(870272, 1, "ad1085ba5ca9f1eb2943cc33949b681105386e3c4529f3a4692af1ce5b0871d8") -- DC Super Heroes TV Character Pack - DC Super Heroes TV Series Character Pack (870272) Depot
setManifestid(870272, "9123239751044486737", 0)
addappid(829115, 1, "fa1124f0c55b14c485885c9abfc6e95c79c5c1f34f94fcdcf392d58d80e5d2de") -- DC Super Heroes TV Character Pack - Mac - DC Super Heroes TV Series Character Pack (870272)
setManifestid(829115, "7255825339039448898", 0)

-- Justice League Dark Character Pack (AppID: 870273)
addappid(870273)
addappid(870273, 1, "ab3b14da59c55a2b78d4308299aa334b0ae1b262c54a1fb8f050c39e8f7863e5") -- Justice League Dark Character Pack - Justice League Dark (870273) Depot
setManifestid(870273, "6019917751173088415", 0)
addappid(829116, 1, "2883672f457318347f1f8983be13476c3f0a9ea1c0dec88fb012ee8c2327409e") -- Justice League Dark Character Pack - Mac - Justice League Dark (870273)
setManifestid(829116, "5597196538648195862", 0)

-- LEGO Aquaman Movie LevelPack1 (AppID: 870274)
addappid(870274)
addappid(870274, 1, "0208ff88e2e45ed98ec3afdd05a027761b4d18dfc3cd14bd7a6aba3db64d39cb") -- LEGO Aquaman Movie LevelPack1 - Aquaman Movie Pack Part 1 (870274) Depot
setManifestid(870274, "5288679075935559631", 0)
addappid(829117, 1, "fff02eeabd2cb4158b0fe7028a0f0ded92b1704be22af8f187bdef578995857f") -- LEGO Aquaman Movie LevelPack1 - Mac - Aquaman Movie Pack Part 1 (870274)
setManifestid(829117, "2212603186511104734", 0)

-- LEGO DC Super-Villains Aquaman Pack2 (AppID: 870275)
addappid(870275)
addappid(870275, 1, "be35a5d5451201e5d902d44b0222023b79aa99b880760d5d0b0c6bfd36358318") -- LEGO DC Super-Villains Aquaman Pack2 - Aquaman Movie Pack Part 2 (870275) Depot
setManifestid(870275, "1931946879256919564", 0)
addappid(829118, 1, "48588b827e7573c1dc6b460a59bea93e99c148ec12da79abc8b9264d7749f277") -- LEGO DC Super-Villains Aquaman Pack2 - Mac - Aquaman Movie Pack Part 2 (870275)
setManifestid(829118, "6451769703018694872", 0)

-- LEGO DC Super-Villains DC Movies Character Pack (AppID: 870276)
addappid(870276)
addappid(870276, 1, "19e1c49521be2a12e107b1a6cd41273589b07b3e68038bf4220ea4bd75e4de66") -- LEGO DC Super-Villains DC Movies Character Pack - DC Movie Character Pack (870276) Depot
setManifestid(870276, "4170844032711227266", 0)
addappid(829119, 1, "256edc15066508ccabd1dd95708c046a26d98ddacf747c42c5ee2c564f03264c") -- LEGO DC Super-Villains DC Movies Character Pack - Mac - DC Movie Character Pack (870276)
setManifestid(829119, "8314248493600402178", 0)

-- Young Justice Animated Series (AppID: 870277)
addappid(870277)
addappid(870277, 1, "85157d5d5f3f011ea937df03a40e339db77bd1caea6a0b7efa2366e593c87cd4") -- Young Justice Animated Series - Young Justice (870277) Depot
setManifestid(870277, "3503999892560145053", 0)
addappid(870281, 1, "01cc52496243541dba479056085bbf85c61ac9d0c12751ea2e81572a2f74a24b") -- Young Justice Animated Series - Mac - Young Justice (870277)
setManifestid(870281, "2969361232286576084", 0)

-- Shazam Movie Part 1 (AppID: 870278)
addappid(870278)
addtoken(870278, "5831838884386602089")
addappid(870278, 1, "f670c191f21f1df8c7ba01b30e5c8ea7df339b80762f9d370f0a21901d87fcf4") -- Shazam Movie Part 1 - Shazam Movie Part 1 (870278) Depot
setManifestid(870278, "4312959754939475023", 0)
addappid(870282, 1, "b04911ee5067d2aeaafa9670b00a71f16ae454f92e4081338c7d6b48ffb479fa") -- Shazam Movie Part 1 - Mac - Shazam Movie Part 1 (870278)
setManifestid(870282, "6667436434394516827", 0)

-- Shazam Movie Part 2 (AppID: 870279)
addappid(870279)
addappid(870279, 1, "17f9dede1a1b71803c6a62e1aedd096808667343d5fa5db0a5c63f52eea2abb1") -- Shazam Movie Part 2 - Shazam Movie Part 2 (870279) Depot
setManifestid(870279, "4562348699473461231", 0)
addappid(870283, 1, "c646a4af37d425011e8ea7329bd4f32775422f620f8bb0bf72d0e09d6a6fa823") -- Shazam Movie Part 2 - Mac - Shazam Movie Part 2 (870279)
setManifestid(870283, "2800404343208665838", 0)

-- LEGO DC Super-Villains Batman The Animated Series Level Pack (AppID: 870280)
addappid(870280)
addappid(870280, 1, "72c5cca36388320bcede8961b67cfa8d9cfcdfabbb2b8f3f56c09fc75b7685c9") -- LEGO DC Super-Villains Batman The Animated Series Level Pack - Batman: The Animated Series (870280) Depot
setManifestid(870280, "3239102658030218594", 0)
addappid(870284, 1, "ac9e5913721ae68752f32c3c73da2ea9bfdd7b2e5cf4626c32a75eaf5f40121e") -- LEGO DC Super-Villains Batman The Animated Series Level Pack - Mac - Batman: The Animated Series (870280)
setManifestid(870284, "3415393238007018439", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(870270) -- Season Pass

-- DLCS EXCLUDED (NO DEPOT KEYS, NO DEDICATED DEPOTS)
-- addappid(949220) -- LEGO DC Super-Villains Aquaman BundlePack (no keys available)
-- addappid(949221) -- Shazam Movie Level Pack Bundle (no keys available)
