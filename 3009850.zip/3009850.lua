-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(3009850, 1, "9fdd8cb4b86c7cc5c3e572479c6d1a0275b0e5ae7901fcba8d3026389f9be9cc") -- Hard Time III

-- MAIN APP DEPOTS
addappid(3009851, 1, "e92020d15750f186520ea5132e8c28e25b77f4d583725fc957e734ab28503e12") -- Depot 3009851
setManifestid(3009851, "8196664056774574318", 0)
