addappid(1609080)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1609081,0,"39dd98df1ed684811bc0483ce6a7b480650d5a95c554c2a3dda45d96440667e9")
setManifestid(1609081,"9187437588763131545")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]