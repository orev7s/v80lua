addappid(1030830)
addappid(1030831, 1, "32530b6455aff62129bdca96b7eade4476d7d5aa76a6233563dca1ccad754475")
setManifestid(1030831, "7075325167535131973", 0)
addappid(1523211, 1, "6111b2e3d21efa5e5b26a91f75ff32d12aa8c5bb547c4d0215eda184a7f4c49b")
setManifestid(1523211, "1298223493515886904", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]