addappid(1027820)
addappid(1027821,0,"e0041d8e846b6baabf2214988f78dbc49a631d0e2b3c3447fdde44faf39376ce")
setManifestid(1027821,"4900973496237441332")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]