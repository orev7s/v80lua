addappid(1295270)
addappid(1295271,0,"c0b81b40affc02eb3db6b3a40a61b3acc73b1e46e2c1bb8add8b791cf5e7e6fa")
setManifestid(1295271,"5063445221643174445")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]