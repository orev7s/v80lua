addappid(1932570)
addappid(1932571,1,"d4a7c4e08fc111d9981aa1f767ad9ab90508e704065a302f6a77c7a1be0a5b66")
setManifestid(1932571,"3015365205437167019")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]