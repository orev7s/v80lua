addappid(1184760)
addappid(1184761,0,"b56b55a34487abef1582fb59076f21be023fe8ee57cf7a4198cf33ab2a742a7a")
setManifestid(1184761,"3082942023982083429")
addappid(1184762,0,"1a8af630a226181d500504942c25926928755397f197ea6832117ace6353d6a9")
setManifestid(1184762,"8792631856655911189")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]