addappid(1582650)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1582651,0,"419f9adaf16540ae360fc0bad35397458eefb5fa98ad7051de87780ca12f2283")
setManifestid(1582651,"7956572748710427530")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]