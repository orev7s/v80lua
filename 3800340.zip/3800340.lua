-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @F1uxin on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!)

-- MAIN APPLICATION
addappid(3800340) -- ScootX

-- MAIN APP DEPOTS
addappid(3800341, 1, "2ab21efa32d5093ab0c39f5ddfe5d945bd30dc0d0d0ed1ce2d6a382f406e7f9b") -- Depot 3800341
setManifestid(3800341, "3871396235248121620", 0)
