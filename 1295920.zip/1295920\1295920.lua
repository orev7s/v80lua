addappid(1295920)
addappid(1295921,0,"6b61d645efde65dcb14c38641fec46ad7296e8fc2ae9343a376f37c5031850b0")
setManifestid(1295921,"4542599156815205049")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]