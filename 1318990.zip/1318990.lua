-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @f1uxin on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy / https://discord.gg/m8PxjTwrnv
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(1318990) -- Web Host Simulator
-- MAIN APP DEPOTS
addappid(1318994, 1, "989dfb3e420943fe3a8f62484c63568c5d81945734df171a6ad999e9302ac8aa") -- Depot 1318994
setManifestid(1318994, "1922970636688324581", 514912623)