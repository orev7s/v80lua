addappid(2104890)
addappid(2104891,0,"7aae8e21e13a76d7d261e23592399805131dbb2dc4678b5c40b335e6f131b3a7")
setManifestid(2104891,"6682696923648315772")




--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]