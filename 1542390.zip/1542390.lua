-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(1542390) -- Monolith
-- MAIN APP DEPOTS
addappid(1542391, 1, "2bff4f81fef6251818e5a5ad66f5bbc2a07903fe18a658e9aa156200143b3fe4") -- Depot 1542391
setManifestid(1542391, "3030908205503219353", 4303920459)
addappid(1542392, 1, "4781e7399ed421e69701e97c4c2600cafe32749578635513dccb91fe4aa04f17") -- Depot 1542392
setManifestid(1542392, "1726254763842878655", 4322272221)