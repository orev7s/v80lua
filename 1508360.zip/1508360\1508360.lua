addappid(1508360)
addappid(1508361,0,"e056af6a4e8595f2dc2af4ab35dcd5c1649a2e455425d7e6a3c487db7ca9b310")
setManifestid(1508361,"6038270911226586404")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]