-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(611670) -- The Elder Scrolls V: Skyrim VR

-- MAIN APP DEPOTS
addappid(611671, 1, "1954b005f098c0b728ffb025193b3cd158a0ba414cd1313f1f71dbc3b216944d") -- Skyrim VR base
setManifestid(611671, "3877383290467193767", 0)
addappid(611672, 1, "0d43fb9c02f61aed4427e57f6c3eeb9a22e962e4033bd574e55226ad7c9e55d7") -- Skyrim VR content
setManifestid(611672, "1928013110065929089", 0)
addappid(611673, 1, "4dd9d036679051aff33806421299a6c57d9f0ad211fafb4ef0641f4eda78cc6a") -- Skyrim VR exe
setManifestid(611673, "4815482462544068657", 0)
addappid(611674, 1, "ea7729849ef0a50c02974a4504e1ac1305ffadf535a75b8b5224f5c120a480a3") -- Skyrim VR french
setManifestid(611674, "1870271470279661303", 0)
addappid(611675, 1, "1fd3a8b3181b2e684cf7814083761b3341015519b4f665bd775e4eef9d770771") -- Skyrim VR italian
setManifestid(611675, "1030179458833278956", 0)
addappid(611676, 1, "59af015d179fd6576fc79e0da544c1bbbdd7e6f3e0c722554c6398a2274f2833") -- Skyrim VR german
setManifestid(611676, "8886890815580383395", 0)
addappid(611677, 1, "10aa4916b4b0c966876d347dcc12705cdf9fda7b34306bbad419d95a9fbc2379") -- Skyrim VR spanish
setManifestid(611677, "1677132629223966488", 0)
addappid(611678, 1, "48df4e99974a616f9d53a1ad0fa49d70aab24e0d51464120d4f85f5def9835b4") -- Skyrim VR polish
setManifestid(611678, "2469242488019796501", 0)
addappid(611679, 1, "fa3ef8074babacd54f4d400f9d26c0e708a9bad78dc36204f0a133e95144fdf7") -- Skyrim VR russian
setManifestid(611679, "865322299747175442", 0)
addappid(824120, 1, "1131768d48658f75a1c23ddc045ec6b28cb7e50f15327d99b08dfe6875ce30b4") -- Skyrim VR trad-chinese
setManifestid(824120, "7631913855644462826", 0)
addappid(824121, 1, "711a8e4a21f9720cb6beb933566b382543c8fe5e4a328e4efdb70397f6c66bba") -- Skyrim VR - japanese
setManifestid(824121, "8068773427951618792", 0)

-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
