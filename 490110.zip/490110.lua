-- Made By @F1uxin
-- MAIN APPLICATION
addappid(490110) -- The Precinct

-- MAIN APP DEPOTS
addappid(490111, 1, "44bcc3870bf156385e37ff47e71ae28824fa905a542cdc8eaf05715799f78fc2") -- Main Game Content (Windows Content)
setManifestid(490111, "3207207635747331100", 0)

-- DLCS EXCLUDED (NO DEPOT KEYS, NO DEDICATED DEPOTS)
-- addappid(3240070) -- The Precinct Soundtrack (no keys available)
