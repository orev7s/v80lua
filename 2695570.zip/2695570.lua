-- Made by f1uxin, please read the read me TXT file
addappid(2695570)
addappid(2695571,0,"45055cb777941c2a8648fa0823935affbd3d7e4eb93d62ce2e4289608414f55e")
setManifestid(2695571,"1341008708681182767")
