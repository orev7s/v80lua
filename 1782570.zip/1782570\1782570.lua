addappid(1782570)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1782571,0,"928a51fe69d7cbcda7c24322219e8a0b7bd9174e28b20acb40eeb0815a3f63d7")
setManifestid(1782571,"6543790568184172603")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]