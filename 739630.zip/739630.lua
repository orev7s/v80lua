-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(739630, 1, "6850686ca304da94d7b1a8ebd9203bcf007712610dc92eb9452e22a31b6b823d") -- Phasmophobia

-- MAIN APP DEPOTS
addappid(739631, 1, "a0af61717bae449e5db4a1cc6eb68d7604ac3a8e05ff5226faa14b5be67d640c") -- VR_Project Content
setManifestid(739631, "2474426265434908391", 0)

-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 0)
