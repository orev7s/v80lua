addappid(1456760)
addappid(1456761,0,"b8bc2cde1ecb6eaf6683921c1879482515b41e3483909370a39729920b7e45c2")
setManifestid(1456761,"2917292735709856245")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]