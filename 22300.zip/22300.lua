-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(22300) -- Fallout 3

-- MAIN APP DEPOTS
addappid(22301, 1, "d0f52e722d1c619a329d2f7dd5e6a76f158e5dc61863ea68afa769f28bb46bc5") -- Fallout 3 content
setManifestid(22301, "2329076020665736242", 0)
addappid(22305, 1, "c55375825a26b701e374f0464eb4f46df4598e2dded9c370743fd58465801134") -- Fallout 3 low violence
setManifestid(22305, "7317209574589268", 0)
addappid(22302, 1, "885f40da257277ed486f99d850bb436fae72600ab219b809c841a8a1a57a0056") -- Fallout 3 Spanish
setManifestid(22302, "8612756459633379896", 0)
addappid(22303, 1, "9f798ad44fe9751d4f591a640f6ea3acf2d94ebda52e989d987aa683c2ca2b00") -- Fallout 3 French
setManifestid(22303, "2652129166773567697", 0)
addappid(22304, 1, "936c4976113e12c1a4f9e0a68a068d6fefc336892da6a0da6f6dfd86cf9ca4e8") -- Fallout 3 German
setManifestid(22304, "5280050595742785365", 0)
addappid(22306, 1, "6603a7efbd402a2018624f51e270e5c528c33f92cf2877202e9cdd01b9f57e00") -- Fallout 3 Italian
setManifestid(22306, "8896170106365657868", 0)
addappid(22404, 1, "129fa095f9979af1483ffcc49ed988aa59a4f94501ef76c51709c32238ddc0f8") -- Fallout 3 Spanish Operation Anchorage
setManifestid(22404, "3877437033700030049", 0)
addappid(22414, 1, "5576c33b90d2762e9465822a2a14330875881f631fef9ac80a9b33b690c9920f") -- Fallout 3 Spanish Broken Steel
setManifestid(22414, "5488403124754598315", 0)
addappid(22424, 1, "d8f094f21600bc15d9e971bc494fa1e04cf496ca6e64dff43bcefbbdfa54ead0") -- Fallout 3 Spanish The Pitt
setManifestid(22424, "6219885424239218661", 0)
addappid(22434, 1, "84aa0515be2a1806a0d102f7e354e26c7515566768ffb1a3885dd11ee00c84c8") -- Fallout 3 Spanish Mothership Zeta
setManifestid(22434, "2159329771730419636", 0)
addappid(22444, 1, "db08d81b1030aad23f1e00f5de03c370de6e2a49fa0eb04d4a44f20c19fdf99e") -- Fallout 3 Spanish Point Lookout
setManifestid(22444, "6143960173608211454", 0)

-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Fallout 3 - Operation Anchorage (AppID: 22400)
addappid(22400)
addappid(22400, 1, "b31b61cea7216a06c34a60727c5e137806508d6dabe368a45baaa8c5963550e0") -- Fallout 3 - Operation Anchorage - Fallout 3 - Operation: Anchorage
setManifestid(22400, "699843849040938104", 0)

-- Fallout 3 - Broken Steel (AppID: 22410)
addappid(22410)
addappid(22410, 1, "4178973be6a2c1644ba166b8cb3a81c385c343127e9b59e4487a4008ad29b1ec") -- Fallout 3 - Broken Steel - Fallout 3 - Broken Steel
setManifestid(22410, "1848668152774282356", 0)

-- Fallout 3 - The Pitt (AppID: 22420)
addappid(22420)
addappid(22420, 1, "c772851ae9aba8e29e32422cd53d7495130a70d5afffbfaa8807ade697034cce") -- Fallout 3 - The Pitt - Fallout 3 - The Pitt
setManifestid(22420, "2788937135207952237", 0)

-- Fallout 3 - Mothership Zeta (AppID: 22430)
addappid(22430)
addappid(22430, 1, "af9fc2294e0d2630ecda5f448cf808b983d0510d43484e26fbf676670da8f063") -- Fallout 3 - Mothership Zeta - Fallout 3 - Mothership Zeta
setManifestid(22430, "6374078947564922635", 0)

-- Fallout 3 - Point Lookout (AppID: 22440)
addappid(22440)
addappid(22440, 1, "7b64db37214ba2e02aeebf7979695068e879821d6baa6f10ace95ff6fe0a576a") -- Fallout 3 - Point Lookout - Fallout 3 - Point Lookout
setManifestid(22440, "1414355692444715444", 0)

-- Fallout 3 - Soundtrack (AppID: 461150)
addappid(461150)
addappid(461150, 1, "a4f8cbdd8bf43bc36b880710ff9bdafd378d3686cf8fa7f6ef277f39bbc3caed") -- Fallout 3 - Soundtrack - Fallout 3 - Soundtrack (461150) Depot
setManifestid(461150, "6263313154763130481", 0)
