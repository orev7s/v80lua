-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(418370) -- Resident Evil 7 Biohazard

-- MAIN APP DEPOTS
addappid(418371, 1, "2df4ede71de8b8163daa12dbd679f25b89c131c806485d93fba323e47a2d8eb3") -- RESIDENT EVIL 7 biohazard
setManifestid(418371, "2875836326402428050", 0)
addappid(418372, 1, "5ffba65b1aa063765d2dec7582c23b09661a6b361fa9657a2508ab2f5fb15be5") -- BIOHAZARD 7 resident evil
setManifestid(418372, "2988871419767868150", 0)

-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Banned Footage Vol.1 (AppID: 529930)
addappid(529930)
addappid(529930, 1, "f05d0430d570b49933e26bdf148b52ff2b68676636afc882087ed81b826de455") -- Banned Footage Vol.1 - DLC 1（WWD） (529930) 個のデポ
setManifestid(529930, "1885029655974643736", 0)

-- Survival Pack A (AppID: 530590)
addappid(530590)
addappid(530590, 1, "06f0d9d9de44f84a3f255e0a3f500152f680761eb95e3cc2187947df324c0f80") -- Survival Pack A - Survival Pack A (530590) 個のデポ
setManifestid(530590, "2821452161378484140", 0)

-- Survival Pack C (AppID: 530592)
addappid(530592)
addtoken(530592, "137849144737045535")
addappid(530592, 1, "b877d348297442a4a20326c8eb10445ac7061410396c429e453ef38a1666fb68") -- Survival Pack C - Survival Pack C (530592) 個のデポ
setManifestid(530592, "5193083539346488075", 0)

-- A Coin  Hard Mode (AppID: 530595)
addappid(530595)
addappid(530595, 1, "f532e1f9272faaca708b0d54b4aa86b9b5bfccfb61c1376c6e984e2be6cdee4f") -- A Coin  Hard Mode - A Coin & Hard Mode (530595) 個のデポ
setManifestid(530595, "4096306864002722519", 0)

-- B Coin  Hard Mode (AppID: 530596)
addappid(530596)
addappid(530596, 1, "05b334a227cbe67d789998bbdd2ab7726b891a1d7deff5349cb4938bc6304487") -- B Coin  Hard Mode - B Coin & Hard Mode (530596) 個のデポ
setManifestid(530596, "2437844440160457168", 0)

-- C Coin  Hard Mode (AppID: 530597)
addappid(530597)
addappid(530597, 1, "5f791b96cace35bd231db330435ad45b3f3a608805f020a0add4f5c116193f4b") -- C Coin  Hard Mode - C Coin & Hard Mode (530597) 個のデポ
setManifestid(530597, "6364590930435507576", 0)

-- D Coin  Hard Mode (AppID: 530598)
addappid(530598)
addappid(530598, 1, "01cd6f3745501d469f6193aa99becb7244a4b293031b09365d07e4f419c606d3") -- D Coin  Hard Mode - D Coin & Hard Mode (530598) 個のデポ
setManifestid(530598, "3874000828551471378", 0)

-- E Coin  Hard Mode (AppID: 530599)
addappid(530599)
addappid(530599, 1, "acc89294725ca72de44fa2e7d060e1479794516963c1aa999c03df609dbd372f") -- E Coin  Hard Mode - E Coin & Hard Mode (530599) 個のデポ
setManifestid(530599, "2633628331817827169", 0)

-- Banned Footage Vol.2 (AppID: 530610)
addappid(530610)
addappid(530610, 1, "cc5848d208a6436651fa7875afd740c71bf799b0cc61e1677f7156ba27178e41") -- Banned Footage Vol.2 - DLC 2（WWD） (530610) 個のデポ
setManifestid(530610, "8797633140491138315", 0)
addappid(418375, 1, "75ef17978e6091765555cc1c2fe83e7886cfe49121baa935e8e0b80b6fe98e3e") -- Banned Footage Vol.2 - DLC2(K)
setManifestid(418375, "5278038220232861179", 0)

-- End Of Zoe (AppID: 530611)
addappid(530611)
addappid(530611, 1, "32a01ec16f26a30cfbb8a309e864b0f6e22a2af0324100f0561857dcd8964e5d") -- End Of Zoe - DLC 3（WWD） (530611) 個のデポ
setManifestid(530611, "6056753254666249273", 0)

-- Not A Hero (AppID: 564190)
addappid(564190)
addappid(564190, 1, "3e28043753fe610017111a39a7a80aac705b7cfcddb1c420d50f388e6ea0b0b1") -- Not A Hero - CP8（WWD） (564190) 個のデポ
setManifestid(564190, "30059815315701992", 0)
addappid(418376, 1, "ad6230311dea128611a7f6616e116755175138b3a505a4e371a8a7e8f45ad437") -- Not A Hero - CP8(JP)
setManifestid(418376, "1861368551167317490", 0)
addappid(418377, 1, "2376c48c0daa86e1edabafd112cf1be3c96aad06d1b7df745ec4b8580f4c0775") -- Not A Hero - CP8(K)
setManifestid(418377, "1544223621847730578", 0)

-- Resident Evil 7 biohazard Original Soundtrack (AppID: 583810)
addappid(583810)
addappid(583811, 1, "36e7b1016079bfb946e7c59b7677949091a517cd03587caa603dcfc20f17b28e") -- Resident Evil 7 biohazard Original Soundtrack - Resident Evil 7 biohazard Original Soundtrack [MP3 V0]
setManifestid(583811, "8253221820533898039", 0)
addappid(583812, 1, "3cdde1e07a57728e52fdf3a16629160e3aa1a91141a1c068863a9cbb0d726ed0") -- Resident Evil 7 biohazard Original Soundtrack - Resident Evil 7 biohazard Original Soundtrack [MP3 320]
setManifestid(583812, "966416827336040689", 0)
addappid(583813, 1, "06419bb48cfc02165a531e9b917670688fa0f96ec65913c5b435822b7d7e9bb3") -- Resident Evil 7 biohazard Original Soundtrack - Resident Evil 7 biohazard Original Soundtrack [FLAC 16-bit]
setManifestid(583813, "8960716292059363130", 0)
addappid(583814, 1, "3347d5c4d50c459dd2a6c76a4c9681cf06dcbf4476558efaba51c37490587d06") -- Resident Evil 7 biohazard Original Soundtrack - Resident Evil 7 biohazard Original Soundtrack [FLAC 24-bit]
setManifestid(583814, "7287749018283110606", 0)
addappid(583815, 1, "aaa2750460ed1409918a573753cf810acc13c670297d8ea6bd8b63a32c3b0f15") -- Resident Evil 7 biohazard Original Soundtrack - Resident Evil 7 biohazard Original Soundtrack [AAC]
setManifestid(583815, "1679476974014982504", 0)
addappid(583816, 1, "78ed9f0075ada547c58d79794bd965b4b19627d652196c4e9d1105aa150cff65") -- Resident Evil 7 biohazard Original Soundtrack - バイオハザード7 レジデント イービル オリジナル・サウンドトラック [MP3 V0]
setManifestid(583816, "1715021259447610288", 0)
addappid(583817, 1, "e775b88948beb9658f34d018a3fd48dac5776f4cbc8b2b0a07a19734fa818c09") -- Resident Evil 7 biohazard Original Soundtrack - バイオハザード7 レジデント イービル オリジナル・サウンドトラック [MP3 320]
setManifestid(583817, "7987493839995406587", 0)
addappid(583818, 1, "f4a1c744ce7a4d5ba7144025a7da2f9151a85884548b737d0f2a397440b6fbe1") -- Resident Evil 7 biohazard Original Soundtrack - バイオハザード7 レジデント イービル オリジナル・サウンドトラック [FLAC 16-bit]
setManifestid(583818, "6399794036426392597", 0)
addappid(583819, 1, "1d8620f6837e7b32f5eece01135b457123c6285f34e1eaa914586e2212a629dd") -- Resident Evil 7 biohazard Original Soundtrack - バイオハザード7 レジデント イービル オリジナル・サウンドトラック [FLAC 24-bit]
setManifestid(583819, "7943629174887838133", 0)
addappid(1233910, 1, "0d12b58407b173a09f242a91ff4027d998dbc52c93c143fd3f37e83f35163cd6") -- Resident Evil 7 biohazard Original Soundtrack - バイオハザード7 レジデント イービル オリジナル・サウンドトラック [AAC]
setManifestid(1233910, "4494750808554982374", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(540340) -- Resident Evil 7 - Season Pass
addappid(584960) -- RESIDENT EVIL 7 biohazard - Original Soundtrack (FLAC)
