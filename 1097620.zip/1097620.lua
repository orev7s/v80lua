-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪username - f1uxin, on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy / https://discord.gg/m8PxjTwrnv
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(1097620, 1, "e90c4d87817a4d2fcb7d5e3c85f285fe39791bd4763d1137c90536ddda8afade") -- Fast and Low
-- MAIN APP DEPOTS
addappid(1097621, 1, "6100da7a3d68eac914d9479b7a776d917e688cc1414b490021096bc2a1bb64cb") -- Fast and Low Content
setManifestid(1097621, "8276173981620097733", 5962430785)