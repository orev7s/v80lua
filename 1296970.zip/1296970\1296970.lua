addappid(1296970)
addappid(1296971,0,"1ca19bbb94e75de41dd8c52d6acf85d530be62d83f53f5b49a833126237bf7fb")
setManifestid(1296971,"5902019715534820874")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]