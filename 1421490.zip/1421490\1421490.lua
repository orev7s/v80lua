addappid(1421490)
addappid(228989)
addappid(1421491,0,"4c96fc77e80893f97175c55d238caa7a765baccf22cfacce856d510565a99a8c")
setManifestid(1421491,"5287422744090859401")
addappid(1421492,0,"23e0a537b2489a3466936cfdfdd60bd99d40ab67b8e259b9986c164b94d7ba45")
setManifestid(1421492,"353744201225818277")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]