-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(950400) -- Blame him

-- MAIN APP DEPOTS
addappid(950401, 1, "abebdee05d57d7bff538be01db0c472222c5fd3e214a1532fc137f25f3d20da8") -- Blame her Content
setManifestid(950401, "7484443896825327840", 0)
