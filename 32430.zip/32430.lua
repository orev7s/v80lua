-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(32430) -- STAR WARS™: The Force Unleashed™ Ultimate Sith Edition

-- MAIN APP DEPOTS
addappid(32431, 1, "08e72d82ccbe91f8b72fba69ac16cc191f170115c6a908ac75de67300260fb0f") -- star_wars_force_unleashed_content
setManifestid(32431, "7086741752643505745", 0)
addappid(32433, 1, "ce3f009e72c14f745a9dd1a491a9e29c663cd811ac634bedd52e58d210f3a678") -- SWTFU-Mac-Content
setManifestid(32433, "4034928732234361858", 0)
addappid(32434, 1, "41c1df521f64b622f4d0e2eedacddb1fe8be41f9da778143b22aa8380704c512") -- SWTFU-Mac-App
setManifestid(32434, "3832244542025695403", 0)
