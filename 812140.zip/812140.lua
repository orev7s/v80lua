-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy

-- MAIN APPLICATION
addappid(812140) -- Assassin's Creed Odyssey

-- MAIN APP DEPOTS
addappid(812141, 1, "0d69b986695af676b593ce6d217a24a47bceeb630dbd8ac61eaba88b72a17819") -- Main Content
setManifestid(812141, "7369859942329036273", 0)
addappid(812142, 1, "500a7b45788ab393ea848fa1f13f8c94450e34112be4f429c609035df4d6e1e9") -- French Audio
setManifestid(812142, "8328691686092249446", 0)
addappid(812143, 1, "ef150f7bac4d1776428bdbf22cbc466a706c94ca3fad3e52fc3f04640d9e6445") -- Brazilian Portuguese Audio
setManifestid(812143, "7207703417476497678", 0)
addappid(812144, 1, "a3c5e18d19e59d43ac841bfb47696527a5df28c7f00bc487ad1209bdf62c919a") -- German Audio
setManifestid(812144, "7568168263952342688", 0)
addappid(812145, 1, "e7987355e75005a3427ea9f492931e4d3dcc3fead917205b3f8559e2d5460db6") -- Italian Audio
setManifestid(812145, "8450177789687634985", 0)
addappid(812146, 1, "e6a983014e43104c1ce2cba18939b39f80e80c1d4c38dbaaf00867d3f6f244a6") -- Russian Audio
setManifestid(812146, "6975128233689020437", 0)
addappid(812147, 1, "1f216a1ed4582aedcd215d44fd522d5712e7c4078d336e9fddf229439cb1ac15") -- Spanish Audio
setManifestid(812147, "8756573802222983569", 0)
addappid(812148, 1, "c86367c01d5724d576682c66d4ba21c57a3524633d185a5bf0cbf3fa9629c545") -- Japanese Audio
setManifestid(812148, "3408766981981870757", 0)

-- SHARED DEPOTS (from other apps)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
setManifestid(1716751, "818295193716041715", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Assassins Creed Odyssey - Legacy of the First Blade (AppID: 937891)
addappid(937891)
addappid(857154, 1, "83d52bd1470d31e15675f56ebe3ebcc33aca78389e03609658453f0bbab533bd") -- Assassins Creed Odyssey - Legacy of the First Blade - Legacy of the first blade (part 1)
setManifestid(857154, "6682327947305864699", 0)
addappid(857155, 1, "3090e98acd394b0fd68186d871834bf36b3f01f272c974a9f18c7b0d89289750") -- Assassins Creed Odyssey - Legacy of the First Blade - Legacy of the first blade (part 2)
setManifestid(857155, "3258680875590795254", 0)
addappid(857156, 1, "955d65e60433b66a7635ab199e725571f2c649893471f79840cde33a687cf9e8") -- Assassins Creed Odyssey - Legacy of the First Blade - Legacy of the first blade (part 3)
setManifestid(857156, "2300917583245418327", 0)

-- Assassins Creed Odyssey - The Fate of Atlantis (AppID: 937892)
addappid(937892)
addtoken(937892, "15850730603638221170")
addappid(857158, 1, "8be9361fa307daedc4a4162a88f195938dce6a248d9fe399ceea1fa2d66a1dd4") -- Assassins Creed Odyssey - The Fate of Atlantis - Tales of Atlantis (part 2)
setManifestid(857158, "2111558703979014825", 0)
addappid(857159, 1, "e2d4b3e65d688551d5b3a00e3f337d4f3d4ba560523a57ce9333c03d26219f19") -- Assassins Creed Odyssey - The Fate of Atlantis - Tales of Atlantis (part 3)
setManifestid(857159, "4985956972222534239", 0)

-- Assassins Creed Odyssey - Fields of Elysium (AppID: 1109770)
addappid(1109770)
addappid(857157, 1, "322b49c10e633b78fd5e37cc8ef9cf5f8eb4b000472ab38228b068a9921eceb2") -- Assassins Creed Odyssey - Fields of Elysium - Tales of Atlantis (part 1)
setManifestid(857157, "5671725767919675728", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(857150) -- Assassins Creed Odyssey - Preorder Standard - Uplay Activation
addappid(857151) -- Assassins Creed Odyssey - Preorder Deluxe - Uplay Activation
addappid(857152) -- Assassins Creed Odyssey - Preorder Gold - Uplay Activation
addappid(857153) -- Assassins Creed Odyssey - Preorder Ultimate - Uplay Activation
addappid(907610) -- Assassins Creed Odyssey - Standard - Uplay Activation
addappid(907611) -- Assassins Creed Odyssey - Deluxe - Uplay Activation
addappid(907613) -- Assassins Creed Odyssey - Gold - Uplay Activation
addappid(907614) -- Assassins Creed Odyssey - Ultimate - Uplay Activation
addappid(933010) -- Assassins Creed Odyssey - Season Pass  Uplay Activation
addappid(933011) -- Assassins Creed Odyssey - Legacy of the First Blade  Uplay Activation
addappid(933012) -- Assassins Creed Odyssey - The Fate of Atlantis  Uplay Activation
addtoken(933012, "6760411481530335580")
addappid(937890) -- Assassins Creed Odyssey - Season Pass
addappid(1113150) -- Assassins Creed Odyssey - Free DLC 2.1 - Uplay Activation
addappid(1254000) -- Assassins Creed Odyssey - Free weekend ownership
addappid(1254010) -- Assassins Creed Odyssey - Full Game ownership
addtoken(1254010, "16051304276878572945")
