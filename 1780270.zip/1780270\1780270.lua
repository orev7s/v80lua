addappid(1780270)
addappid(1780271,0,"822c8b3e340ec700ba50fc790c9c54896197e796fa2f745cbd991cd82a9e960c")
setManifestid(1780271,"8416547880961926110")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]