-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy

-- MAIN APPLICATION
addappid(552520) -- Far Cry 5

-- MAIN APP DEPOTS
addappid(552521, 1, "941abe7976a0b28d302442645dd45aeff4a92808b351906d5341cc9928dd1fdd") -- temp Content
setManifestid(552521, "8965279101697150481", 0)
addappid(643857, 1, "fff270ed617a6a03b5c89610cbec4ceac7e4f03658c65ad702e7bab4ab04cc12") -- Far Cry 5 English
setManifestid(643857, "5272481886350375515", 0)
addappid(552522, 1, "74a72dd270bdcf9413516071c930c71a093f2bd0ff6f0370619e36dd3af605f7") -- Far Cry 5 Brazilian
setManifestid(552522, "663453966566387216", 0)
addappid(552523, 1, "337c9883c0abea9d644bc57a39726413db04279c872286fd9cf47b8d03a6d3f7") -- Far Cry 5 French
setManifestid(552523, "4051639157773472698", 0)
addappid(552524, 1, "669f40330d7fd6434cce00fed29c04e7e006227b4d423c050b537f5c92341d45") -- Far Cry 5 German
setManifestid(552524, "9177661898334819167", 0)
addappid(552525, 1, "15ecba77e47273f7dc186ec750e2660ee90c27c57d9ac81d2fc82403b06b1244") -- Far Cry 5 Italian
setManifestid(552525, "34117454520629984", 0)
addappid(552526, 1, "e1431f7ce02ee881d43bf75fadc76be28f7321d0610dd36aec90ba888892c336") -- Far Cry 5 Japanese
setManifestid(552526, "6358593642057803988", 0)
addappid(552527, 1, "7afb60d9946b6e8bee79c5972164b757e0fb09a28c88d818d4b875a2d1f2190c") -- Far Cry 5 Spanish
setManifestid(552527, "8698831239768813057", 0)
addappid(552528, 1, "e9ea523b975fa96f51abd42eb284be630b4a79159c4ea37d00d34b5767bb5ab6") -- Far Cry 5 Russian
setManifestid(552528, "8620862225036627409", 0)

-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 0)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- .NET 3.5 Redist (Shared from App 228980)
setManifestid(229000, "4622705914179893434", 0)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- .NET 4.5.2 Redist (Shared from App 228980)
setManifestid(229004, "5220958916987797232", 0)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- .NET 4.6 Redist (Shared from App 228980)
setManifestid(229005, "7992454656023763365", 0)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
setManifestid(1716751, "818295193716041715", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Far Cry 5 - Lost on Mars (AppID: 761820)
addappid(761820)
addtoken(761820, "14681857404498689519")
addappid(761820, 1, "98bacdde1712e2f8417583fb6b6fb2c2baf9c2a722e7adfb20bb0e60450db9e2") -- Far Cry 5 - Lost on Mars - Far Cry 5 - Mars (761820) Depot
setManifestid(761820, "2545214878384794380", 0)
addappid(763821, 1, "2fb99e22ccea2c54daf1a28bd4600540495307d24afa2d1627b291063d4c25b3") -- Far Cry 5 - Lost on Mars - Far Cry 5 Mars English
setManifestid(763821, "5798107504181173828", 0)
addappid(763822, 1, "94262fe43fc8135c74a90f7fa0ca23770f2e9e0839855366f6dcc1725de4e456") -- Far Cry 5 - Lost on Mars - Far Cry 5 Mars Brazilian
setManifestid(763822, "8610894077677042877", 0)
addappid(763823, 1, "7a422a4a13dc9ae4a9236e0491c16d445e90150dcf954b08c861c64529e4848c") -- Far Cry 5 - Lost on Mars - Far Cry 5 Mars French
setManifestid(763823, "7241860453021330036", 0)
addappid(763824, 1, "b59e6ec4fea275a654946576d9bbbc598894dcee0f14029e320a9ed773a12383") -- Far Cry 5 - Lost on Mars - Far Cry 5 Mars German
setManifestid(763824, "9059379376526556968", 0)
addappid(763825, 1, "3d39f7de6b8f138eea310b73525ecc5761fcf4d534326734e4888b1f18ec3bd1") -- Far Cry 5 - Lost on Mars - Far Cry 5 Mars Italian
setManifestid(763825, "5615771465837311702", 0)
addappid(763826, 1, "64b8c5a314796e15acf0e80e04275b979bafc82369b85b64ffe765f9025bc878") -- Far Cry 5 - Lost on Mars - Far Cry 5 Mars Japanese
setManifestid(763826, "8220163018283470515", 0)
addappid(763827, 1, "309f85afad901fa8cf8305e14e02f6f9c65639fb93c1ce72cbd972bb67fc971d") -- Far Cry 5 - Lost on Mars - Far Cry 5 Mars Spanish
setManifestid(763827, "7667932027403316147", 0)
addappid(763828, 1, "fcaa0d4b0d9249ce7116a60e2490634f53c9b4b98a5b3bf454fa5796e6c718bb") -- Far Cry 5 - Lost on Mars - Far Cry 5 Mars Russian
setManifestid(763828, "9123334093001751284", 0)

-- Far Cry 5 - Hours of Darkness (AppID: 761821)
addappid(761821)
addtoken(761821, "5284535117382526942")
addappid(761821, 1, "db4ce18aba3aa1810b256c19273d764525612689d00707af7e5afbd3c4f8cde7") -- Far Cry 5 - Hours of Darkness - Far Cry 5 - Vietnam (761821) Depot
setManifestid(761821, "6786887464288860602", 0)
addappid(761824, 1, "ceb0ccf442fde02470050a9ef2b45f70a948769acf06f5fa0ffbb1a97cfd7218") -- Far Cry 5 - Hours of Darkness - Far Cry 5 Vietnam English
setManifestid(761824, "8243048617070152687", 0)
addappid(761825, 1, "f8a5414239cba2f46cdaf66b0c1da20647abd5c854a302db3486a006389d85a4") -- Far Cry 5 - Hours of Darkness - Far Cry 5 Vietnam Brazilian
setManifestid(761825, "7995029197434014273", 0)
addappid(761826, 1, "f6345588472b31561d44479604e64c29b009d5b6a435631182eee3bc80827b22") -- Far Cry 5 - Hours of Darkness - Far Cry 5 Vietnam French
setManifestid(761826, "7879826585126109365", 0)
addappid(761827, 1, "78c1538ef7dc2e18dac6b948ddc8f34824f6f5b4c9da038fc0157f0648c45b34") -- Far Cry 5 - Hours of Darkness - Far Cry 5 Vietnam German
setManifestid(761827, "6175534544942389636", 0)
addappid(761828, 1, "b15ba89cd3288cdb0a57eb409b5d9e44b2418b494e9f24e40c71bf05713ac06f") -- Far Cry 5 - Hours of Darkness - Far Cry 5 Vietnam Italian
setManifestid(761828, "7820109186986903857", 0)
addappid(761829, 1, "218fd7386ed9d2c9b3e7a14252aa3be843d956e7d44a52458b60c02a8a4ff660") -- Far Cry 5 - Hours of Darkness - Far Cry 5 Vietnam Japanese
setManifestid(761829, "8692547962058359784", 0)
addappid(643856, 1, "32ab422b969508efb491eaab97eac88283831622546a6014053743fb2990c97e") -- Far Cry 5 - Hours of Darkness - Far Cry 5 Vietnam Spanish
setManifestid(643856, "5424890830496165377", 0)
addappid(643858, 1, "771b6bbb7ef79bdaebef1ade3dc8d30463e2ce675d9e1a0601f73b0a027e5efd") -- Far Cry 5 - Hours of Darkness - Far Cry 5 Vietnam Rusiian
setManifestid(643858, "7407458576740880998", 0)

-- Far Cry 5 - Zombies (AppID: 874610)
addappid(874610)
addtoken(874610, "6597978076628574405")
addappid(874610, 1, "1ea844ce276d065e245e7534d2dc2c248d1b00c6834685fac76471bce45311ee") -- Far Cry 5 - Zombies - Far Cry 5 - Zombies (874610) Depot
setManifestid(874610, "8539017273179371602", 0)

-- Far Cry 5 - HD textures pack (AppID: 903840)
addappid(903840)
addappid(552529, 1, "07b602181357ccc09efa0edf2bd9f5543e03e5a9642c82360a22b09db89df7c8") -- Far Cry 5 - HD textures pack - Far Cry 5 HD textures pack
setManifestid(552529, "8763824218821042009", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(643850) -- Far Cry 5 - WW Standard Preorder - Uplay Activation
addappid(643851) -- Far Cry 5 - RU-CN Standard Preorder - Uplay Activation
addappid(643852) -- Far Cry 5 - WW Deluxe Preorder - Uplay Activation
addappid(643853) -- Far Cry 5 - RU-CN Deluxe Preorder - Uplay Activation
addappid(643854) -- Far Cry 5 - WW Gold Preorder - Uplay Activation
addappid(643855) -- Far Cry 5 - RU-CN Gold Preorder - Uplay Activation
addappid(761822) -- Far Cry 5 - Lost on Mars Uplay Activation
addappid(761823) -- Far Cry 5 - Hours of Darkness Uplay Activation
addappid(763820) -- Far Cry 5 - Season Pass
addappid(817060) -- Far Cry 5 - Season Pass - Uplay Activation
addappid(823960) -- Far Cry 5 - Standard Edition - Uplay Activation
addappid(823970) -- Far Cry 5 - Deluxe Edition - Uplay activation
addappid(823980) -- Far Cry 5 - Gold edition - Uplay Activation
addappid(823981) -- Far Cry 5 - Deluxe Pack - Uplay Activation
addappid(823990) -- Far Cry 5 - Deluxe Pack
addappid(874611) -- Far Cry 5 - Zombies Uplay Activation
addappid(1716580) -- Far Cry 5 - Full Game ownership
addtoken(1716580, "11036179696305668927")
addappid(1716581) -- Far Cry 5 - Free weekend ownership
