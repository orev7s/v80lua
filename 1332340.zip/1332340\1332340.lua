addappid(1332340)
addappid(1332341, 1, "4299a87965c6fa8f20880c1225607076c95cae50666d2ee56b9a19d5cc3e7da2")
setManifestid(1332341, "3593477581239036899", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]