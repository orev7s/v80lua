addappid(1560250)
addappid(1560252,0,"f3f6f6db116ce81041fc3f358582e5ad09e76e9b0c54dd65b85851ef11bce0e9")
setManifestid(1560252,"6009539091938380650")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]