-- Made by f1uxin, please read the read me TXT file.
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship
addappid(2248760) -- Car For Sale Simulator 2023

-- MAIN APP DEPOTS
addappid(2248761, 1, "7e322b4c38775f33754204b8cb08844982412cd9d4b140906cfff0047a9b2843") -- Depot 2248761
setManifestid(2248761, "942708118981086903", 0)

-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(2679810) -- Car For Sale Simulator 2023 - Super Sports (unreleased)
-- addappid(3400430) -- Car For Sale Simulator 2023 - PickUp & SUV (unreleased)
