addappid(1926520)
addappid(228989)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1926521,0,"8d99afff8971c840af514a5901f2195b6fd5fabb00d1beaa89d547fe2b297787")
setManifestid(1926521,"3415996051761944131")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]