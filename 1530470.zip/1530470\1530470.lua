addappid(1530470)
addappid(1530471,0,"59a219e71bf3bffe8b6f329ae250dec7fbd1d09db31e21bffd5c5f8f95b66def")
setManifestid(1530471,"4915849220534126323")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]