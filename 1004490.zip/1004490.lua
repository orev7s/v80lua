-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(1004490) -- Tools Up!

-- MAIN APP DEPOTS
addappid(1004491, 1, "1293fb9fd26fdaf27c67385704ccc255168787779beb45a309b36725506f778e") -- Tools Up! Content
setManifestid(1004491, "7683747812532859775", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Tools Up Garden Party  Season Pass (AppID: 1408620)
addappid(1408620)
addappid(1408620, 1, "41a759a74c136baa213c5512785cd204cb0d9c54d927f5a73443c434769992e2") -- Tools Up Garden Party  Season Pass - Tools Up! Garden Party – Season Pass (1408620) Depot
setManifestid(1408620, "5904890169833865056", 0)

-- Tools Up Garden Party - Episode 1 The Tree House (AppID: 1415430)
addappid(1415430)
addappid(1415430, 1, "b830a4da289437fc1c3ebb420d7756aa8e5effef5ad0418456dc52c97657686b") -- Tools Up Garden Party - Episode 1 The Tree House - Tools Up! Garden Party - Episode 1: The Tree House (1415430) Depot
setManifestid(1415430, "4237597664100428700", 0)

-- Tools Up Garden Party - Episode 2 Tunnel Vision (AppID: 1415440)
addappid(1415440)
addappid(1415440, 1, "a60ea3c7b87ab327b7535028f03fbd04708bade9885a64d4d564ba5d5a9ccf28") -- Tools Up Garden Party - Episode 2 Tunnel Vision - Tools Up! Garden Party - Episode 2: Tunnel Vision (1415440) - magazyn zawartości
setManifestid(1415440, "340514984383026726", 0)

-- Tools Up Garden Party - Episode 3 Home Sweet Home (AppID: 1415450)
addappid(1415450)
addappid(1415450, 1, "4048f396cd7081d42d0c676d2b8638563dad10a46309dd84d93049fbb9911870") -- Tools Up Garden Party - Episode 3 Home Sweet Home - Tools Up! Garden Party - Episode 3: Home Sweet Home (1415450) - magazyn zawartości
setManifestid(1415450, "8836853490041576741", 0)
