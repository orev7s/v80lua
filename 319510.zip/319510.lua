-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(319510) -- Five Nights at Freddy's

-- MAIN APP DEPOTS
addappid(319511, 1, "1c9bdb805e961c88bff8090d7a3047fc4932948393b4a0d0939cc84ccbe542c4") -- Five Nights at Freddy's Content
setManifestid(319511, "685265219366152400", 0)
