-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(3376250) -- Nine-Ball Roulette

-- MAIN APP DEPOTS
addappid(3376251, 1, "b8e4a7ce69ae5aef69562f43522ae837dd6bb3b36efb3a3d923d874afa21397d") -- Depot 3376251
setManifestid(3376251, "5505971277173534705", 0)
