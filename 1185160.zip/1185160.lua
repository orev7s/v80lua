-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(1185160) -- Inunaki Tunnel | 犬鳴トンネル

-- MAIN APP DEPOTS
addappid(1185161, 1, "98384b4e59f2b0ac92e774182750741b0192d520c99684d87e28feae073993a7") -- Inunaki Tunnel | 犬鳴トンネル Content
setManifestid(1185161, "8150101208894534041", 0)
