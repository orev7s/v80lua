-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(1782460) -- Hell Clock

-- MAIN APP DEPOTS
addappid(1782461, 1, "b87981e090ab2ad89c7a18d14898061157db6a1ed5fb03d5e9f0546d734399ce") -- Depot 1782461
setManifestid(1782461, "6599977978206439836", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3774890) -- Hell Clock Supporter Pack Edition
addappid(3859500) -- Hell Clock Supporter Pack Upgrade

-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Hell Clock Soundtrack (AppID: 3893120) - missing depot keys
-- addappid(3893120)
