-- Made by f1uxin, please read the read me TXT file
addappid(2138720)
addappid(2138721,0,"c1a2b9eea7346395b175b2d8458f566dcabe83b99822111d3446a5ce377bdc52")
setManifestid(2138721,"8814656720822723498")
