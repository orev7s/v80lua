-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(337350) -- Flywrench

-- MAIN APP DEPOTS
addappid(337351, 1, "ae470c63abd7359546f9634e05f5571b241cc9f63741e778e89f944e84dc9530") -- Flywrench Content
setManifestid(337351, "5729365923544328578", 0)
addappid(337352, 1, "db0b2bf4af15e86a8d0f191ca8f283debaccdb18ba49474413b6326ca5687fe0") -- Flywrench Mac
setManifestid(337352, "8309755705839771426", 0)
addappid(337353, 1, "cd49aee180c18e9f849611a2346a005d1f7181d49d0390e891c7c33808ea313a") -- Flywrench Linux
setManifestid(337353, "4561823368062184214", 0)

-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
