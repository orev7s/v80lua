-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(3769130) -- Keep on Mining!
-- MAIN APP DEPOTS
addappid(3769131, 1, "79dda683e39e3551788e59192e005fe2d8b3e5f3f3adecacf712b638a9e732b3") -- Depot 3769131
setManifestid(3769131, "5850267657624917866", 289203122)
-- DLCS WITH DEDICATED DEPOTS
-- Keep on Mining - Pickaxe skins SUPPORT PACK (AppID: 3862020)
addappid(3862020)
addappid(3769132, 1, "4143d4c98337ddcbaa5a9c74444b143a9204495eca185108b268a76f237de3a6") -- Keep on Mining - Pickaxe skins SUPPORT PACK - Depot 3769132
setManifestid(3769132, "1869520104454938729", 289203122)