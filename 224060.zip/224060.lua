-- Made by f1uxin, please read the read me TXT file
-- MAIN APPLICATION
addappid(224060) -- Deadpool

-- MAIN APP DEPOTS
addappid(224061, 1, "1b95dccb34463613e917735aaf08d1b525b8fe739dd85d3cb537aa551f9d949f") -- Binaries
setManifestid(224061, "902441342317572401", 0)
addappid(224062, 1, "cd62e1cfd5835f6de15a9aa435e3455605e4ee68c7d2df31eb255270b9b3d54a") -- Content
setManifestid(224062, "8163029659755953523", 0)
addappid(224063, 1, "c57f5d7b7446a66b6f6c7ff9bb60551c0809b868795918e136f58376bd79c59f") -- Content ENU
setManifestid(224063, "3104057046075596770", 0)
addappid(224064, 1, "9a34418503b802045b1178d6a831be163ab3cd057546d8d88fd875910dfbe2d3") -- Content FRA
setManifestid(224064, "9034951943485147947", 0)
addappid(224065, 1, "0dfecfe02c8e2e523d2ed028b56eea20b65310d104a0f4065cb21f7ebf414a10") -- Content DEU
setManifestid(224065, "5966443289890992442", 0)
addappid(224066, 1, "10f70d5182a1e769914588edfe5efed38b18f6d6fb0594757db61d5212b695bb") -- Content ITA
setManifestid(224066, "3402381215480815", 0)
addappid(224067, 1, "d367fc2230da5fa8fb9a73d884537089bbf9202d48379488999b0f9909b04055") -- Content ESP
setManifestid(224067, "8633549531911463504", 0)
addappid(224068, 1, "4ad7e48bc90a77adba68585a791b30f1009235deefd725dea7e597e599e6ae34") -- Content RUS
setManifestid(224068, "7079399129514840253", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(237151) -- Deadpool - Merc with a Map Pack
