-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(2395260) -- Midnight Shift

-- MAIN APP DEPOTS
addappid(2395261, 1, "29c2b2e9bb5e0f1fdf802c71052622c6907ff977f461f3768eb8ccfe402fea24") -- Depot 2395261
setManifestid(2395261, "8731994298596628", 0)
