-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(4069520)
addappid(4069521,0,"7e03356de28c147831a4c06ff74efaa4af6dbeafdfffa371069c5635bd41cf00")
