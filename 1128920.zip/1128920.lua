-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(1128920) -- EVERSPACE™ 2

-- MAIN APP DEPOTS
addappid(1128921, 1, "4fb55ad1df336278e71c3e9a335c0363bb35b6e0f494a94c99191bfbadc8eb0f") -- EVERSPACE™ 2 Content
setManifestid(1128921, "735055807809773736", 0)
addappid(1128922, 1, "ff9edec770843a8d63f9a1aba47498ac0f23a8b40c8f999fbc2ee734f06362aa") -- Depot 1128922
setManifestid(1128922, "2676565006000094732", 0)
addappid(1128923, 1, "4527c674a543e15dd06218ee6b3bb80c44ceb6d511e84b1380c1607746f3a0ab") -- Depot 1128923
setManifestid(1128923, "4021497237423968422", 0)

-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- The Art of EVERSPACE 2 (AppID: 2606620)
addappid(2606620)
addappid(2606620, 1, "dd34c19620ea950a13a0d544896d8b542a704267f1fbb307077f0569d8f621a0") -- The Art of EVERSPACE 2 - Depot 2606620
setManifestid(2606620, "195865514797556095", 0)

-- EVERSPACE 2 - Titans (AppID: 2873460)
addappid(2873460)
addappid(2873460, 1, "c503ae9096190326103167eba0703865863e047bb2850a9a016c969f05c3a948") -- EVERSPACE 2 - Titans - Depot 2873460
setManifestid(2873460, "7225401587094450400", 0)
addappid(2873461, 1, "f30d18ec58a88269a037f070d5aac60ae6645b33aed71ab5f16623dee9ef6667") -- EVERSPACE 2 - Titans - Depot 2873461
setManifestid(2873461, "3354458671497130421", 0)

-- EVERSPACE 2 - Wrath of the Ancients (AppID: 2873470)
addappid(2873470)
addappid(2873470, 1, "2d9d9a57c798d640f00003a21902422a198ee76116a02fda8c648592b3de41a1") -- EVERSPACE 2 - Wrath of the Ancients - Depot 2873470
setManifestid(2873470, "6170837278021773362", 0)

-- EVERSPACE 2 - Supporter Pack (AppID: 2911770)
addappid(2911770)
addappid(2911771, 1, "fcc79fa32e1c48f07cd511999e2ae33b829c3194fc3b2af04c6c1e43d4c0299e") -- EVERSPACE 2 - Supporter Pack - Depot 2911771
setManifestid(2911771, "6223906961600506367", 0)

-- The Art of EVERSPACE 2 - Ancients and Titans (AppID: 3690840)
addappid(3690840)
addappid(3690840, 1, "ae6779c8530cc504d9cc7aa323be0a83630fb576a93051800b3b38f4a6ae6ddf") -- The Art of EVERSPACE 2 - Ancients and Titans - Depot 3690840
setManifestid(3690840, "1523801439398253059", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2915570) -- EVERSPACE 2 - Alienware Ship Skin
