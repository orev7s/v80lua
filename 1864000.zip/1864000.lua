-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @f1uxin on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy / https://discord.gg/m8PxjTwrnv
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(1864000) -- Artis Impact
-- MAIN APP DEPOTS
addappid(1864001, 1, "9eccab235dfb23018531ba20ea2bb82f2b197494f54abad326278360bf8c8fc1") -- Depot 1864001
setManifestid(1864001, "492630100847085637", 2882301878)