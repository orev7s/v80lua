-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪username - f1uxin, on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy / https://discord.gg/m8PxjTwrnv
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(220440) -- DmC Devil May Cry

-- MAIN APP DEPOTS
addappid(220441, 1, "aed2b190f9b8ea15e6f1e22aed2d339f162f17b8673f06124dd11e1ea45b11be") -- DmC Devil May Cry Content
setManifestid(220441, "8660867655925405335", 0)
addappid(220442, 1, "390e4902a68f3b732b8e42fe6fe3ccea44c54c19421e21eaa9860842c26fa973") -- DmC Devil May Cry Content LV
setManifestid(220442, "8284177927415320138", 0)

-- DLCS WITH DEDICATED DEPOTS
-- DmC Devil May Cry Costume Pack (AppID: 223790)
addappid(223790)
addappid(223790, 1, "84ed6b57c32b4629f5cc2274674cb95f00d4b65d067170bb9a2f0ba4ffbd76a6") -- DmC Devil May Cry Costume Pack - DmC Devil May Cry DanteOryginalDLC
setManifestid(223790, "7654700979379588386", 0)

-- DmC Devil May Cry Weapon Bundle (AppID: 223792)
addappid(223792)
addappid(223792, 1, "8ca028cec8d61d9c12f8ea45f546d2c50f66aa8a2ddbda601a042ab68e909b0a") -- DmC Devil May Cry Weapon Bundle - DmC Devil May Cry WeaponsBundleDLC
setManifestid(223792, "5445163040217040808", 0)

-- DmC Devil May Cry Vergils Downfall (AppID: 223793)
addappid(223793)
addappid(223793, 1, "e839ea49e739fb933e04b272dedc90509e470ad48ad698e48433772c64ef86fd") -- DmC Devil May Cry Vergils Downfall - DmC Devil May Cry VergilsDownfallDLC WW
setManifestid(223793, "4639589247481781479", 0)

-- DmC Devil May Cry Bloody Palace Mode (AppID: 229080)
addappid(229080)
addappid(229080, 1, "2d5f510f44b55ffd17e3fe6d09bba6d2751544fd151293553fa4466dea0660ef") -- DmC Devil May Cry Bloody Palace Mode - Dmc Devil May Cry BloodyPalaceDLC WW
setManifestid(229080, "1173515098563360562", 0)

-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- DmC Devil May Cry Golden Pack (AppID: 223791) - missing depot keys
-- addappid(223791)
-- DmC Devil May Cry Vergils Downfall (Japan) (AppID: 223794) - missing depot keys
-- addappid(223794)
