addappid(1170060)
addappid(1170061,0,"5ced70d72fc2bc820942dc3667d1b99c1035da06c16793c20b9c3eba2306cbf9")
setManifestid(1170061,"8443382881645681621")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]