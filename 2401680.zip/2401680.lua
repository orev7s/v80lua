-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(2401680) -- Pet Shop Simulator

-- MAIN APP DEPOTS
addappid(2401681, 1, "db42f98ce5b346b2b30380411f5affe0c398cc0902195210ede5408abcd8da82") -- Main Game Content (Windows Content)
setManifestid(2401681, "5141030563288626807", 0)
