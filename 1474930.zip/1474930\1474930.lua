addappid(1474930)
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(1474931,0,"9ebe45ec36b6017e74fbffec6a0f5877792ef03b356231266a2e8503a72f999b")
setManifestid(1474931,"3945061257070616144")
addappid(3581920)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]