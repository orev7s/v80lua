-- Made by f1uxin, please read the read me TXT file
-- MAIN APPLICATION
addappid(2881650) -- Content Warning

-- MAIN APP DEPOTS
addappid(2881651, 1, "def8422fa7589f4d65aa2cbbb21d623f10e3ad941e695558651289920c89c1d9") -- Main Game Content (Windows Content)
setManifestid(2881651, "4763499704581700907", 0)
