addappid(1701380)
addappid(1701381, 1, "5ede11afc34e5817f9bcd980c734f0d066ba884f4e2eab022daef9b44f66c0b2")
setManifestid(1701381, "5885776156854458887")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]