addappid(1915380)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1915381,0,"7a8eb0ea6b14c163b1032bc4fd042146b492d7e9f44067fe78e291058b28a9ac")
setManifestid(1915381,"8277375476641274344")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]