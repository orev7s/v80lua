-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(296830) -- Lucius II

-- MAIN APP DEPOTS
addappid(296831, 1, "8d6e19a7ddee087cc9ecc030b4e54be0c65f87d9d0f833a472f5579be9b962f6") -- Lucius II Depot
setManifestid(296831, "6790248121765624399", 0)
addappid(296832, 1, "a604868a76f3de549fe84b620e024969acbef9d6b815b2734c7e64b6c01e1bb5") -- Lucius II Linux Depot
setManifestid(296832, "3498301544859864467", 0)

-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS EXCLUDED (NO DEPOT KEYS, NO DEDICATED DEPOTS)
-- addappid(821030) -- Lucius II - Soundtrack (no keys available)
