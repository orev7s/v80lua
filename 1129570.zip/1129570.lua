-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(1129570) -- Industry Giant 4.0
-- MAIN APP DEPOTS
addappid(1129571, 1, "935ab3832e28a8b5f78e186f4fe8c126614978599d03ccc079bfcb638d5c26cf") -- Depot 1129571
setManifestid(1129571, "3783362147524845927", 14015065447)
addappid(1129572, 1, "0d775dff9ac37058d65a83ffc37683eefeb59f4f75c3532a7521bd0b13d0e6b2") -- Depot 1129572
setManifestid(1129572, "6240189635197075233", 6709817)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITH DEDICATED DEPOTS
-- Industry Giant 4.0 - Digital Supporter Pack (AppID: 3225390)
addappid(3225390)
addappid(3225390, 1, "1b0d7f0259e77baed39b0ea0bdcd7207bc9e70452ff1e34d95858a78c18dffe0") -- Industry Giant 4.0 - Digital Supporter Pack - Depot 3225390
setManifestid(3225390, "7131817753326613103", 21647012)
-- Industry Giant 4.0 - Official Guide (AppID: 3265360)
addappid(3265360)
addappid(3265360, 1, "5e0c11cbb73a2b13463f8371493e7d790c38d40aa5569cb8162e27e2ca6247c4") -- Industry Giant 4.0 - Official Guide - Depot 3265360
setManifestid(3265360, "7533600506520075449", 49632636)