-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(611660) -- Fallout 4 VR

-- MAIN APP DEPOTS
addappid(611661, 1, "6389d687c5eef617aaaab319dfcd957cd30805cfcf8478f7498751fad8a02ad0") -- Fallout 4 VR Base
setManifestid(611661, "8855914008840078851", 0)
addappid(748772, 1, "bacd16a6db3f9236c9f7cb7460fe743dde353475f8202e20a4c1d9e5039cee4b") -- Fallout 4 VR Content
setManifestid(748772, "6853555613453562821", 0)
addappid(611662, 1, "e32560a05ea334d8d14efafdc822f6f33215a1ffb32eeac467a6b38781bd83ab") -- Fallout 4 VR EXE
setManifestid(611662, "2607440145941621789", 0)
addappid(611663, 1, "074f3aefb02e99526af673c123091dddbc98f3f069df02314d83c7a9cfdc539e") -- Fallout 4 VR French
setManifestid(611663, "5982953010917093797", 0)
addappid(611664, 1, "575dec48ecb313daad2d472631f3223ea39af1463cb84eea1e8d254a59fa3031") -- Fallout 4 VR Italian
setManifestid(611664, "2132914617517307231", 0)
addappid(611665, 1, "2e577849e0123dc85d67a8cbdbff45f0f04512cebb46760d2a231f92ba05c364") -- Fallout 4 VR German
setManifestid(611665, "192621487731533611", 0)
addappid(611666, 1, "d2cc5a43e5e2dbd549cb7286768313a77767d9cb6cfcac8ec7f278d2036b1c35") -- Fallout 4 VR Spanish
setManifestid(611666, "4536125018843112911", 0)
addappid(611667, 1, "a1c52d4d713c3c6c262b1c0204d739f0db333d2a480b06edd522694b20883c08") -- Fallout 4 VR Polish
setManifestid(611667, "8939398803369569689", 0)
addappid(611668, 1, "e69016c22c3cc9bff58d9b1ffaf4b62660ca4673af83eb392abe7c3cca07d783") -- Fallout 4 VR Russian
setManifestid(611668, "7037362188323175968", 0)
addappid(611669, 1, "a529c989210056b9773213319da57097b36cc9bba8a32879ea766193b9436adf") -- Fallout 4 VR PT-BR
setManifestid(611669, "224361152182972890", 0)
addappid(748770, 1, "b2b5531454bb49e218a12cbd3065537cc17b030ea2e3580897ba0037c71a2abb") -- Fallout 4 VR Japanese
setManifestid(748770, "2462286988041989275", 0)
addappid(748771, 1, "d3fb064f37c1a08fdd29210549673fe1255b210c4200fe544c5a80c837fdee82") -- Fallout 4 VR TCH
setManifestid(748771, "1892399916080160947", 0)

-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
