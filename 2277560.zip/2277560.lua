-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(2277560, 1, "5a45ebe9e985f6ea27f4be004ba5af9d317bd2242c20008cea7060fb5651844d") -- WUCHANG: Fallen Feathers
-- MAIN APP DEPOTS
addappid(2277561, 1, "6db3af8b5be3def24c758a005feb7fa0f65750716392328e2f14321340adb273") -- Depot 2277561
setManifestid(2277561, "2647147609698210830", 48402445061)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3653760) -- WUCHANG Fallen Feathers - Full-Grown Red Mercury
addappid(3653770) -- WUCHANG Fallen Feathers - Glistening Red Mercury
addappid(3653780) -- WUCHANG Fallen Feathers Night  White Cosmetics and Weapon Pack
addappid(3653790) -- WUCHANG Fallen Feathers Deluxe Upgrade Pack