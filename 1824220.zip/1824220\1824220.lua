addappid(1824220)
addappid(228989)
setManifestid(228989,"1332597174812030948")
addappid(228990)
setManifestid(228990,"5087715316087945828")
addappid(1824221,0,"70ac4fdbb000d0a3f6ff5a9c3756662da90ff180752fb9bf87cc1f7cfc50e49d")
setManifestid(1824221,"1387858746576488614")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]