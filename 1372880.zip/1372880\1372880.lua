addappid(1372880)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229007)
setManifestid(229007,"4477590687906973371")
addappid(1372881,0,"c2f266082b4666e8fccf6b72330a6db8c7173c85d7ea8e7438cad8faae710a49")
setManifestid(1372881,"784397959976162815")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]