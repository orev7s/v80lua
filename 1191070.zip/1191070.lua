-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(1191070) -- Yuki Onna | 雪女

-- MAIN APP DEPOTS
addappid(1191071, 1, "e6d260ba37853888bae27b1bb5e11efc51d65725ae767a24f944abed378e3228") -- Scissors Slaughterhouse | 口裂け 屠畜場 Content
setManifestid(1191071, "501031684602708506", 0)
