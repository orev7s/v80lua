-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(339340) -- Resident Evil 0

-- MAIN APP DEPOTS
addappid(339341, 1, "e9299de2069122e5731bd097c02d35efe353b7dc40f59ca9ab568a382f3753c9") -- Resident Evil 0 / biohazard 0 HD REMASTER Depot Common
setManifestid(339341, "8625797949261159340", 0)
addappid(339342, 1, "5152d943dbe7913f463d7f9deab9da7bc6fcd382c8cb835b83182e1b7ef6ba46") -- Resident Evil 0 / biohazard 0 HD REMASTER Depot WW
setManifestid(339342, "556683354567652030", 0)

-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Resident Evil 0 Costume Pack 1 (AppID: 381710)
addappid(381710)
addappid(381710, 1, "ad086aff51fa29ecb7fd9e505054a2eea1a4d7ec52ab5e375278abeb78a7e16e") -- Resident Evil 0 Costume Pack 1 - DLC1 (381710) Depot
setManifestid(381710, "64352183134533440", 0)

-- Resident Evil 0 Costume Pack 2 (AppID: 381711)
addappid(381711)
addappid(381711, 1, "8983531cfd5d11e8574db04b0e6b0b9fff62a72b1c96d3a49c0eec8d6cb3229b") -- Resident Evil 0 Costume Pack 2 - DLC2 (381711) Depot
setManifestid(381711, "2539166499240446273", 0)

-- Resident Evil 0 Costume Pack 3 (AppID: 381712)
addappid(381712)
addappid(381712, 1, "75c7d7d7a3b9d267b81318fb7cfd61f1cd78d4b757e70f71efecde5fff153bcf") -- Resident Evil 0 Costume Pack 3 - DLC3 (381712) Depot
setManifestid(381712, "8981484900505289106", 0)

-- Resident Evil 0 Costume Pack 4 (AppID: 381713)
addappid(381713)
addappid(381713, 1, "0af8b8434f59751b16e7c4980fc31ddde20b0741487216fe779580ee28d05215") -- Resident Evil 0 Costume Pack 4 - DLC4 (381713) Depot
setManifestid(381713, "6723286139049539008", 0)

-- t- (AppID: 381715)
addappid(381715)
addappid(381715, 1, "92073fe5f9583ca8f8e27e4d617d3ddc7c176b70414bc280d6deb6d35b9340c8") -- t- - DLC6 (381715) Depot
setManifestid(381715, "2879115187161328365", 0)

-- Resident Evil 0 Fan Design T-shirt Pack (AppID: 381716)
addappid(381716)
addappid(381716, 1, "6af532d95f2f01b2de58c0a23d03e6c3b8f875653e8ccbc33babf6befe8e47b4") -- Resident Evil 0 Fan Design T-shirt Pack - DLC7 (381716) Depot
setManifestid(381716, "796528297318074013", 0)

-- t-GEO (AppID: 381717)
addappid(381717)
addappid(381717, 1, "163ac07f7433ca64c56ce7d4d5f6fa0d65c0862254216b4d9a204ecbdc3db355") -- t-GEO - DLC8 (381717) Depot
setManifestid(381717, "8576500298965902497", 0)

-- t-Joshin (AppID: 401340)
addappid(401340)
addappid(401340, 1, "8e6a4bf9ab74870f1642a94165c0895fa1411c8e95d72b64709ea95bfef3bbf9") -- t-Joshin - DLC9 (401340) Depot
setManifestid(401340, "9028079802819383357", 0)

-- t-WonderGOO (AppID: 401341)
addappid(401341)
addappid(401341, 1, "fba6c3da84f60705a9fe3e0fecb0b7e74a4daef175c06b245e83fade94bc3c31") -- t-WonderGOO - DLC10 (401341) Depot
setManifestid(401341, "7727255681251125193", 0)

-- Resident Evil 0 Shadow of Fear Rebecca T-shirt (AppID: 406140)
addappid(406140)
addappid(406140, 1, "c898f781e3b9add2cec64f7b3f0b7d4ca3f0860aa0693fca4284b8e172cd9d1d") -- Resident Evil 0 Shadow of Fear Rebecca T-shirt - DLC11 (406140) Depot
setManifestid(406140, "5500713755257879385", 0)

-- t- (AppID: 430390)
addappid(430390)
addappid(430390, 1, "2b2af9d49810ca216a15e3163cc022d8aa1c4ce0e5c1117226180fc04113ae1b") -- t- - DLC12 (430390) Depot
setManifestid(430390, "6770061075741675048", 0)
