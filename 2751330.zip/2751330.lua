-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(2751330) -- Helix Jump

-- MAIN APP DEPOTS
addappid(2751331, 1, "9311d12434a65f0fb1089412277bde4cefb56f9e38dc9ba441a43cde71fee310") -- Main Game Content (Windows Content)
setManifestid(2751331, "2154077787273698452", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Helix Jump Letter Madness (AppID: 2828070)
addappid(2828070)
addappid(2828070, 1, "14b9748f87964b5959dd2ce2442da85eb843e4bd246ed584a55c0d7926f6ef60") -- Helix Jump Letter Madness - Main Content
setManifestid(2828070, "1004469991290073738", 0)

-- Helix Jump Party Skins (AppID: 2828080)
addappid(2828080)
addappid(2828080, 1, "b60fcba88966bfc3ec84dd5a5d9a31a38e55530263d92733eae88262779fa09d") -- Helix Jump Party Skins - Main Content
setManifestid(2828080, "5310072092295361206", 0)
