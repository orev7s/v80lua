-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy

-- MAIN APPLICATION
addappid(3125750) -- EDENS ZERO

-- MAIN APP DEPOTS
addappid(3125751, 1, "8e98d35380e0ac080fbc6342eca2d99a14165fb1f54e883ecf81a691c99c1ecf") -- Depot 3125751
setManifestid(3125751, "4526864796636492866", 0)

-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- EDENS ZERO - Equipment for Men Gaming Series   Equipment for Women Cyber Series (AppID: 3273490)
addappid(3273490)
addappid(3273490, 1, "bd2ee0c4b65cfa695db6f47c24a2c7c2a508e1a1df69be2478180e3b138cb2af") -- EDENS ZERO - Equipment for Men Gaming Series   Equipment for Women Cyber Series - Depot 3273490
setManifestid(3273490, "7279457516532429743", 0)

-- EDENS ZERO - Lacrima Set (AppID: 3345380)
addappid(3345380)
addappid(3345380, 1, "9a9b24b0fcbd745e892372f653dfe0b38e60db478743edb5bc9bf137727da8c2") -- EDENS ZERO - Lacrima Set - Depot 3345380
setManifestid(3345380, "6956964429016939257", 0)

-- EDENS ZERO - Starter Item pack (AppID: 3345400)
addappid(3345400)
addappid(3345400, 1, "f5e90e13a7c91cfe19599118d404e9387ddfcfa8973453879a081cfb893887bb") -- EDENS ZERO - Starter Item pack - Depot 3345400
setManifestid(3345400, "5846874651050349388", 0)

-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- EDENS ZERO - Pinos Attire Hunter Attire (AppID: 3345410) - missing depot keys
-- addappid(3345410)
-- EDENS ZERO - Accessory Dragon Wings (AppID: 3345420) - missing depot keys
-- addappid(3345420)
