-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy / https://discord.gg/m8PxjTwrnv
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(491540, 1, "50ede99c2f96404b8a78ea512566035693baad8bf04610df397b9587b56ae155") -- The Bus
-- MAIN APP DEPOTS
addappid(491541, 1, "8d2383b07a93cb99ce9f861e608ebecb5f050f9b03c687a4c34d65810c7a6de2") -- The Bus Content
setManifestid(491541, "5190193716623585114", 52892307109)
addappid(491542, 1, "17a413c346787a07c3435c510d605b955d08d830625bce61660fea8014c99ee3") -- The Bus - Scania CW18M
setManifestid(491542, "6173733593377344687", 216132341)
addappid(897493, 1, "31e71ddf1e4074dd299969b0b2bf3d6752f7d420860a443729aa2b25ac6a15d6") -- The Bus - MAN Lion's City DD
setManifestid(897493, "2497618430557806663", 145551548)
addappid(897494, 1, "b3f0af7017d1c49fcf5e67fda2f8f0cf27a8497278ea73223937a1ed9b15df6a") -- The Bus - Line 200
setManifestid(897494, "3725264354591688735", 0)
addappid(897495, 1, "ee3dfb504287b75635b8f4f65e461b942c19ee2aa79f41ff33bd918c21968341") -- The Bus - Line 245
setManifestid(897495, "5501507913094284178", 0)
addappid(897496, 1, "775dc74ca6a581d55a7fbb9d866ed88bbb58af2b9db1830bba59605dfb4e4911") -- The Bus - Line 100
setManifestid(897496, "7856527596074613875", 0)
addappid(897498, 1, "4579ccfebc7d2b7503855a9ca06e5814dd25974c87ba487f9bcb5c57f4126928") -- Depot 897498
setManifestid(897498, "4340830551304702519", 79350407)
addappid(897499, 1, "b590c139a5495cb19349ad13183148beebba64cba77fd97fd2203f5c3af3eb0e") -- Depot 897499
setManifestid(897499, "3424333586108645378", 0)
addappid(898611, 1, "abbdea3d230c0dfec1c0e957b9e7e48d11cee42a4231596bcaf7f7782b0769f2") -- Depot 898611
setManifestid(898611, "2470266384672435631", 59585334)
addappid(898612, 1, "7507d616d2d5d33fb200774c4721b24c7b12c9a6e244a7d955292b76d6bf0386") -- Depot 898612
setManifestid(898612, "6856078903255251146", 0)
addappid(898621, 1, "d6ac0bafa7c3862e611df6645da819c058edc7bff67a77957644795a37d32403") -- Depot 898621
setManifestid(898621, "780433789316063419", 0)
addappid(898622, 1, "928e91bdd6aff07abd00679a7b57b6cf2afb5e03b0e9552fbfe21559381a2148") -- Depot 898622
setManifestid(898622, "898285436787148995", 458971)
addappid(898623, 1, "c3946683cfdbc82316bce160e3d183a7910d1dcf95261729d2e831c28f705e0e") -- Depot 898623
setManifestid(898623, "2005502871026558840", 0)
addappid(898624, 1, "3da00b447931500314e2ec3ef7824e0828a836c20b74edd3f9e46fc04f3a4580") -- Depot 898624
setManifestid(898624, "1388638951982481714", 714438)
addappid(898626, 1, "a0e87b2536cf223daa4572d5c494db6c1da23303a5bf1f00196af604a71915db") -- Depot 898626
setManifestid(898626, "4392997473346220623", 119923)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- The Bus - Hamburg City (AppID: 3544250)
addappid(3544250)
addappid(3544250, 1, "25a1c05581659f93bcbf9d25a2f6c033ea73eb9fac6eda9727e03454fde92247") -- The Bus - Hamburg City - Depot 3544250
setManifestid(3544250, "6974219549889987553", 14900837150)