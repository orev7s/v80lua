-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(2314720) -- Parasocial | パラソーシャル

-- MAIN APP DEPOTS
addappid(2314721, 1, "f627302cb6e9725d117be8923be7440410f1c69d179f96e422a607dfcf4f24f8") -- Main Game Content (Windows Content)
setManifestid(2314721, "1838143738588820217", 0)
