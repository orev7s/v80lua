addappid(1874000)
addappid(1874001, 1, "34de6dc6df22af7fc7df7fda8a5799f8793ae860ac574864e18896fecf02aeb2")
setManifestid(1874001, "7898987537505594807", 0)
addappid(3012890, 1, "8538cdc8423137fdd53890d96f7395b141dd635ad6ccc37092464d57e5f35ce1")
setManifestid(3012890, "282289861124015302", 0)
addappid(3012900, 1, "c50fa338cf0d3a6411b58603d71ffd4209f1e48f95bd13e0a97954dd5a44b12a")
setManifestid(3012900, "7909477111697944413", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]