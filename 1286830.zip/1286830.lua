-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(1286830) -- STAR WARS™: The Old Republic™

-- MAIN APP DEPOTS
addappid(1286831, 1, "5f441ab499a56229f41d6a145429972e63e773be8f3028defce3e15cd0d2c397") -- Launcher Content
setManifestid(1286831, "7707818389424499420", 0)
addappid(1286833, 1, "0dc81a7e097e5bcaa2befe6feca6001c8b4e7ec674d5e5faeae16a1d720c6e05") -- German Movies and Assets
setManifestid(1286833, "4599223595034866118", 0)
addappid(1286834, 1, "14b0eb51cb078a993b393e640b71ca12dc5a1b8bb53b9423259e67a2963f374a") -- French Movies and Assets
setManifestid(1286834, "3811797453910408225", 0)
addappid(1286835, 1, "3dff041725d43f20ec9fc52b005a9c94193a7076ad086dd58d989fceb4f8c717") -- English Movies and Assets
setManifestid(1286835, "1116924592521249041", 0)
addappid(1286836, 1, "b21b5ef05d644660d0c7ad11d5390622abd8a6513a7efa65da7f6ef07421f1d8") -- Client and Shared Movies and Assets
setManifestid(1286836, "7694059683476123398", 0)

-- SHARED DEPOTS (from other apps)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
setManifestid(228982, "6413394087650432851", 0)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1303600) -- STAR WARS The Old Republic Legacy of the Sith Digital Collectors Edition
addappid(1303605) -- STAR WARS The Old Republic - Cartel Coins
addappid(1303891) -- STAR WARS The Old Republic - Galactic Leisure Bundle
addappid(1333220) -- STAR WARS The Old Republic  - Subscriptions
addappid(1346540) -- STAR WARS The Old Republic - Jedi Bundles
addappid(1346541) -- STAR WARS The Old Republic - Sith Bundles
addappid(2550190) -- STAR WARS The Old Republic - Join the Fight Bundle
addappid(3076010) -- STAR WARS The Old Republic - Master the Fight - Firebolt Edition
addappid(3076020) -- STAR WARS The Old Republic - Master the Fight - Starbolt Edition
addappid(3076030) -- STAR WARS The Old Republic - Master the Fight - Storm Edition
