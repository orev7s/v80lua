-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪username - f1uxin, on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy / https://discord.gg/m8PxjTwrnv
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(319630) -- Life is Strange™

-- MAIN APP DEPOTS
addappid(319631, 1, "3fb59542b09289ab37c28b9fe85bd128cbaa0726769ec3102f79027c7725927e") -- Life is Strange™ Content
setManifestid(319631, "1504133382031970604", 0)
addappid(319633, 1, "31bd43fdb6e995d0d75cfcdadd226dfa13de27323e9ddcbdfa4e4344403175c7") -- Mac Life is Strange™ Content
setManifestid(319633, "3204428865733255167", 0)
addappid(319640, 1, "152b2d7b51db869726fca55d8b1467e15102c4adfbfd446e30e67785c56450f9") -- Mac Life is Strange™ App
setManifestid(319640, "3010017480070139114", 0)
addappid(319641, 1, "6b9a5171c7b655f3eef5f83a84208b5dbf523cecac4ac9efcf3e3f11c58aad11") -- Linux Life is Strange™ Content
setManifestid(319641, "2241753359886490277", 0)
addappid(319648, 1, "1bdedf312ffa80c410a089497caa431265df143f56631db46afc7414da483e27") -- Linux Life is Strange™ App
setManifestid(319648, "713697669645095858", 0)
addappid(319649, 1, "e0ba3f355ec97c629ef0ff88d2ba485c79479d8ccb06cce8cef9a56a113441a6") -- Linux Life is Strange™ - Launch Overrides
setManifestid(319649, "5832655655601560602", 0)

-- SHARED DEPOTS (from other apps)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- VC 2005 Redist (Shared from App 228980)
setManifestid(228981, "7613356809904826842", 0)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
setManifestid(228982, "6413394087650432851", 0)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
addappid(229032, 1, "15b3308d4e95d1156182211bab1c823b6df0a06fd74a5c0833abed89bc307cfb") -- PhysX System Software 9.13.1220 (Shared from App 228980)
setManifestid(229032, "3616495131483866412", 0)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- PhysX System Software 9.14.0702 (Shared from App 228980)
setManifestid(229033, "2059065101492814639", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Life is Strange - Episode 2 (AppID: 329880)
addappid(329880)
addappid(329880, 1, "bdea222006c210df117e306a7c0505c0a2f89e78c7647d4ac65784493c7c53e1") -- Life is Strange - Episode 2 - Life is Strange™ - Episode 2 (329880) Depot
setManifestid(329880, "6686257525367030622", 0)
addappid(319634, 1, "8fe4526ae9afeb8b59f4b3fa259c51838cff708227c76a7d0110c32ed8d6bf66") -- Life is Strange - Episode 2 - Mac Life is Strange™ - Episode 2 (329880) Depot
setManifestid(319634, "222794417875313061", 0)
addappid(319642, 1, "cad29faffb7fb1074549051de5576c96aa59d60ca75fd6bdbc7a6d89a2b06a90") -- Life is Strange - Episode 2 - Linux Life is Strange™ - Episode 2 (329880) Depot
setManifestid(319642, "47059555116448828", 0)

-- Life is Strange - Episode 3 (AppID: 329910)
addappid(329910)
addappid(329910, 1, "304a457d2d78d9cd0878d23c51e61f8664101396b62d63bdbd38ef546de83960") -- Life is Strange - Episode 3 - Life is Strange™ - Episode 3 (329910) Depot
setManifestid(329910, "621653098648178046", 0)
addappid(319635, 1, "7c7b95f829557a2f462fbc0b2172942e2365f494884d828e13ceb7f3ffae974a") -- Life is Strange - Episode 3 - Mac Life is Strange™ - Episode 3 (329910) Depot
setManifestid(319635, "70888225976114718", 0)
addappid(319643, 1, "f2c2eab81d337bf33940ae788f5937c328c8f1d6fd36ee6f1b06033803882531") -- Life is Strange - Episode 3 - Linux Life is Strange™ - Episode 3 (329910) Depot
setManifestid(319643, "63421583718511130", 0)

-- Life is Strange - Episode 4 (AppID: 329920)
addappid(329920)
addappid(329920, 1, "009ff873239574e1b41db8b66d1eb5effaa71390de4da55be0e361dcdd1513b2") -- Life is Strange - Episode 4 - Life is Strange™ - Episode 4 (329920) Depot
setManifestid(329920, "6205501035602217932", 0)
addappid(319636, 1, "ae3350e4808e23662d74c14aab69a2504142f595f752a90d7ce461339cfa444b") -- Life is Strange - Episode 4 - Mac Life is Strange™ - Episode 4 (329920) Depot
setManifestid(319636, "114033635064667670", 0)
addappid(319644, 1, "d9187f067e9216845fbf15ec0d2a954ac58820dffd0cb363f7fbf7e315ea9a66") -- Life is Strange - Episode 4 - Linux Life is Strange™ - Episode 4 (329920) Depot
setManifestid(319644, "14200674631853344", 0)

-- Life is Strange - Episode 5 (AppID: 329930)
addappid(329930)
addtoken(329930, "11315752241480638327")
addappid(329930, 1, "c9ac63b1daabc2c5247168e1c4b2dc5809ce93459a56e903335994d074544523") -- Life is Strange - Episode 5 - Life is Strange™ - Episode 5 (329930) Depot
setManifestid(329930, "4448389403897272612", 0)
addappid(319637, 1, "88a9a5ae4b1e710e7be30a09ddf55dd871e6d37d195a1fdd03d06d825c1eb583") -- Life is Strange - Episode 5 - Mac Life is Strange™ - Episode 5 (329930) Depot
setManifestid(319637, "185325383318277789", 0)
addappid(319645, 1, "dc4f53a308d6026d9520881c75e03df7cf015f3ac6f718132fcf8ef85e1bd2cc") -- Life is Strange - Episode 5 - Linux Life is Strange™ - Episode 5 (329930) Depot
setManifestid(319645, "79657551267791428", 0)

-- Life is Strange - Directors Commentary (AppID: 432670)
addappid(432670)
addappid(432670, 1, "0c81f5c855f8cae80641f62076aba0696fd2768b20bf7823f31f1f781962eb94") -- Life is Strange - Directors Commentary - Life is Strange™ - Directors Commentary (432670) Depot
setManifestid(432670, "8697497343955061773", 0)
addappid(319638, 1, "142491ccaeab8fe91b2b0640b634295251fb2ae44e6ae5e7b64423a1550ea3ef") -- Life is Strange - Directors Commentary - Mac Life is Strange™ Directors Commentary (432670) Depot
setManifestid(319638, "41093949998204956", 0)
addappid(319646, 1, "8d208bd00b29b049ff84bdf43a718b6eaa8233dbcc70f4b6edba20735955b497") -- Life is Strange - Directors Commentary - Linux Life is Strange™ - Directors Commentary (432670) Depot
setManifestid(319646, "17411502911150245", 0)

-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Life is Strange - Japanese Language Pack (AppID: 425570) - missing keys for depots: [425570, 425570]
-- addappid(425570)
-- addappid(425570, 1, "fa766d1da9dbaad796c5f87b1f63be8d1ed2d1c8f69cb95f3dbb0034e4e59b29") -- Life is Strange - Japanese Language Pack - Life is Strange™ - Japanese Language Pack (425570) Depot (excluded with DLC)
-- setManifestid(425570, "9058349801170125022", 0)
-- addappid(425570, 1, "fa766d1da9dbaad796c5f87b1f63be8d1ed2d1c8f69cb95f3dbb0034e4e59b29") -- Life is Strange - Japanese Language Pack - Life is Strange™ - Japanese Language Pack (425570) Depot (excluded with DLC)
-- setManifestid(425570, "9058349801170125022", 0)
