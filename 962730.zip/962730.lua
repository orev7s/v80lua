-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(962730) -- Skater XL

-- MAIN APP DEPOTS
addappid(962731, 1, "d40a19216eb72a40d8ccee687beb14fa0b2f7678d0c65a9e48606889e089c047") -- Skater XL Content
setManifestid(962731, "961873864225958869", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1952000) -- Skater XL - Tampa Pro 2022 Gear Pack For Charity
