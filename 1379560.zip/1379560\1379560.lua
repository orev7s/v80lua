addappid(1379560)
addappid(1379561,0,"addeeefc87fad317c91677181dc941c48893ff4188609219bb27bbdd38f62ec7")
setManifestid(1379561,"1257233539612524131")
addappid(1379562,0,"2324f1a6f25064ae2c7eb9d5c62549abf69b312043b043c8177632080b0c7673")
setManifestid(1379562,"299528426525074060")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]