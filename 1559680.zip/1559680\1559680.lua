addappid(1559680)
addappid(1559681,0,"274a5cc627fe54c61daf8e1c089fc62ea53d53af956d035a58954c7b29547de0")
addappid(1559682,0,"bd324a3eba603f0e521137580660afe5afc50023b3be624ada2164da28abb35e")
setManifestid(1559681,"7943043988990674140")
setManifestid(1559682,"8380547442226109673")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]