-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy

-- MAIN APPLICATION
addappid(2300320) -- Farming Simulator 25

-- MAIN APP DEPOTS
addappid(2300321, 1, "e5e857b4939e3993f78ae1bfa1857aa4dca14c90680aec0e63f48565c885c2ae") -- Depot 2300321
setManifestid(2300321, "6058333694498242201", 0)
addappid(2300322, 1, "e60dffe1f9b3a6f6fb4475045e0d66ec6a40410ffb036ce2dd37fd88c3acd6a5") -- Depot 2300322
setManifestid(2300322, "5979330087026300633", 0)
addappid(2300323, 1, "3de49a7eee583d841ab3194df793f8db9fe186930c8623d2a864a81ff5586afd") -- Depot 2300323
setManifestid(2300323, "1550107122794757569", 0)
addappid(2300324, 1, "f8938589cbd4ca4f7c8031839fe15759ac1c8c79ef2eaef69e6a00241703a2c5") -- Depot 2300324
setManifestid(2300324, "7082434029875972807", 0)
addappid(2300325, 1, "f946e8f4ea8420aed7edd1f5918e81d77ce171e78ea11c54b7adeae8a4669a4d") -- Depot 2300325
setManifestid(2300325, "2519322278117707135", 0)
addappid(2300326, 1, "cca076ed972ab800d4c8c6efafe281be83d39290660fe3a2b27603c21151da6c") -- Depot 2300326
setManifestid(2300326, "2699845844463245190", 0)
addappid(2300327, 1, "639dd3cbaa8cbc16ccedb39098b2b8a039da4a992920ff2e368bc2c041b28cba") -- Depot 2300327
setManifestid(2300327, "8747416787258114339", 0)
addappid(2300328, 1, "c121e9f50b5801a92cc456d3211620c4d920f3a0e75686f6184cb10bb562d904") -- Depot 2300328
setManifestid(2300328, "4898221753086484171", 0)
addappid(2300329, 1, "f80f185138acffeef2e34fa3571b351e5551c4d705483aaabd9b5d15e74e75fb") -- Depot 2300329
setManifestid(2300329, "5932979496095422232", 0)
addappid(2981091, 1, "968fe6780cc09c4baeda840f0411a94b5f1bab38dfca0f36c89fbe2331c294a8") -- Depot 2981091
setManifestid(2981091, "5292817651936743538", 0)
addappid(2981092, 1, "e0288911696b43f3458119ec84de121e35abfe2d2322504ce777e37a018b4a33") -- Depot 2981092
setManifestid(2981092, "3986813650063916220", 0)
addappid(2981093, 1, "29d185a1ecc003c97c77f0e8b70151d2f4ce3499db9e54ca2e85cbe1b2ff9070") -- Depot 2981093
setManifestid(2981093, "934605271199172290", 0)
addappid(2981094, 1, "ea0932e50bea6317bc6a512361e03c2e454e9733c0a9a65a5290879eee89bf6b") -- Depot 2981094
setManifestid(2981094, "4467306760700940625", 0)
addappid(2981095, 1, "ade1eac77aba845dd5816f2573f47b7ac39f5599834dc69c3b71af8f59bee8ec") -- Depot 2981095
setManifestid(2981095, "8694346490421832324", 0)
addappid(2981096, 1, "863228b07a13e8d3eba1639ebaab3cc538e34672e7b3672c40197ffb6c896ba2") -- Depot 2981096
setManifestid(2981096, "8727505838908121317", 0)
addappid(2981097, 1, "1ced5c6691d6aa866ca70e4708a6617186dc447bc154699a8ec16682c9cf165f") -- Depot 2981097
setManifestid(2981097, "6937195163401650241", 0)
addappid(2981098, 1, "d1f521d8b6ae2b013a7e2a9f4c44766e025a4e0a6112ee90016c6f2968da9e24") -- Depot 2981098
setManifestid(2981098, "8829242856986735896", 0)
addappid(2981099, 1, "655b7d0f6e8e38251a8eeec6f60e4ed47d5ddc3a50b3cacb2faca871417c9dc0") -- Depot 2981099
setManifestid(2981099, "3980285498065046994", 0)
addappid(2981101, 1, "9f00d6bfe26a671b716b22bcfacf0ffa17e67b9960a7627a9c6d6a5448f93fd8") -- Depot 2981101
setManifestid(2981101, "6096155025109753201", 0)
addappid(2981102, 1, "9eb91152a6aa2d434131b3551ccd34e79cdcd87baa77972f930e2e49f2727c16") -- Depot 2981102
setManifestid(2981102, "6773764835871137388", 0)
addappid(2981103, 1, "9a3b1f5733c28c3ac4529ab6f6ae7c3c35639bd8adc5518066c1e9db0ac6a9d8") -- Depot 2981103
setManifestid(2981103, "2996502837207591963", 0)
addappid(2981104, 1, "ae85b8e8c5a5ed430feea1df6a23f3bccca41ee70b4b77592b6f6551c956be81") -- Depot 2981104
setManifestid(2981104, "8290737112462894023", 0)
addappid(2981105, 1, "41b3097f70f8b302773f6d473d438df683eba85bc6fedfca26e4b55f00388cec") -- Depot 2981105
setManifestid(2981105, "6806530335208221837", 0)
addappid(2981106, 1, "8f6f1b07d0ff2a282fbaa971eb841ec96e4cea021abb7fdbb8b788a0c2bdd556") -- Depot 2981106
setManifestid(2981106, "2141179524058091071", 0)
addappid(2981107, 1, "402e70f1a56080cfdac842c33ef75226c38fd20e3e390c6e67dcae0b01e28a95") -- Depot 2981107
setManifestid(2981107, "782481009953151439", 0)

-- DLCS WITH DEDICATED DEPOTS
-- FS25 - MacDon Pack (AppID: 2981090)
addappid(2981090)
addappid(2981090, 1, "0651e56ae954c27ffee937a46ec72d5a6d9838157153e18713a5f5367b6655dd") -- FS25 - MacDon Pack - FS25 - MacDon Pack
setManifestid(2981090, "7847067090206129125", 0)

-- FS25 - New Holland CR11 Gold Edition (AppID: 2981110)
addappid(2981110)
addappid(2981110, 1, "c8311e383c31827910b45fd0ab017594f10b8c6395251b28c6c4fa0d57a8e7be") -- FS25 - New Holland CR11 Gold Edition - FS25 - New Holland CR11 Gold Edition
setManifestid(2981110, "2426592928577282527", 0)

-- FS25 - NEXAT Pack (AppID: 3450870)
addappid(3450870)
addappid(3450870, 1, "9a83c658cb248afaef38c4df9015a9c6e0bf9b2397e9dfff8dca12aa6e4d3a81") -- FS25 - NEXAT Pack - Depot 3450870
setManifestid(3450870, "4372243593270383365", 0)

-- FS25 - Plains and Prairies Pack (AppID: 3453950)
addappid(3453950)
addappid(3453950, 1, "467c83ead3c8b40f90c044575fc18c1cd49f0acdd23423219f7ab35f19e30b02") -- FS25 - Plains and Prairies Pack - Depot 3453950
setManifestid(3453950, "4479790015664922032", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2981100) -- Farming Simulator 25 Year 1 Season Pass

-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(3453970) -- Farming Simulator 25: Highlands Fishing Expansion (unreleased)
