-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(3716600) -- Mage Arena
-- MAIN APP DEPOTS
addappid(3716601, 1, "e310c1b9ef27e0d9ec00ac3593dc3851ee94ffa39699fed48341039f9ec50fc6") -- Depot 3716601
setManifestid(3716601, "6227913375238721501", 800923834)