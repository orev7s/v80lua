-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪username - f1uxin, on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy / https://discord.gg/m8PxjTwrnv
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(1669000, 1, "af2a71eb151a9b1847e1be622c9084650267ff44d0f8a29cf9c516b8aaf92284") -- Age of Wonders 4
-- MAIN APP DEPOTS
addappid(1669001, 1, "c9f8c2fa2410e5cdca74811acc196b199d9831a62e6f4365e521fcadca9d12a5") -- Depot 1669001
setManifestid(1669001, "4053427315300259637", 28843276053)
addappid(1669002, 1, "c4f706f7261dee685e2d74998d61a7b4fb175bb47659cce89b560f89fe30ff61") -- Depot 1669002
setManifestid(1669002, "2014604144985367483", 361497078)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- .NET 4.5.2 Redist (Shared from App 228980)
setManifestid(229004, "5220958916987797232", 70000464)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- .NET 4.6 Redist (Shared from App 228980)
setManifestid(229005, "7992454656023763365", 62009092)
-- DLCS WITH DEDICATED DEPOTS
-- Age of Wonders 4 Pre-Order Content Pack (AppID: 2257970)
addappid(2257970)
addappid(2257970, 1, "2725cc874450911b4c09f09607e3a3125e1daa5574ee01d74fe2b27e7d8400f0") -- Age of Wonders 4 Pre-Order Content Pack - Depot 2257970
setManifestid(2257970, "2865807012584769022", 163176)
-- Age of Wonders 4 Sign-Up Content (AppID: 2257990)
addappid(2257990)
addappid(2257990, 1, "7e40f1272e9d72fa90cb32e8faf281b53d56bd56d220983df52143d7590517e8") -- Age of Wonders 4 Sign-Up Content - Depot 2257990
setManifestid(2257990, "3586028993103183297", 161493)
-- Age of Wonders 4 Archmage Attire (AppID: 2330150)
addappid(2330150)
addappid(2330150, 1, "279b4878ac89aace60e568e256cfa63ceff174760e2873b46fece3f4435209cb") -- Age of Wonders 4 Archmage Attire - Depot 2330150
setManifestid(2330150, "1952808027203437358", 145854)
-- Age of Wonders 4 Dragon Dawn (AppID: 2367860)
addappid(2367860)
addappid(2367860, 1, "0deaaf18077207ee03464d1de42b12c00ac5a7d0030f00d7f27ddf8f1c93d0f4") -- Age of Wonders 4 Dragon Dawn - Depot 2367860
setManifestid(2367860, "7815419419515787571", 184113)
-- Age of Wonders 4 Empires  Ashes (AppID: 2401830)
addappid(2401830)
addappid(2401830, 1, "8c4094bd7b64677817f0211860cbf741b9157cafe4a11f2421288c69ae5107e8") -- Age of Wonders 4 Empires  Ashes - Depot 2401830
setManifestid(2401830, "3447008450579376002", 177441)
-- Age of Wonders 4 Primal Fury (AppID: 2401850)
addappid(2401850)
addappid(2401850, 1, "c29a39c1b2c6028d82b7dd85839375cca70dda4dfdee57687761ae35e4c082e5") -- Age of Wonders 4 Primal Fury - Depot 2401850
setManifestid(2401850, "4962773803312409013", 174865)
-- Age of Wonders 4 Eldritch Realms (AppID: 2401860)
addappid(2401860)
addappid(2401860, 1, "46a1086fb27c2492df2940ac528d7793ed980733ce1c2ea0ab216202a1244dd7") -- Age of Wonders 4 Eldritch Realms - Depot 2401860
setManifestid(2401860, "7513830674370079236", 169789)
-- Age of Wonders 4 Ways of War (AppID: 2914280)
addappid(2914280)
addappid(2914280, 1, "efa7dbf9c27c1c8fe6553dab29b0e257ecb8c3a3235765ae79671ff744affd13") -- Age of Wonders 4 Ways of War - Depot 2914280
setManifestid(2914280, "8430218516059799238", 171549)
-- Age of Wonders 4 Herald of Glory (AppID: 3119880)
addappid(3119880)
addappid(3119880, 1, "bc0d77b48758274a4e61539d17c04865ad8c53089786afd2de063fe74551ba6e") -- Age of Wonders 4 Herald of Glory - Depot 3119880
setManifestid(3119880, "5200052240744467692", 152039)
-- Age of Wonders 4 Giant Kings (AppID: 3181500)
addappid(3181500)
addappid(3181500, 1, "f597777e5312438bf357be4399b5be50ebe4b75a469dd5afcb5093d146926979") -- Age of Wonders 4 Giant Kings - Depot 3181500
setManifestid(3181500, "5177705880271432925", 158543)
-- Age of Wonders 4 Archon Prophecy (AppID: 3181540)
addappid(3181540)
addappid(3181540, 1, "f86f726aa931e7892ad89db18d3c78c584e28d33b8fe9a5a61fc719f5ee781df") -- Age of Wonders 4 Archon Prophecy - Depot 3181540
setManifestid(3181540, "8537650910095910606", 162029)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2260160) -- Age of Wonders 4 Expansion Pass 1
addappid(3181480) -- Age of Wonders 4 Expansion Pass 2