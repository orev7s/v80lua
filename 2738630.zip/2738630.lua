-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(2738630) -- Dungeons & Dragons Neverwinter Nights 2: Enhanced Edition

-- MAIN APP DEPOTS
addappid(2738631, 1, "e5b933ee1484218c14744f2cd290d7f9be7a1b76b6f12f82b2164c566c7e95e7") -- Depot 2738631
setManifestid(2738631, "6414316965324281766", 0)
addappid(2738632, 1, "887ad38cf68594a0dd601c040e05aab634071f3d006e7d60022e3fa871ca3110") -- Depot 2738632
setManifestid(2738632, "7765997139974976210", 0)
addappid(2738633, 1, "f6e4dfa86dd91eeec9b72b52dd017c93130ec9a1bb3c76d79bf792dd88b1eaa5") -- Depot 2738633
setManifestid(2738633, "2559327378053739436", 0)

-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 0)
