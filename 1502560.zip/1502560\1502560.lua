addappid(1502560)
addappid(1502561,0,"92924d4fced70d09d84c8558800903f84e5e65a36fee94b5bb50d1708a42a660")
setManifestid(1502561,"1817633527475260225")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]