-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(1809540)
addappid(1809541, 1, "6c41504f601faddc7ec40aff4688b9ee9e34c37f2ab46b882880cbcc76a8eb40")
setManifestid(1809541, "5699864374575062052", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]