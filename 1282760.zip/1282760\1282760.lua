addappid(1282760)
addappid(1282761,0,"5321960cdea41e3e93e37be21b0ff8446ca360073ac57e667330ceaecb4dd5a4")
setManifestid(1282761,"3483535207374547737")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]