addappid(1522960)
addappid(1522961,0,"4ae1b706c46cc1e3aca6e2040b858a5e0c2eab28033eabed5ac691e9f78ac1d3")
setManifestid(1522961,"5159803858357428533")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]