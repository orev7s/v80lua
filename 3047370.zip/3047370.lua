-- Made by f1uxin, please read the read me TXT file.
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship
addappid(3047370) -- Net.Attack()

-- MAIN APP DEPOTS
addappid(3047371, 1, "ce6a946ac6fb6632b2489d746a06a79acce0c5819852b033b8f79db93be9f9c3") -- Depot 3047371
setManifestid(3047371, "4204310230556529067", 0)
