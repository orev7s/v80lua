-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(1744910) -- The Radio Station | 深夜放送

-- MAIN APP DEPOTS
addappid(1744911, 1, "eb0f4b8fba0f819736cc9ec1a6272888175aa9867d1c2d632a777c14bf7acaab") -- The Radio Station | 深夜放送 Content
setManifestid(1744911, "2707537798635530019", 0)
