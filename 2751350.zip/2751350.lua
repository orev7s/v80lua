-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(2751350) -- Golf Guys

-- MAIN APP DEPOTS
addappid(2751351, 1, "9323bb94c459555a610816a1eea4df0a35156d49053cee3833bb835cf23325bb") -- Depot 2751351
setManifestid(2751351, "3335361995774969743", 0)

-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Golf Guys Fantasy DLC (AppID: 2813390) - missing depot keys
-- addappid(2813390)
-- Golf Guys Party DLC (AppID: 2813400) - missing depot keys
-- addappid(2813400)
-- Golf Guys Space DLC (AppID: 2813410) - missing depot keys
-- addappid(2813410)
