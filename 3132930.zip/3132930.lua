-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(3132930) -- Monument Valley 3

-- MAIN APP DEPOTS
addappid(3132931, 1, "57e0afd11139b43336255c7e6bd21df5144f5b38b0f68a0b6604a88babe7c065") -- Depot 3132931
setManifestid(3132931, "8834799550329660245", 0)

-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Monument Valley 3 - Original Soundtrack (AppID: 3846460) - missing depot keys
-- addappid(3846460)
