-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(1361210)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(229006)
setManifestid(229006,"1784011429307107530")
addappid(1361211,0,"91a13a5dcfb61da0b70e706684905b0c2aa90d8287d89e17507c0b94bc0f6e62")
setManifestid(1361211,"2648689302390650597")
addappid(1361212,0,"4d49f54fcf910bba344e8488b85616043a21cf7d6d486b8ad37085ffc6bf9401")
setManifestid(1361212,"2639934707954061880")
addappid(1361213,0,"5b665c11f3ab71ed186993ab184691c52af53a8d86ffd0c2fd8fbc8ec33b757d")
setManifestid(1361213,"5810179873087365514")
addappid(1361214)