addappid(1571340)
addappid(1571341,0,"ee0b8b28add459c0accd5b7a7df7a9fd3614b2790fea6cb28fd6430b726c7b10")
setManifestid(1571341,"8786014110604061825")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]