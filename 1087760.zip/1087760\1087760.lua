addappid(1087760)
addappid(1087761, 1, "6a138e7b33b8d0fddcc4efc5c3d9fc69a18b80529c80a1d2fb835656233d8530")
setManifestid(1087761, "883226923566714580", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]