addappid(1743850)
addappid(1743851,0,"4542812225d88ed246fc6f5b269158a5e15d6d9f75b57361e0185944175a9fa3")
addappid(1743859,0,"56a8a0709b1877c6628f1aac9841bf088da9a8dad317dc8d6521de3558bcec2f")
setManifestid(1743851,"6721235343416524107")
setManifestid(1743859,"7997716907046878545")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]