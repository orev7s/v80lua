addappid(1028630)
addappid(1028631, 1, "e9ccb16c87cb95105a5b78d0bbdcbac885cdc99d5b83b4d9d928b13b56ca408a")
setManifestid(1028631, "3848653972656035277")
addappid(1554620, 1, "2fc404dce88b76903ce2a7d0bbaf98489fae7b3c4f10830d5b5ee8b0278ddd18")
setManifestid(1554620, "6759593030495132579")
addappid(1554620)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]