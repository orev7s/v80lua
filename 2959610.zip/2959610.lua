-- Made by f1uxin, please read the read me TXT file.
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(2959610) -- Cabin Crew Life Simulator

-- MAIN APP DEPOTS
addappid(2959611, 1, "a8a8ab2bb84a026b16b49e2cd4b28c2a6c2b59fa7840ad3e88fc04cc5f6e9c0f") -- Main Game Content (Windows Content)
setManifestid(2959611, "9019767735926778324", 0)
