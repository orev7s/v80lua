-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(408120) -- Cibele

-- MAIN APP DEPOTS
addappid(408122, 1, "d2eaf2dfbfb3efbb0fbd9da95ca2dc46d6de47d8db463886eed54b4ad0091fb4") -- Cibele mac
setManifestid(408122, "8804347182754771586", 0)
addappid(408123, 1, "7244507187f5cd93be22e7175a38fe2c70b79452fb60f3cf191f6e6fdd122530") -- Cibele windows
setManifestid(408123, "6489824298675106507", 0)

-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Cibele - Soundtrack (AppID: 414590) - missing depot keys
-- addappid(414590)
