-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(2771320) -- The Nom

-- MAIN APP DEPOTS
addappid(2771321, 1, "26ecd8537ca914dad2dfb4b186b04fe79739022b529c0429587512f2c2d64bf3") -- Main Game Content (Windows Content)
setManifestid(2771321, "5400988316646670321", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2820860) -- The Nom Monster Madness
