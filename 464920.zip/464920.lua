-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(464920) -- Surviving Mars

-- MAIN APP DEPOTS
addappid(464921, 1, "530eaa80779996a84cfcf683a34311a8d94f025012d313bfe0d035a7baccf69b") -- Project MacGyver Content
setManifestid(464921, "447948026586350606", 0)
addappid(464922, 1, "eac6bbbec707bf8704010ee79ecefca58960798dea2fc434e0b68265952b4c72") -- Windows
setManifestid(464922, "2257851184703518869", 0)
addappid(464923, 1, "85ff22504da07740b09b331ec2e8fac8d6254f645d806dc0a73a6504957386e7") -- OSX
setManifestid(464923, "8581551019178732520", 0)
addappid(464924, 1, "7e146ce13064ba4d7b1a9bab779ead25841086730c7ed64d50cdb0ec61d9f2c0") -- Linux
setManifestid(464924, "4325663035446729888", 0)
addappid(464926, 1, "45a14af6bba64488abd49702ce7da791d177d882bb18293aa12b876cdf0b5b1f") -- Project MacGyver ModTools Windows
setManifestid(464926, "6281924960710939694", 0)

-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 0)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 0)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Surviving Mars - Stellaris Dome Set (AppID: 801650)
addappid(801650)
addtoken(801650, "13891198710111036148")
addappid(801650, 1, "8501eedb1ac754c193e98c80d7dc934187f34e5bbcd16d977b2dfbab737dd49d") -- Surviving Mars - Stellaris Dome Set - Surviving Mars - Stellaris Dome Set (801650) Depot
setManifestid(801650, "5226763798194045649", 0)

-- Surviving Mars Space Race (AppID: 801670)
addappid(801670)
addappid(801670, 1, "fd78a781943e09c00fd42fea0af6ba84fb98a6f79b7b48a2b0833f4c74c4f36a") -- Surviving Mars Space Race - Surviving Mars - Expansion Pack 1 (801670) Depot
setManifestid(801670, "3653009730862117454", 0)

-- Surviving Mars - Art Book (AppID: 801680)
addappid(801680)
addtoken(801680, "5042068378699435322")
addappid(801680, 1, "c2f7642835cd001fe01e1fa6550920767456e89d4d75ccf7c8c66fe7fa5a2200") -- Surviving Mars - Art Book - Surviving Mars - Art Book (801680) Depot
setManifestid(801680, "1061448776058161571", 0)

-- Surviving Mars Mysteries Resupply Pack (AppID: 801690)
addappid(801690)
addappid(801690, 1, "ecdee0884897327733c9491f7c66e5d93125c6f5cce5954bf2ac580bea00953f") -- Surviving Mars Mysteries Resupply Pack - Surviving Mars - Content Pack 1  (801690) Depot
setManifestid(801690, "2609102183933092711", 0)

-- Surviving Mars Deluxe Edition Upgrade Pack (AppID: 801710)
addappid(801710)
addappid(801710, 1, "67d10f7d83946b45764179a0fc5deb652583cdb0e66eb2ecef77f3775279cb2a") -- Surviving Mars Deluxe Edition Upgrade Pack - Surviving Mars - Deluxe Edition Upgrade Pack (801710) Depot
setManifestid(801710, "2364341209585381660", 0)

-- Surviving Mars - Wallpaper (AppID: 801720)
addappid(801720)
addtoken(801720, "1442774856955222404")
addappid(801720, 1, "19fcaae32c77f6f2a68f376b9dc775b3373f073d613b84158f4d6e916687fd06") -- Surviving Mars - Wallpaper - Surviving Mars - Wallpaper (801720) Depot
setManifestid(801720, "262274256123306684", 0)

-- Surviving Mars - OST (AppID: 801730)
addappid(801730)
addappid(801730, 1, "c4be808cfa4bd76910f24621d70f17729c8d63df01e14c04d2741ec847ff8001") -- Surviving Mars - OST - Surviving Mars - OST (801730) Depot
setManifestid(801730, "6733073739076920202", 0)

-- Surviving Mars Green Planet (AppID: 952890)
addappid(952890)
addappid(952890, 1, "2b3203730a5f2892f20d5775a8275327a524a4dba20f479cb425cedd612f7e2d") -- Surviving Mars Green Planet - Surviving Mars: Green Planet (952890) Depot
setManifestid(952890, "7542913245687107314", 0)

-- Surviving Mars Marsvision Song Contest (AppID: 952891)
addappid(952891)
addappid(952891, 1, "cfcd99508b5250a8021de5d0a2eec7dbaa49a33e1e3e27194e2de8b96e9d8a44") -- Surviving Mars Marsvision Song Contest - Surviving Mars: Marsvision Song Contest (952891) Depot
setManifestid(952891, "6881951248507851089", 0)

-- Surviving Mars Colony Design Set (AppID: 952892)
addappid(952892)
addappid(952892, 1, "4d40031770c4e1aad6fade7d77b36129a60221df703699b19c320e93768b4b71") -- Surviving Mars Colony Design Set - Surviving Mars: Colony Design Set (952892) Depot
setManifestid(952892, "2842524164827190883", 0)

-- Surviving Mars Project Laika (AppID: 1042360)
addappid(1042360)
addappid(1042360, 1, "68ab7a446ff601357fcac16c17032d741e9309641f5f9eec3612fba648bd1fe8") -- Surviving Mars Project Laika - Surviving Mars: P Pack (1042360) Depot
setManifestid(1042360, "8563063333793013945", 0)

-- Surviving Mars In-Dome Buildings Pack (AppID: 1497160)
addappid(1497160)
addappid(1497160, 1, "0930eb2a22673fe9fb9155e75b69bdfff3d0782bee47288af1526846caf64fce") -- Surviving Mars In-Dome Buildings Pack - Kerwin (1497160) Depot
setManifestid(1497160, "5496300233771063717", 0)

-- Surviving Mars Below and Beyond (AppID: 1498760)
addappid(1498760)
addappid(1498760, 1, "e579faeefaef2605c3bf6c427c009e4a6089b81fb34f69d82cb65c2d6523dc9e") -- Surviving Mars Below and Beyond - Picard (1498760) Depot
setManifestid(1498760, "4778159180374871016", 0)
addappid(1498761, 1, "161530193b45bba4e529db132576331aac6b5bde9943c07d6a771cb329941600") -- Surviving Mars Below and Beyond - Picard OSX (1498760) Depot
setManifestid(1498761, "5198683564729496470", 0)

-- Surviving Mars Mars Lifestyle Radio (AppID: 1657990)
addappid(1657990)
addappid(1657990, 1, "68ed4139b2c5af9331bed2ecf206018c6b7ac3e0f83c14f7bc74d4caddbe0650") -- Surviving Mars Mars Lifestyle Radio - Surviving Mars: Wubbo (1657990) Depot
setManifestid(1657990, "9107929283703558595", 0)

-- Surviving Mars Revelation Radio Pack (AppID: 1658000)
addappid(1658000)
addappid(1658000, 1, "ff63b000dc6fb546f2670482cabbabfc7799823dd3b15c9807c7e69985f76018") -- Surviving Mars Revelation Radio Pack - Surviving Mars: Ockels (1658000) Depot
setManifestid(1658000, "3522520792933738256", 0)

-- Surviving Mars Future Contemporary Cosmetic Pack (AppID: 1658001)
addappid(1658001)
addappid(1658001, 1, "7c42d8d1fc127216df54d9e4fce56cb1803e2e75fb8e1f9badbae40a40429526") -- Surviving Mars Future Contemporary Cosmetic Pack - Surviving Mars: Ariane (1658001) Depot
setManifestid(1658001, "8872748289433894216", 0)

-- Surviving Mars Martian Express (AppID: 1816780)
addappid(1816780)
addappid(1816780, 1, "a101675c3cea66fad25911cec8732c60510faa7219b18d1334853ad98797467d") -- Surviving Mars Martian Express - Surviving Mars: Prunariu (1816780) Depot
setManifestid(1816780, "7060210691217510984", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(802700) -- Surviving Mars Season Pass
