addappid(1997480)
addappid(1997481,0,"6e01ca386e2eaaa9606f025f59618ddb12818c3b17f5857d2afba781fafe9270")
setManifestid(1997481,"4671444676535002679")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]