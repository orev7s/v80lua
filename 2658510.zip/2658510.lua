-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(2658510) -- Animal Shelter 2

-- MAIN APP DEPOTS
addappid(2658511, 1, "a48c2e31217f8135a3c94b510a5fcc9053ec566353f54bc6a17f9e42c2e36481") -- Depot 2658511
setManifestid(2658511, "1871937279619017310", 0)
