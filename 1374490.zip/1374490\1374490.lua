addappid(1374490)
addappid(228989)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1374491,0,"e1a3b5ad6a0fbda32b1fceadce8be5fe365e6c98dcc654bfdef62b6aa01f48d5")
setManifestid(1374491,"3459719057240987288")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]