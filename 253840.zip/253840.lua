-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy

-- MAIN APPLICATION
addappid(253840) -- Shantae: Half-Genie Hero

-- MAIN APP DEPOTS
addappid(253841, 1, "2b179febc3199ba5e83ba4dbf43d6d067b18a7ecb0d66a2d58fd1b378bace83a") -- Shantae: Half-Genie Hero Content
setManifestid(253841, "697900514062617528", 0)

-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
