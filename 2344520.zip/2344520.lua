-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(2344520) -- Diablo® IV
-- MAIN APP DEPOTS
addappid(2344521, 1, "bf58e60bf2aca37197c7bc279a6b48b726131fa8b6d07bd12909d8a251252c65") -- Depot 2344521
setManifestid(2344521, "4792759086786337867", 72759087588)
addappid(2344522, 1, "8b885b87e01a772da363b1cd92f8fb0faac6f727acb321aef2ae9c4ce938a4bf") -- Depot 2344522
setManifestid(2344522, "2804981501307027654", 423724878)
addappid(2344523, 1, "95a541fb3a2967fb73875c96ad8f56e3cbb5e3eafb742a4a1671847e722b543a") -- Depot 2344523
setManifestid(2344523, "7435362687459974044", 1525388655)
addappid(2344524, 1, "5eab48ada2fbd0681f2548f19de28ffb437ab06f912c4adef37b7d4a1d82df40") -- Depot 2344524
setManifestid(2344524, "1791005504593600266", 1928920050)
addappid(2344525, 1, "222f83dd58e78880080c90ac47ec8b18598682e8d9cf1eb5d9c971838ae9982a") -- Depot 2344525
setManifestid(2344525, "455952894560026898", 2016906528)
addappid(2344526, 1, "36773de6a67ec1ab03be4f3608e84d6065093969f89f13a78938d568c64dbcdc") -- Depot 2344526
setManifestid(2344526, "2698013680664388428", 1794953553)
addappid(2344527, 1, "e9ca21ab9bc1f84a13c3ab8c2d16770896c62bded180208739d12966d0a5a74e") -- Depot 2344527
setManifestid(2344527, "2730223001243832733", 1952287586)
addappid(2344528, 1, "8208caaf454b35c95674eea8f70a58cc4daf109424ce89ff87f15a06e0c57002") -- Depot 2344528
setManifestid(2344528, "4868334574415422129", 1829214131)
addappid(2344529, 1, "cc7acfe91d9730e4bf1d3d18e3c3c508c138f3308b65e1b5430171c037ad1b72") -- Depot 2344529
setManifestid(2344529, "273184445838866554", 2224119105)
addappid(2452970, 1, "02d4526ba2550dee890eb72533f01be38dbfa301a86b4c9ce95bf1a00cb4320f") -- Depot 2452970
setManifestid(2452970, "613821691196489505", 1891818352)
addappid(2452971, 1, "26b03b20e224538d7f7d02d44f1b6e6a64dc028b2950ae50570a6871607a168d") -- Depot 2452971
setManifestid(2452971, "4405682680161286413", 1948166296)
addappid(2452972, 1, "d7bf30f74044cedc899e1a38a4ade22b52a682d843b76a530652c0b4a7510a29") -- Depot 2452972
setManifestid(2452972, "4127206478451286924", 1790970975)
addappid(2452973, 1, "8e3ae2409f103be46cbd55a941b370d6a19438516d0cf68c4fea29a7e2a0c018") -- Depot 2452973
setManifestid(2452973, "3553242184039306588", 1931728282)
addappid(2452974, 1, "6db8a9ba8df12b66ed9f14a1e18c176f6a44522ab7c4ca3b37e9964ea0a3eb5b") -- Depot 2452974
setManifestid(2452974, "868214670449482918", 1525388655)
addappid(2452975, 1, "22c898c54175ad295a2c2794c9ea4b44278e36f2a4f65362d48b6cbe284388ea") -- Depot 2452975
setManifestid(2452975, "1432517896829171846", 1766494832)
addappid(2452976, 1, "88ea785161f2912b8884373d4e8cdb42c8105a3f689cd44c89116d9b38abd476") -- Depot 2452976
setManifestid(2452976, "6143367495984190722", 1759644669)
-- DLCS WITH DEDICATED DEPOTS
-- Diablo IV - High-Resolution Assets (AppID: 2453170)
addappid(2453170)
addappid(2453170, 1, "962a85322d266e4dc3ca0de3fe2d065dd2c270c3322c73ceb0d742f960ceb77e") -- Diablo IV - High-Resolution Assets - Depot 2453170
setManifestid(2453170, "6210613392391735707", 61506568575)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2453190) -- Diablo IV - Crypt Hunter Pack
addappid(2572010) -- Diablo IV - Standard Edition
addappid(2572020) -- DiabloIV - Digital Deluxe Edition
addappid(2572030) -- DiabloIV - Ultimate Edition
addappid(2575620) -- Diablo IV - Tributes of Rime Pack
addappid(2575630) -- Diablo IV - Shards of Vulcan Pack
addappid(2575640) -- Diablo IV - Fathers Judgement Pack
addappid(2721550) -- Diablo IV - Beckoning Thunder Pack
addappid(2721560) -- Diablo IV - Dark Pathways Pack
addappid(2721570) -- Diablo IV - Vitreous Scourge Pack
addappid(2941030) -- Diablo IV Vessel of Hatred - Standard Edition
addappid(2941050) -- Diablo IV Vessel of Hatred - Deluxe Edition
addappid(2941060) -- Diablo IV Vessel of Hatred - Ultimate Edition
addappid(3043530) -- Diablo IV Vessel of Hatred
addappid(3184520) -- Diablo IV - Rebels Cache Platinum Pack
addappid(3559880) -- Diablo IV - Deaths Messenger Platinum Pack