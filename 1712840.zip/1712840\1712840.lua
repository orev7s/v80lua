addappid(1712840)
addappid(1712841,0,"dad684f848d851329295fc8c0f76dfb511663bd905a2d8034a696cfaae396703")
addappid(1712842,0,"c4af5b8df243bf3c1186ecacfa2a53537869932b2562dcf0eb0eb6920d3f13c9")
addappid(1712844,0,"1083695a701956ed352ac5b0b0b3a54cc6219164fa9e235ec2cd7767db7848cc")
setManifestid(1712841,"2922594229071620517")
setManifestid(1712842,"4978354088493661969")
setManifestid(1712844,"8097817127191144599")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]