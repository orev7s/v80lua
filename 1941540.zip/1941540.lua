-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @f1uxin on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy / https://discord.gg/m8PxjTwrnv
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(1941540) -- Mafia: The Old Country
-- MAIN APP DEPOTS
addappid(1941541, 1, "47c1ea957b9ecc8662a117fa6b19eea01ed30ef06478a364110fe40afa4e9f0e") -- Depot 1941541
setManifestid(1941541, "7389755233066346624", 48103885967)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- .NET 4.0 Redist (Shared from App 228980)
setManifestid(229002, "7260605429366465749", 50450161)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3262000) -- Mafia The Old Country - Soldato Pack
addappid(3269260) -- Mafia The Old Country - Padrino Pack
addappid(3269270) -- Mafia The Old Country - Gatto Nero Pack
addappid(3269280) -- Mafia The Old Country - Soundtrack and Digital Artbook