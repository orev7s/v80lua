-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(247430) -- Hitman: Contracts

-- MAIN APP DEPOTS
addappid(247431, 1, "182bcba5d65a64b9c0dc8156b346cb0549ee2af8a977f547686343e596012aae") -- Hitman Contracts Content
setManifestid(247431, "9036949535771899383", 0)
addappid(247432, 1, "e7df4fc7093e7772a0654e8df008d29afecfd28c74486250257102383c89f5ff") -- English
setManifestid(247432, "2455568948625319926", 0)
addappid(247433, 1, "fd17f44320430619c3cbac87b0ad2e056ddf0477250f4deb2001e3b4dea67a2c") -- French
setManifestid(247433, "3132939751871621720", 0)
addappid(247434, 1, "b556b38776a5a50f81fc0af064375f3f810e6834e8e1d6d0530e992da719d333") -- Italian
setManifestid(247434, "1909916003904629517", 0)
addappid(247435, 1, "c9f919d3371c41c64883be0b176efb9f2eb85ba1aa0fc877ce537c02bff42216") -- German
setManifestid(247435, "7020066482023277527", 0)
addappid(247436, 1, "66afd23830b046aac40aa68af0ba7dc288025377772d4efd7f9a75866e745fdd") -- Spanish
setManifestid(247436, "505095712992583969", 0)
