addappid(1642620)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(1642621,0,"37e5c69516ba3fe109dd57a96a172e4f586356fa6fcc47efe6ac465cb2370b1a")
setManifestid(1642621,"8833501137017413398")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]