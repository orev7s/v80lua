-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(883710) -- Resident Evil 2

-- MAIN APP DEPOTS
addappid(883711, 1, "638f06d7569ecead867a27e5934284446cbf9a8740638265114ad27fb4ce2f27") -- RESIDENT EVIL 2
setManifestid(883711, "1276883776777242280", 0)
addappid(883712, 1, "64aebcf6ac355fbc07d5edeb037ef5d1ecdd3415cc520f397e3674edd078fd84") -- BIOHAZARD RE:2
setManifestid(883712, "4308061999662339354", 0)
addappid(883713, 1, "f0afbce3fe63581d5b1179fe571e137761ed6ca98455ee6606650f4b09f5249e") -- RESIDENT EVIL 2 TEST1
setManifestid(883713, "5793354868189524285", 0)
addappid(883714, 1, "27631926b9162a5355df9eb09fdd90efe7631dcb86a2a34edbbd04fdb3ddbe02") -- BIOHAZARD RE:2 TEST1
setManifestid(883714, "5577253524310892660", 0)
addappid(883715, 1, "a8afa9147111fd2590f12a2efafb74a91f4c9ac15eb56cdaaee4eb70b8b513ee") -- RESIDENT EVIL 2 TEST2
setManifestid(883715, "1048038669598412361", 0)
addappid(883716, 1, "cdbca1dcd27611eab5a12f53db738d8d0012572146b930e71578f21d7662317c") -- BIOHAZARD RE:2 TEST2
setManifestid(883716, "6893789202571151145", 0)
addappid(883717, 1, "66abdff706240ae3c2faa39ccb3d9cf90c2ba61cf80d0b94b5e40fc467e8dab5") -- RESIDENT EVIL 2 TEST3
setManifestid(883717, "594447121131702131", 0)
addappid(883718, 1, "bed9e589ec8c4a42f4f4c4165ea55ef524cc1a746466f0cd0dcec717d7422fd0") -- BIOHAZARD RE:2 TEST3
setManifestid(883718, "5949125275142682173", 0)
addappid(920572, 1, "dbd486a37d92e45a6cb1125e71b80bd31ce74e3732a72384b26103d71f27af5c") -- RESIDENT EVIL 2 WallpaperPack
setManifestid(920572, "4813678597596508063", 0)
addappid(883719, 1, "efe4f1a93047a0d60991536337e376ccc14e11b701a2a7b9140b0080c53bf5ea") -- SERIAL
setManifestid(883719, "2758490342177349494", 0)

-- SHARED DEPOTS (from other apps)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Resident Evil 2 - Leon Costume Arklay Sheriff (AppID: 920560)
addappid(920560)
addappid(920560, 1, "ed972f698b50ed84c8edc351a84adc57ef81a9d75dfdc05f87297e2caa4741e3") -- Resident Evil 2 - Leon Costume Arklay Sheriff - RESIDENT EVIL 2 - Leon Costume: Arklay Sheriff (920560) デポ
setManifestid(920560, "3707796803102380515", 0)

-- Resident Evil 2 - Leon Costume Noir (AppID: 920561)
addappid(920561)
addappid(920561, 1, "bb62b32357a66bdfb10eb2a374912ffa9ba58924252603e1935226520aea8513") -- Resident Evil 2 - Leon Costume Noir - RESIDENT EVIL 2 - Leon Costume: Noir (920561) デポ
setManifestid(920561, "7777910790301298561", 0)

-- Resident Evil 2 - Claire Costume Military (AppID: 920562)
addappid(920562)
addappid(920562, 1, "71020da471eab8cf287e8b1364dc41774641785316eef961b1bf872b2e81426b") -- Resident Evil 2 - Claire Costume Military - RESIDENT EVIL 2 - Claire Costume: Military (920562) デポ
setManifestid(920562, "6204099557140371425", 0)

-- Resident Evil 2 - Claire Costume Noir (AppID: 920563)
addappid(920563)
addappid(920563, 1, "e970b08de60e4726cf9020d6eba9cc48c1dc79053e7000033ddb28c328c7ee34") -- Resident Evil 2 - Claire Costume Noir - RESIDENT EVIL 2 - Claire Costume: Noir (920563) デポ
setManifestid(920563, "6596791651819430825", 0)

-- Resident Evil 2 - Claire Costume Elza Walker (AppID: 920564)
addappid(920564)
addappid(920564, 1, "194df6fccffb69f0b91badf8550570c554f9dd2ba7a8ce025c23b2e1b707de51") -- Resident Evil 2 - Claire Costume Elza Walker - RESIDENT EVIL 2 - Claire Costume: Elza Walker (920564) デポ
setManifestid(920564, "4567165216698197061", 0)

-- Resident Evil 2 - Leon Costume 98 (AppID: 920565)
addappid(920565)
addappid(920565, 1, "cc4cc3692f32ee8a0e912af30b2a6c7d63ca6625dfe904bc9c8a7fe7e27c3f45") -- Resident Evil 2 - Leon Costume 98 - RESIDENT EVIL 2 - Leon Costume: '98 (920565) デポ
setManifestid(920565, "510135806956799705", 0)

-- Resident Evil 2 - Claire Costume 98 (AppID: 920566)
addappid(920566)
addappid(920566, 1, "747b360f6029581b9e552dbadd556684c85b21f80c6d812a6ea68f48b8e38630") -- Resident Evil 2 - Claire Costume 98 - RESIDENT EVIL 2 - Claire Costume: '98 (920566) デポ
setManifestid(920566, "7570154016218765728", 0)

-- Resident Evil 2 - Original Ver. Soundtrack Swap (AppID: 920567)
addappid(920567)
addappid(920567, 1, "1cb02d129e55942d541b1f1c88365d043c8a0cce730a25ec3c56a15c77523def") -- Resident Evil 2 - Original Ver. Soundtrack Swap - RESIDENT EVIL 2 - Original Ver. Soundtrack Swap (920567) デポ
setManifestid(920567, "3579676083509558298", 0)

-- Resident Evil 2 - Deluxe Weapon Samurai Edge - Albert Model (AppID: 920568)
addappid(920568)
addappid(920568, 1, "dd350bfb23bfd3c931f2589bab2b0ce0eff6704491a777ff4db51439cb2bf94c") -- Resident Evil 2 - Deluxe Weapon Samurai Edge - Albert Model - RESIDENT EVIL 2 - Deluxe Weapon: Samurai Edge - Albert Model (920568) デポ
setManifestid(920568, "3078911744541340384", 0)

-- Resident Evil 2 - Deluxe Weapon Samurai Edge - Jill Model (AppID: 920569)
addappid(920569)
addtoken(920569, "9210640672866114780")
addappid(920569, 1, "d5951968c5c68af4a7e4cca71625a71dfb289fc98e170a6e25e87221faac71f5") -- Resident Evil 2 - Deluxe Weapon Samurai Edge - Jill Model - RESIDENT EVIL 2 - Deluxe Weapon: Samurai Edge - Jill Model (920569) デポ
setManifestid(920569, "3611674127107630311", 0)

-- Resident Evil 2 - Deluxe Weapon Samurai Edge - Chris Model (AppID: 920570)
addappid(920570)
addtoken(920570, "12658968023885460684")
addappid(920570, 1, "7b918b3037406996a31fddfade6f149ee7a41e6dff77548200886097deb98ec6") -- Resident Evil 2 - Deluxe Weapon Samurai Edge - Chris Model - RESIDENT EVIL 2 - Deluxe Weapon: Samurai Edge - Chris Model (920570) デポ
setManifestid(920570, "7297738854267208684", 0)

-- Resident Evil 2 - All In-game Rewards Unlocked (AppID: 920571)
addappid(920571)
addappid(920571, 1, "04ba2f12b585affc9ed2cc03b5b04f136e6159ea7430892ae71c5a541c7ae427") -- Resident Evil 2 - All In-game Rewards Unlocked - RESIDENT EVIL 2 - All In-game Rewards Unlock (920571) デポ
setManifestid(920571, "7444394391996341768", 0)

-- DLCS EXCLUDED (NO DEPOT KEYS, NO DEDICATED DEPOTS)
-- addappid(1335170) -- Resident Evil 2 Original Soundtrack (no keys available)
