-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(997010, 1, "e0a4648d4ca142f34287122872b86bd305cacbe1ff627fe6f774aa1b0576ed6f") -- Police Simulator: Patrol Officers

-- MAIN APP DEPOTS
addappid(997011, 1, "788e33ebc2e38174d9b613b57ed47947aacaf7399a6bbd32762161e56ce34d62") -- Project Bavaria Content
setManifestid(997011, "4881193988811544067", 0)

-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2009550) -- Police Simulator Patrol Officers Urban Terrain Vehicle DLC
addappid(2199030) -- Police Simulator Patrol Officers Compact Police Vehicle DLC
addappid(2210960) -- Police Simulator Patrol Officers Guardian Police Vehicle DLC
addappid(2350410) -- Police Simulator Patrol Officers Highway Patrol Expansion
addappid(2513250) -- Police Simulator Patrol Officers Multipurpose Police Vehicle DLC
addappid(2527820) -- Police Simulator Patrol Officers Surveillance Police Vehicle DLC
addappid(2527830) -- Police Simulator Patrol Officers Warden Police Vehicle DLC
addappid(2893870) -- Police Simulator Patrol Officers Unmarked Police Vehicle Pack
addappid(2893880) -- Police Simulator Patrol Officers Special Police Vehicle Pack 
addappid(3048950) -- Police Simulator Patrol Officers Tropical Taskforce Pack
addappid(3167630) -- Police Simulator Patrol Officers Fast Pursuit Police Vehicle DLC
addappid(3597210) -- Police Simulator Patrol Officers - Season Pass
addappid(3597220) -- Police Simulator Patrol Officers - Vehicle Customization Pack
addappid(3768290) -- Police Simulator Patrol Officers Adventurer Police Vehicle DLC
