addappid(1380070)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228989)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229005)
setManifestid(229005,"7992454656023763365")
addappid(229006)
setManifestid(229006,"1784011429307107530")
addappid(229007)
setManifestid(229007,"4477590687906973371")
addappid(1380071,0,"35bbeb039ac8fcae5ecedb7bf9592c5fbead89187c78e7fca100ccc0b85d39a9")
setManifestid(1380071,"6853465713138396269")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]