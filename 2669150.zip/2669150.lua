-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @F1uxin on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!)

-- MAIN APPLICATION
addappid(2669150) -- Mindlock - The Apartment

-- MAIN APP DEPOTS
addappid(2669152, 1, "942f719ef077b28da08ede695bf551f7a189e17e6cd4fe171223fab07cb5c304") -- Game Content (Linux Binaries)
setManifestid(2669152, "8194567364590138612", 0)

-- DLCS EXCLUDED (NO DEPOT KEYS, NO DEDICATED DEPOTS)
-- addappid(3303050) -- Mindlock - The Apartment Original Soundtrack (no keys available)
