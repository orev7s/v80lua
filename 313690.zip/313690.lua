-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @F1uxin on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!)

-- MAIN APPLICATION
addappid(313690) -- LEGO® Batman™ 3: Beyond Gotham

-- MAIN APP DEPOTS
addappid(313691, 1, "fa7bb640190fa418f844f89156da30e1c5b6d5524f881a674b78a783a5cb5c71") -- LEGO Batman 3: Beyond Gotham Content
setManifestid(313691, "4443902272311026638", 0)
addappid(313692, 1, "fc88e3808e53d2662d26947bf1d1198fe9c2b1a230f6308db81ea46c6949443f") -- LEGO Batman 3: Beyond Gotham Depot Mac
setManifestid(313692, "7475121684167367128", 0)

-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- LEGO Batman 3 Beyond Gotham DLC Man of Steel (AppID: 327170)
addappid(327170)
addappid(327170, 1, "8481fc0feb07db26e4cd81dd97bcd4f35e4fcb95271773d89ecb06f4a2a25acd") -- LEGO Batman 3 Beyond Gotham DLC Man of Steel - LEGO Batman 3: Beyond Gotham DLC: Man of Steel (327170) Depot
setManifestid(327170, "2020646298349048643", 0)
addappid(313695, 1, "7090f0160820e2ea1193680a66f4506fcfbd8b4f5917605dc7765afbcd542148") -- LEGO Batman 3 Beyond Gotham DLC Man of Steel - Mac DLC: Man of Steel (PC 327170)
setManifestid(313695, "339197424601476617", 0)

-- LEGO Batman 3 Beyond Gotham DLC Batman 75th Anniversary (AppID: 327171)
addappid(327171)
addappid(327171, 1, "143b434a96c55b2c106679789257f90f56a666c0a3c918bb9c8770c034d4a887") -- LEGO Batman 3 Beyond Gotham DLC Batman 75th Anniversary - LEGO Batman 3: Beyond Gotham DLC: Batman 75th Anniversary (327171) Depot
setManifestid(327171, "4238496217585822049", 0)
addappid(313696, 1, "faa04a8fe37b2064226c6a34504dab69da0e7054e30cde2f3cbe654ce2a91148") -- LEGO Batman 3 Beyond Gotham DLC Batman 75th Anniversary - Mac DLC: Batman 75th Anniversary (PC 327171)
setManifestid(313696, "683981261730635318", 0)

-- LEGO Batman 3 Beyond Gotham DLC Dark Knight (AppID: 327172)
addappid(327172)
addappid(327172, 1, "8a425720898dcfd078fc33fdf9ccf69b6f192a14f4a5112c26f592cef4612fa0") -- LEGO Batman 3 Beyond Gotham DLC Dark Knight - LEGO Batman 3: Beyond Gotham DLC: Dark Knight (327172) Depot
setManifestid(327172, "6398719775382247543", 0)
addappid(327178, 1, "aa53309e83aa7e9a1cbad6bd052bfe7c20cbf7d9b0a52c460e2e0bcfd9bd4cca") -- LEGO Batman 3 Beyond Gotham DLC Dark Knight - Mac DLC: Dark Knight (PC 327172)
setManifestid(327178, "5605480070281958561", 0)

-- LEGO Batman 3 Beyond Gotham DLC Batman of the Future Character Pack (AppID: 327173)
addappid(327173)
addappid(327173, 1, "1c7d5eff9053e8ce944771da693bb9382a76ea6fa212ea47e39d5e5610d38a16") -- LEGO Batman 3 Beyond Gotham DLC Batman of the Future Character Pack - LEGO Batman 3: Beyond Gotham DLC: Batman of the Future Character Pack (327173) Depot
setManifestid(327173, "4912572547395676561", 0)
addappid(313693, 1, "1c375c3af1087b002b2cf4306708071900c080d8459cb0a6e602524319c86a3c") -- LEGO Batman 3 Beyond Gotham DLC Batman of the Future Character Pack - Mac DLC: Batman of the Future Character Pack (PC 327173)
setManifestid(313693, "8952656108740785958", 0)

-- LEGO Batman 3 Beyond Gotham DLC Rainbow Character Pack (AppID: 327174)
addappid(327174)
addtoken(327174, "7591203462887189837")
addappid(327174, 1, "b285e21faa32afed3d6b8eceeda5239d6dc806e8de7e126721dad6b9915e3e49") -- LEGO Batman 3 Beyond Gotham DLC Rainbow Character Pack - LEGO Batman 3: Beyond Gotham DLC: Rainbow Character Pack (327174) Depot
setManifestid(327174, "964649925611933701", 0)
addappid(313694, 1, "e5a15c09ca59f960ebbb6aa3009524edc727c5f2eb96e335234c88c0380c4c91") -- LEGO Batman 3 Beyond Gotham DLC Rainbow Character Pack - Mac DLC: Rainbow Character Pack (PC 327174)
setManifestid(313694, "4541054431822865910", 0)

-- LEGO Batman 3 Beyond Gotham DLC Arrow (AppID: 327175)
addappid(327175)
addappid(327175, 1, "312e123f3707b6b9e8b4ae34556aabc7b4bbbf3e44a3d3fdcb93c74d4fcbe472") -- LEGO Batman 3 Beyond Gotham DLC Arrow - LEGO Batman 3: Beyond Gotham DLC: Arrow (327175) Depot
setManifestid(327175, "7803373803440355626", 0)
addappid(313698, 1, "d2f2488881c2505e44be1f46db944a001690fcfe55d64a515f3944f238d0ce33") -- LEGO Batman 3 Beyond Gotham DLC Arrow - Mac DLC: Arrow (PC 327175)
setManifestid(313698, "392792081728617917", 0)

-- LEGO Batman 3 Beyond Gotham DLC The Squad (AppID: 327176)
addappid(327176)
addtoken(327176, "12429466481375319226")
addappid(327176, 1, "d68d93e47d2b116a21d590cdfeb4fa4c7a65205f8e14c21f5b951fdbcf5d9535") -- LEGO Batman 3 Beyond Gotham DLC The Squad - LEGO Batman 3: Beyond Gotham DLC: The Squad (327176) Depot
setManifestid(327176, "5382487805151043846", 0)
addappid(313699, 1, "973d3b5e50dc94b3f03b427f448774c35b5defe5c0988e1236c50ff517717cab") -- LEGO Batman 3 Beyond Gotham DLC The Squad - Mac DLC: The Squad (PC 327176)
setManifestid(313699, "3793953187342338197", 0)

-- LEGO Batman 3 Beyond Gotham DLC Bizarro (AppID: 327177)
addappid(327177)
addtoken(327177, "4196379036651091314")
addappid(327177, 1, "bc7038b8b312c757fdb7ecfa7988ff655c5e3ce73c44dc7cf894d9bdb8c78ad5") -- LEGO Batman 3 Beyond Gotham DLC Bizarro - LEGO Batman 3: Beyond Gotham DLC: Bizarro (327177) Depot
setManifestid(327177, "4325475610853729515", 0)
addappid(313697, 1, "741daa194ff417f5c151ace9d5af463216d250d346f6336e318d77fd13319f4d") -- LEGO Batman 3 Beyond Gotham DLC Bizarro - Mac DLC: Bizarro (PC 327177)
setManifestid(313697, "4763929614456373971", 0)

-- LEGO Batman 3 Beyond Gotham DLC Heroines and Villainesses Character Pack (AppID: 335800)
addappid(335800)
addappid(335800, 1, "e0546b4f705797fda23ad0cdcbeb6cf29c4ced267fcce18340c0c396ef20bd31") -- LEGO Batman 3 Beyond Gotham DLC Heroines and Villainesses Character Pack - LEGO Batman 3: Beyond Gotham DLC: Heroines and Villainesses Character Pack (335800) Depot
setManifestid(335800, "317296534116282674", 0)
addappid(327179, 1, "d8788b279f5acaa65f4435f1a3ae6d2c6ad0c7d2da736a8eb543ce1657682c63") -- LEGO Batman 3 Beyond Gotham DLC Heroines and Villainesses Character Pack - LEGO Batman 3: Heroines and Villainesses Mac
setManifestid(327179, "6035738132262626744", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(330860) -- LEGO Batman 3 Beyond Gotham Season Pass
addtoken(330860, "16153299654692621777")
