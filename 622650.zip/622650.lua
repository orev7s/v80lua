-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(622650) -- Bendy and the Ink Machine

-- MAIN APP DEPOTS
addappid(622651, 1, "525bb062dc2acf46744d4fbd02044d28bad4f3266fe3c8e42bd6fdd1d2030e97") -- Bendy and the Ink Machine Depot WIN_64
setManifestid(622651, "3839364653133507972", 0)
addappid(622652, 1, "ff3dc383c775b96130d7be30d5b3a0b9d28a8a761f48663a342206e48f58ff0c") -- Bendy and the Ink Machine Depot WIN_32
setManifestid(622652, "1235752666285185366", 0)
addappid(622653, 1, "32f8523448cd804dbdb79f690000a9a39ec66e90f2b4b8db6dee433092a4abf4") -- Bendy and the Ink Machine Depot LINUX
setManifestid(622653, "8875080210494677398", 0)
addappid(622654, 1, "b05fea5e1e495e4c071fee38d3d800ab0c2bc123fbfc9609da2bf49f614ac42e") -- Bendy and the Ink Machine Depot MAC
setManifestid(622654, "779084498159863616", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(622660) -- Bendy and the Ink Machine Chapter Three
addappid(622661) -- Bendy and the Ink Machine Chapter Two
addappid(730000) -- Bendy and the Ink Machine Chapter Four
