addappid(1506510)
addappid(1506511,0,"dbbc2e988bb44dc68bab3e401f7b9ba7d1933a8196961987ff36c46e189297a1")
setManifestid(1506511,"2517148997334290483")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]