-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(434460) -- Rock of Ages 2

-- MAIN APP DEPOTS
addappid(434461, 1, "3a02fbf8f2b8f47ee3ba37a0e4fa6e8f4b9e794dd2d95abd4cbf41c71c5721cd") -- Rock of Ages 2 Content
setManifestid(434461, "7548472794906374406", 0)
addappid(434462, 1, "ff41ed9ac0228ce19c30fc6ae2aa20cdb4dc3bbc185c510910fdb5ee01227e64") -- Rock of Ages 2 Win64
setManifestid(434462, "8674897469296333998", 0)

-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- OpenAL 2.0.7.0 Redist (Shared from App 228980)
setManifestid(229020, "5799761707845834510", 0)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- PhysX System Software 9.14.0702 (Shared from App 228980)
setManifestid(229033, "2059065101492814639", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Rock of Ages 2 - Classic Pack (AppID: 645970)
addappid(645970)
addappid(434463, 1, "f77c2bb98646e339a89a460e92088ca71a430d3bb7478951b27905181a2bae5c") -- Rock of Ages 2 - Classic Pack - Rock of Ages 2 Original Soundtrack
setManifestid(434463, "4680995194679294570", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(700900) -- Rock of Ages 2 - Binding of Isaac Pack
