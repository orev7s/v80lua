-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪username - f1uxin, on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy / https://discord.gg/m8PxjTwrnv
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(566530) -- Mass Exodus Redux
-- MAIN APP DEPOTS
addappid(566532, 1, "6898bfe587c9ff4f75290423f896ad874b8a3447973aea22fa2c930f5562b2ea") -- Mass Exodus PC Client
setManifestid(566532, "728118854358957615", 5801176766)
addappid(566531, 1, "46c61cb14ff4b82a97b73710b99cfa43b22f3ffd7fe287f21992b5b0a8d899e9") -- Mass Exodus VR Client
setManifestid(566531, "5539609951378597983", 4405763672)