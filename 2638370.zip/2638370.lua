-- Made by f1uxin, please read the read me TXT file.
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship
addappid(2638370) -- Five Nights at Freddy's: Into the Pit

-- MAIN APP DEPOTS
addappid(2638371, 1, "8852cf8d7bc2edf25ef5fa623e3a6811b710f8c4e6ed3d59de3db7f7a9776210") -- Main Game Content (Windows Content)
setManifestid(2638371, "5153321941414034057", 0)
