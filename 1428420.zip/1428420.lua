-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(1428420)
addappid(1428421, 1, "ac43af7109101c47a87ace9779caefb38f41bc5c97d6e7c9eb8e76652939e6c9") 
setManifestid(1428421, "826467149326475415", 3714626440)
addappid(3000380)
addappid(3000380, 1, "bb3ddd9cc724263241d5b868d6bb32ffba6ecf59a4f9527aee50d5c2779bbd5f")
setManifestid(3000380, "7480053320571850900", 47048697)