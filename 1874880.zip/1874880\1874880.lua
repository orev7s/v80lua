addappid(1874880)
addappid(228989)
addappid(1874881,0,"f1bc308d3a58a8d144a76dc02d552819b433bda49c325060fcab53e8100cead3")
setManifestid(1874881,"828061930134249962")
addappid(1874882,0,"c964efe3e6ee7295beeb474f46e6c78d1f2f62097dc3c793b1474cfab9f2f055")
setManifestid(1874882,"1650233779375073015")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]