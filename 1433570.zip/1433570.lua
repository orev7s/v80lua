-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(1433570) -- Car Detailing Simulator

-- MAIN APP DEPOTS
addappid(1433572, 1, "6fdbb0037c4aa12c03a2684a46ed80f7edb869e441ae37d43d3e5ec00d6a4b5e") -- Game Content (Linux Binaries)
setManifestid(1433572, "6932075348263177066", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Car Detailing Simulator - AMMO NYC DLC (AppID: 1802260)
addappid(1802260)
addappid(1802264, 1, "5a4caf851a74cbbe8fe3c15cb6d030a49f3cad0266048fe3f8d2c4b97677284a") -- Car Detailing Simulator - AMMO NYC DLC - Main Content
setManifestid(1802264, "3959727870878580688", 0)

-- Car Detailing Simulator - Track Day DLC (AppID: 2161870)
addappid(2161870)
addappid(2161872, 1, "dfa5152a177d80677faaa80ce6a5cb632d7e8a140145ccac9035a7fa93fa5945") -- Car Detailing Simulator - Track Day DLC - Main Content
setManifestid(2161872, "5076558517413881759", 0)
