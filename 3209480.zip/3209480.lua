-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(3209480) -- Last Report

-- MAIN APP DEPOTS
addappid(3209481, 1, "cd783437d27e2a39f961592e9b07cea05662d93e0799c248158afdbd8b1fb1d8") -- Depot 3209481
setManifestid(3209481, "8524687911932301224", 0)
