-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(222480) -- Resident Evil Revelations

-- MAIN APP DEPOTS
addappid(222481, 1, "65e75d906613ce658af73b8db0772cf9f6fa3905427161dd1c0482572da72c0d") -- Resident Evil: Revelations Content
setManifestid(222481, "2624313053854726936", 0)

-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- RE Rev.  BH REV. UE Upgrade Parts Resistance Set (AppID: 229621)
addappid(229621)
addtoken(229621, "233459904209267960")
addappid(229621, 1, "cd908e40d47ae228e942070e0e6e9dd87d874f16434488b0b6d70091915ec999") -- RE Rev.  BH REV. UE Upgrade Parts Resistance Set - DLC_MER_WPSET_01
setManifestid(229621, "1729720183785589076", 0)

-- RE Rev.  BH REV. UE Upgrade Parts Enhancement Set (AppID: 229622)
addappid(229622)
addtoken(229622, "16981799673173157394")
addappid(229622, 1, "ae8ea828b9a2c97510d5968ce55a9dae3a04346865801ac4757d7cd7ff106d9d") -- RE Rev.  BH REV. UE Upgrade Parts Enhancement Set - DLC_MER_WPSET_02
setManifestid(229622, "5762540738354433494", 0)

-- RE Rev.  BH REV. UE RAID Outfit LADY HUNK (AppID: 229626)
addappid(229626)
addappid(229626, 1, "1badd29cc032ee6227834ed10f78d0f4e785be725ae708391b1d6083e9d0fd67") -- RE Rev.  BH REV. UE RAID Outfit LADY HUNK - DLC_ULK_PL_RH
setManifestid(229626, "1462684019205755272", 0)

-- RE Rev.  BH REV. UE RAID Outfit Rachael Ooze (AppID: 229627)
addappid(229627)
addappid(229627, 1, "05fe47e8229993a4957c546b6b11f34f46e75c4344ec653a896e52fcfb8d4343") -- RE Rev.  BH REV. UE RAID Outfit Rachael Ooze - DLC_ULK_PL_RO
setManifestid(229627, "6146425481277420255", 0)

-- RE Rev.  BH REV. UE Weapon Parkers Government  Custom Part FBC (AppID: 229628)
addappid(229628)
addtoken(229628, "15453805459233408151")
addappid(229628, 1, "deda58ec7e09d693118e91f904d7e25e08198a746dfe30f5a988ade2caf96dbb") -- RE Rev.  BH REV. UE Weapon Parkers Government  Custom Part FBC - DLC_ULK_WP_GBM
setManifestid(229628, "1091544035272724112", 0)

-- RE Rev.  BH REV. UE Weapon Jessicas G18  Custom Part BSAA (AppID: 229629)
addappid(229629)
addappid(229629, 1, "c9a80ed80166abc5061fe93f2ca57b2a013075300639e2a7963909215b3cdc57") -- RE Rev.  BH REV. UE Weapon Jessicas G18  Custom Part BSAA - DLC_ULK_WP_PC356
setManifestid(229629, "7610772433233583544", 0)

-- RE Rev.  BH REV. UE Weapon Jills Samurai Edge  Custom Part S.T.A.R.S. (AppID: 229630)
addappid(229630)
addappid(229630, 1, "c338077d7ee7ef5a03646b62ae08290d05705e25da98b945e75cc86b5c3da7a3") -- RE Rev.  BH REV. UE Weapon Jills Samurai Edge  Custom Part S.T.A.R.S. - DLC_ULK_WP_SMR
setManifestid(229630, "8821996626474824228", 0)
