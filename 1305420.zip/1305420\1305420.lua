addappid(1305420)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"5087715316087945828")
addappid(1305421,0,"e2a190fff002b76e61bc7ac0cc6e55561e04f6719710aa5a91df91458dd83c70")
setManifestid(1305421,"3543692515117652983")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]