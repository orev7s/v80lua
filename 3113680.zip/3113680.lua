-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(3113680) -- Missing Banban

-- MAIN APP DEPOTS
addappid(3113681, 1, "174d479a2c0657ad7755534a7a005230bebfbedd36f2ee0607d3354b5ea0b9b2") -- Main Game Content (Windows Content)
setManifestid(3113681, "6221000715959591162", 0)
