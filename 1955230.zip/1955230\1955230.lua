addappid(1955230)
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228989)
setManifestid(228989,"1332597174812030948")
addappid(1955231,0,"a78b34a2e413da7191f349d1954b63df72dd07f76b35ef57b7a01665b8e64358")
setManifestid(1955231,"3326283962832174915")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]