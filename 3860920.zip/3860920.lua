-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3860920)
addappid(3860921,0,"831c12a8afb073a4b11d5fe223b0780e90589cb045dcf38c363b494e7eadf604")
setManifestid(3860921,"2298963565622412963")