-- Made by f1uxin, please read the read me TXT file.
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship
addappid(2967990) -- Train Sim World® 5

-- MAIN APP DEPOTS
addappid(2967991, 1, "4e4c795aecb9eb3eaee78f7e24da9313ed931cc7eb5b7b1c7866d3ef1cbe5726") -- Depot 2967991
setManifestid(2967991, "3919040482107965380", 0)
addappid(2970770, 1, "335a0cedcfa948034598d0c75aeae8f9e95cbeb642b132491b60c8f3d16b9129") -- Depot 2970770
setManifestid(2970770, "2648673516199063916", 0)
addappid(2970780, 1, "9acdaa2ecb3384af36aa38089dbca60b09ca7175a915042568c1795bd0fd2d3a") -- Depot 2970780
setManifestid(2970780, "3926362508052861626", 0)

-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 0)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "550968249685141759", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Train Sim World 5 Great Western Express Route Add-On (AppID: 2969390)
addappid(2969390)
addappid(2969390, 1, "95445a3a2a1cd04ad9899d3479e00edd71ee3eaee3e2a3ac2cfabd303b86931a") -- Train Sim World 5 Great Western Express Route Add-On - Depot 2969390
setManifestid(2969390, "5836714899614253717", 0)

-- Train Sim World 5 Rapid Transit (AppID: 2969400)
addappid(2969400)
addappid(2969400, 1, "a12d89b95c39e62040c372ad987d5b927c74b4a118230e79291b4f5c63e1d7c4") -- Train Sim World 5 Rapid Transit - Depot 2969400
setManifestid(2969400, "2708109349056259183", 0)

-- Train Sim World 5 West Somerset Railway Route Add-On (AppID: 2969410)
addappid(2969410)
addappid(2969410, 1, "60302bb6e8caddcf30474a74e0c1008710f8c7ca348617623f8e7bb2f7e87e3d") -- Train Sim World 5 West Somerset Railway Route Add-On - Depot 2969410
setManifestid(2969410, "3926980710726897856", 0)

-- Train Sim World 5 Ruhr-Sieg Nord Hagen - Finnentrop Route Add-On (AppID: 2969420)
addappid(2969420)
addappid(2969420, 1, "aabf8f830c2eecba4c76301dac727d49538d319f3892740af1169427951591d7") -- Train Sim World 5 Ruhr-Sieg Nord Hagen - Finnentrop Route Add-On - Depot 2969420
setManifestid(2969420, "8336482108749644943", 0)

-- Train Sim World 5 Long Island Rail Road New York - Hicksville Route Add-On (AppID: 2969430)
addappid(2969430)
addappid(2969430, 1, "c1d6ceee02fb32b2531cc8b247452f4f7e822f840e6723f6dd2a2e0b6af06528") -- Train Sim World 5 Long Island Rail Road New York - Hicksville Route Add-On - Depot 2969430
setManifestid(2969430, "5600198132651951027", 0)

-- Train Sim World 5 Northern Trans-Pennine Manchester - Leeds Route Add-On (AppID: 2969440)
addappid(2969440)
addappid(2969440, 1, "dd3a54f27f9a67a8cc44556261157bf97dcacd3fa63d72f48222cf18b209071e") -- Train Sim World 5 Northern Trans-Pennine Manchester - Leeds Route Add-On - Depot 2969440
setManifestid(2969440, "8723868044108808044", 0)

-- Train Sim World 5 BR Class 33 Add-On (AppID: 2969450)
addappid(2969450)
addappid(2969450, 1, "29ff518e9b3822626e5a9f0f3278ef40ee9a97f10fb8700673c12d00a02bcf75") -- Train Sim World 5 BR Class 33 Add-On - Depot 2969450
setManifestid(2969450, "8969292633616695428", 0)

-- Train Sim World 5 Main-Spessart Bahn Aschaffenburg - Gemunden Route Add-On (AppID: 2969460)
addappid(2969460)
addappid(2969460, 1, "91c258af17455b30d456947d0b40feee9db2f3e6e43e9619e3c1f3f3e2a55053") -- Train Sim World 5 Main-Spessart Bahn Aschaffenburg - Gemunden Route Add-On - Depot 2969460
setManifestid(2969460, "1109165691367334954", 0)

-- Train Sim World 5 DB BR 182 Loco Add-On (AppID: 2969470)
addappid(2969470)
addappid(2969470, 1, "27e3837fb260c301e45b0e6fed0c3622cebd73592d5c79cbdda12f61d8c66ec6") -- Train Sim World 5 DB BR 182 Loco Add-On - Depot 2969470
setManifestid(2969470, "3506257372877165411", 0)

-- Train Sim World 5 DB BR 155 Loco Add-On (AppID: 2969480)
addappid(2969480)
addappid(2969480, 1, "8cbd6cb9a5d49636b9e8f4a5db76cbed98037820141040f23c9237193bd9fc5a") -- Train Sim World 5 DB BR 155 Loco Add-On - Depot 2969480
setManifestid(2969480, "3287780389806632313", 0)

-- Train Sim World 5 BR Class 52 Add-On (AppID: 2969490)
addappid(2969490)
addappid(2969490, 1, "cfac881dd1fc9ffd257baba8eb2546aa5591f1062afea01a200791f231a179bd") -- Train Sim World 5 BR Class 52 Add-On - Depot 2969490
setManifestid(2969490, "6278283628023667809", 0)

-- Train Sim World 5 BR Heavy Freight Pack Loco Add-On (AppID: 2969500)
addappid(2969500)
addappid(2969500, 1, "cec6d7742445818ee1c961036ecdcb1cb85be1a583a78e42c0c0ebe3cbaf47b0") -- Train Sim World 5 BR Heavy Freight Pack Loco Add-On - Depot 2969500
setManifestid(2969500, "4205689597141580836", 0)

-- Train Sim World 5 Tees Valley Line Darlington  Saltburn-by-the-Sea Route Add-On (AppID: 2969510)
addappid(2969510)
addappid(2969510, 1, "20cec8f7a64329a29e87a8980133fa95db095bd9b877e8446c25e5e6dab95c61") -- Train Sim World 5 Tees Valley Line Darlington  Saltburn-by-the-Sea Route Add-On - Depot 2969510
setManifestid(2969510, "8563952732938231936", 0)

-- Train Sim World 5 Peninsula Corridor San Francisco - San Jose Route Add-On (AppID: 2969520)
addappid(2969520)
addappid(2969520, 1, "7459525afd4cf303a1e41d94066f51e43641282371e4206bc350b73dea79704f") -- Train Sim World 5 Peninsula Corridor San Francisco - San Jose Route Add-On - Depot 2969520
setManifestid(2969520, "6720027525444398447", 0)

-- Train Sim World 5 Rhein-Ruhr Osten Wuppertal - Hagen Route Add-On (AppID: 2969530)
addappid(2969530)
addappid(2969530, 1, "903758d25ee39831ab1c79708873c1624c5157322cbc8ec9625f3a1ce4bdccfd") -- Train Sim World 5 Rhein-Ruhr Osten Wuppertal - Hagen Route Add-On - Depot 2969530
setManifestid(2969530, "1412675992801257474", 0)

-- Train Sim World 5 BR Class 31 Loco Add-On (AppID: 2969540)
addappid(2969540)
addappid(2969540, 1, "123d8fa2815e4698cea40d8843e2634a6b5cd06a8b4665d20a98d903fcb56e7f") -- Train Sim World 5 BR Class 31 Loco Add-On - Depot 2969540
setManifestid(2969540, "836484709812773604", 0)

-- Train Sim World 5 East Coastway Brighton - Eastbourne  Seaford Route Add-On (AppID: 2969550)
addappid(2969550)
addtoken(2969550, "16627310466930926792")
addappid(2969550, 1, "2e29554e5714f05349728e128c627b4c5947ac20fb01cf18c67ffa78b310a59a") -- Train Sim World 5 East Coastway Brighton - Eastbourne  Seaford Route Add-On - Depot 2969550
setManifestid(2969550, "7258624077946344658", 0)

-- Train Sim World 5 Caltrain MP36PH-3C Baby Bullet Loco Add-On (AppID: 2969560)
addappid(2969560)
addappid(2969560, 1, "fee08f97a43c8043fde5c05f204fee07ee7946fb1a196523b76db7983abd25a3") -- Train Sim World 5 Caltrain MP36PH-3C Baby Bullet Loco Add-On - Depot 2969560
setManifestid(2969560, "7151969500951014971", 0)

-- Train Sim World 5 Canadian National Oakville Subdivision Hamilton - Oakville Route Add-On (AppID: 2969570)
addappid(2969570)
addappid(2969570, 1, "a15d0ed5a2809a292735eaf4a439233872539f727e65755a1c9bdb9dfaa16e68") -- Train Sim World 5 Canadian National Oakville Subdivision Hamilton - Oakville Route Add-On - Depot 2969570
setManifestid(2969570, "919431237766112468", 0)

-- Train Sim World 5 Caltrain MP15DC Diesel Switcher Loco Add-On (AppID: 2969580)
addappid(2969580)
addappid(2969580, 1, "ce8a1b0b9fa5b70c2ede8284fdc9377bbba807748ec47887d8d98bc922320813") -- Train Sim World 5 Caltrain MP15DC Diesel Switcher Loco Add-On - Depot 2969580
setManifestid(2969580, "6630116803059286205", 0)

-- Train Sim World 5 Hauptstrecke Rhein-Ruhr Duisburg - Bochum Route Add-On (AppID: 2969600)
addappid(2969600)
addappid(2969600, 1, "2c126dc8dfce0feb8d4dd501ede1216238e6229507831388c1cce56410114e49") -- Train Sim World 5 Hauptstrecke Rhein-Ruhr Duisburg - Bochum Route Add-On - Depot 2969600
setManifestid(2969600, "6942992364189700249", 0)

-- Train Sim World 5 DB BR 204 Add-On (AppID: 2969610)
addappid(2969610)
addappid(2969610, 1, "7943f0462d7fe9aab0075a32a144a5ea44491e7e871b33a37e3397f050771f9a") -- Train Sim World 5 DB BR 204 Add-On - Depot 2969610
setManifestid(2969610, "5153085833209820388", 0)

-- Train Sim World 5 LIRR M3 EMU Add-On (AppID: 2969620)
addappid(2969620)
addappid(2969620, 1, "5f21edc022aa2019ac8a93c1f4ed1a728ea0941253f9feed5e3a374677141fe4") -- Train Sim World 5 LIRR M3 EMU Add-On - Depot 2969620
setManifestid(2969620, "1773590193714420632", 0)

-- Train Sim World 5 BR Class 20 Chopper Loco Add-On (AppID: 2969630)
addappid(2969630)
addappid(2969630, 1, "3d3a8801f911eedbd6e4d0462d7c42f65c88aec79d96eaef6a572df348b6af11") -- Train Sim World 5 BR Class 20 Chopper Loco Add-On - Depot 2969630
setManifestid(2969630, "438627698981732013", 0)

-- Train Sim World 5 Isle Of Wight Ryde - Shanklin Route Add-On (AppID: 2969640)
addappid(2969640)
addappid(2969640, 1, "4917a6b6786aa82e266ea198a37554bf182c9ba20f23f540ec5169a27510b5c3") -- Train Sim World 5 Isle Of Wight Ryde - Shanklin Route Add-On - Depot 2969640
setManifestid(2969640, "9157278481928992257", 0)

-- Train Sim World 5 Hauptstrecke Munchen - Augsburg Route Add-On (AppID: 2969650)
addappid(2969650)
addappid(2969650, 1, "99dbc5b1faa85473c7e680dc4cf70dac59acf1645f6398a1f21bdba0bac78e8a") -- Train Sim World 5 Hauptstrecke Munchen - Augsburg Route Add-On - Depot 2969650
setManifestid(2969650, "6946145885943798031", 0)

-- Train Sim World 5 DB BR 363 Loco Add-On (AppID: 2969660)
addappid(2969660)
addappid(2969660, 1, "e14e56ab5722bf2b9c70fad590b0e5f80482bfb169fed4159dea213d37cfa475") -- Train Sim World 5 DB BR 363 Loco Add-On - Depot 2969660
setManifestid(2969660, "2158266607940669329", 0)

-- Train Sim World 5 Southern BR Class 313 EMU Add-On (AppID: 2969670)
addappid(2969670)
addappid(2969670, 1, "74219069069b932599bb04d92be94af97385172cba64e05da8f016383c1f1d2a") -- Train Sim World 5 Southern BR Class 313 EMU Add-On - Depot 2969670
setManifestid(2969670, "4877241596588373317", 0)

-- Train Sim World 5 CSX C40-8W Loco Add-On (AppID: 2969680)
addappid(2969680)
addappid(2969680, 1, "81e649996a8d5c893a4d62eee1a18dd1dfb64097da17fb997de88785a66f1271") -- Train Sim World 5 CSX C40-8W Loco Add-On - Depot 2969680
setManifestid(2969680, "7092336766841530269", 0)

-- Train Sim World 5 LGV Mediterranee Marseille - Avignon Route Add-On (AppID: 2969690)
addappid(2969690)
addappid(2969690, 1, "1118e87e270e95670b06db86537c5f5af2092618b99e65d8b4b2c23cfa4fd105") -- Train Sim World 5 LGV Mediterranee Marseille - Avignon Route Add-On - Depot 2969690
setManifestid(2969690, "5447909382264753187", 0)

-- Train Sim World 5 Arosalinie Chur - Arosa Route Add-On (AppID: 2969720)
addappid(2969720)
addappid(2969720, 1, "e152be49431b591a1892ca21bcd817e48f445e7986be0da61906e640c9ff3b33") -- Train Sim World 5 Arosalinie Chur - Arosa Route Add-On - Depot 2969720
setManifestid(2969720, "4731531568602394764", 0)

-- Train Sim World 5 Cane Creek Thompson - Potash Route Add-On (AppID: 2969730)
addappid(2969730)
addappid(2969730, 1, "c1b4039430263ec9f75b7b85ae2f5522f27e586f97cbc45ac1a4c84499621f70") -- Train Sim World 5 Cane Creek Thompson - Potash Route Add-On - Depot 2969730
setManifestid(2969730, "4829195592694787996", 0)

-- Train Sim World 5 DB BR 187 Loco Add-On (AppID: 2969740)
addappid(2969740)
addappid(2969740, 1, "4b91ee72c68e1a10fd71e5a53e797132ea5cd1842170b4a5b995bbd8f3ab8354") -- Train Sim World 5 DB BR 187 Loco Add-On - Depot 2969740
setManifestid(2969740, "4543655988090048894", 0)

-- Train Sim World 5 Diesel Legends of the Great Western Add-On (AppID: 2969760)
addappid(2969760)
addappid(2969760, 1, "e781ab2fa25f7128b1334f9e4a1596df4bba8c64e2857cd5c3612524aaafc499") -- Train Sim World 5 Diesel Legends of the Great Western Add-On - Depot 2969760
setManifestid(2969760, "6166511477205395963", 0)

-- Train Sim World 5 Clinchfield Railroad Elkhorn - Dante Route Add-On (AppID: 2969780)
addappid(2969780)
addappid(2969780, 1, "c5cef82ebff1b7202609a0eb86d79eb8e3445beb50db8e1f828eb334307531a1") -- Train Sim World 5 Clinchfield Railroad Elkhorn - Dante Route Add-On - Depot 2969780
setManifestid(2969780, "6362323226475243260", 0)

-- Train Sim World 5 DB BR 101 Loco Add-On (AppID: 2969800)
addappid(2969800)
addappid(2969800, 1, "12c9a337ec1095c24a90925b81f26f52234038eea9807f4bfc495cf706928987") -- Train Sim World 5 DB BR 101 Loco Add-On - Depot 2969800
setManifestid(2969800, "2196071705481920787", 0)

-- Train Sim World 5 Hauptstrecke Hamburg - Lbeck Route Add-On (AppID: 2969820)
addappid(2969820)
addappid(2969820, 1, "f6abca8a8eff1ac5a975c7ceb744ec03897adf8abcf72b7bc78a32a890025bca") -- Train Sim World 5 Hauptstrecke Hamburg - Lbeck Route Add-On - Depot 2969820
setManifestid(2969820, "5032401383462013826", 0)

-- Train Sim World 5 Cathcart Circle Line Glasgow - Neilston  Newton Add-On (AppID: 2969840)
addappid(2969840)
addappid(2969840, 1, "3a300b3f3a7bb373539ce95630076a836f21a10cda82cd6fa19279622c59a79c") -- Train Sim World 5 Cathcart Circle Line Glasgow - Neilston  Newton Add-On - Depot 2969840
setManifestid(2969840, "6081387953683143387", 0)

-- Train Sim World 5 London Underground 1938 Stock EMU Loco Add-On (AppID: 2969870)
addappid(2969870)
addappid(2969870, 1, "eb991b85f55ddd5781810601e917bda58897a7ca0f387bbab0eee4c50ec507f1") -- Train Sim World 5 London Underground 1938 Stock EMU Loco Add-On - Depot 2969870
setManifestid(2969870, "7615800161065960293", 0)

-- Train Sim World 5 Nahverkehr Dresden - Riesa Route Add-On (AppID: 2969890)
addappid(2969890)
addappid(2969890, 1, "609c83faba002fe75149224de8ceeb5da8a61be8c8b98ae1f89e94fbb9e73bb4") -- Train Sim World 5 Nahverkehr Dresden - Riesa Route Add-On - Depot 2969890
setManifestid(2969890, "8234161697981974354", 0)

-- Train Sim World 5 Brighton Main Line London Victoria - Brighton Route Add-On (AppID: 2969930)
addappid(2969930)
addappid(2969930, 1, "c74dcb945e8434f81deccc615420db992674e0424036323224372042abbc657e") -- Train Sim World 5 Brighton Main Line London Victoria - Brighton Route Add-On - Depot 2969930
setManifestid(2969930, "400910886588464243", 0)

-- Train Sim World 5 Northeast Corridor Boston - Providence Route Add-On (AppID: 2969940)
addappid(2969940)
addappid(2969940, 1, "258fd06287ae438c6ed7c6639d010bca1b189ac5ca3ec467d9e47443b1b19a27") -- Train Sim World 5 Northeast Corridor Boston - Providence Route Add-On - Depot 2969940
setManifestid(2969940, "3364369865852213753", 0)

-- Train Sim World 5 Horseshoe Curve Altoona - Johnstown  South Fork Route Add-On (AppID: 2969950)
addappid(2969950)
addappid(2969950, 1, "3f6d3301be0ce77c722d6975723ff02e19cc77b47e3096193184beb0ec2938cf") -- Train Sim World 5 Horseshoe Curve Altoona - Johnstown  South Fork Route Add-On - Depot 2969950
setManifestid(2969950, "2962961262088419476", 0)

-- Train Sim World 5 West Cornwall Local Penzance - St Austell  St Ives Route Add-On (AppID: 2969980)
addappid(2969980)
addappid(2969980, 1, "7043a43dead77ff91163d590c7ffcea1f810f5e4b8fae9cbbe901e8a1fc2f2e4") -- Train Sim World 5 West Cornwall Local Penzance - St Austell  St Ives Route Add-On - Depot 2969980
setManifestid(2969980, "1986905744548930973", 0)

-- Train Sim World 5 Sherman Hill Cheyenne - Laramie Route Add-On (AppID: 2969990)
addappid(2969990)
addappid(2969990, 1, "c3adba1e75b52c8bdc3b44c14db88c5ffd04fe3874c28e8d73bcad1c81c5c377") -- Train Sim World 5 Sherman Hill Cheyenne - Laramie Route Add-On - Depot 2969990
setManifestid(2969990, "215736813413432173", 0)

-- Train Sim World 5 DB G6 Diesel Shunter Add-On (AppID: 2970000)
addappid(2970000)
addappid(2970000, 1, "b1f1f63c4503fc73a968bae7a0a0a9e82dc530ffc4aeea189149deb117e73ecc") -- Train Sim World 5 DB G6 Diesel Shunter Add-On - Depot 2970000
setManifestid(2970000, "3544290328289564882", 0)

-- Train Sim World 5 RhB Anniversary Collection Add-On (AppID: 2970010)
addappid(2970010)
addappid(2970010, 1, "c492fe452730b3e581da123e4ab000881f7971dd614db72b24fa6c38c6257e89") -- Train Sim World 5 RhB Anniversary Collection Add-On - Depot 2970010
setManifestid(2970010, "7299702694021072675", 0)

-- Train Sim World 5 Tharandter Rampe Dresden - Chemnitz Route Add-On (AppID: 2970020)
addappid(2970020)
addappid(2970020, 1, "f75f8e4ee4239d32fd5e980f5c2be31783051352272d5d33bb530e22868f6e20") -- Train Sim World 5 Tharandter Rampe Dresden - Chemnitz Route Add-On - Depot 2970020
setManifestid(2970020, "3018512190389999452", 0)

-- Train Sim World 5 S-Bahn Zentralschweiz Luzern - Sursee Route Add-On (AppID: 2970030)
addappid(2970030)
addappid(2970030, 1, "f8cae113ad0c1c05ae33409627787d2e966af1682f1ec6ae0f44755be46cd0aa") -- Train Sim World 5 S-Bahn Zentralschweiz Luzern - Sursee Route Add-On - Depot 2970030
setManifestid(2970030, "8975835821857077013", 0)

-- Train Sim World 5 Harlem Line Grand Central Terminal - North White Plains Route Add-On (AppID: 2970040)
addappid(2970040)
addappid(2970040, 1, "972afbcc698313155f738969b11ff68a24a04a0f1e597d5b5cb0b725cde85cba") -- Train Sim World 5 Harlem Line Grand Central Terminal - North White Plains Route Add-On - Depot 2970040
setManifestid(2970040, "147713198431723061", 0)

-- Train Sim World 5 Schnellfahrstrecke Kassel - Wrzburg Route Add-On (AppID: 2970050)
addappid(2970050)
addappid(2970050, 1, "7dcd39d093569c32fc31b3f1f5f955cd9806572459fd5bf8b5c4839958c497c1") -- Train Sim World 5 Schnellfahrstrecke Kassel - Wrzburg Route Add-On - Depot 2970050
setManifestid(2970050, "3697043151569879838", 0)

-- Train Sim World 5 Cajon Pass Barstow - San Bernardino Route Add-On (AppID: 2970060)
addappid(2970060)
addappid(2970060, 1, "c92694e79497ea2f3ad211b739181b5c76b012269bb1046b03b4dde4ef392487") -- Train Sim World 5 Cajon Pass Barstow - San Bernardino Route Add-On - Depot 2970060
setManifestid(2970060, "1595744646254252048", 0)

-- Train Sim World 5 Southeastern Highspeed London St Pancras  Ashford Intl  Faversham Route Add-On (AppID: 2970070)
addappid(2970070)
addappid(2970070, 1, "3d0288e2848c14de60d38c3c40cad36f9012fcd54b314420ee3ca6fe3b130fcb") -- Train Sim World 5 Southeastern Highspeed London St Pancras  Ashford Intl  Faversham Route Add-On - Depot 2970070
setManifestid(2970070, "5787894780901072398", 0)

-- Train Sim World 5 Spirit of Steam Liverpool Lime Street - Crewe Route Add-On (AppID: 2970090)
addappid(2970090)
addappid(2970090, 1, "5d904580ad541f20d71afb17086bf11fb3b69d796b4a005474b406bb763357f8") -- Train Sim World 5 Spirit of Steam Liverpool Lime Street - Crewe Route Add-On - Depot 2970090
setManifestid(2970090, "3281853759398989209", 0)

-- Train Sim World 5 Niddertalbahn Bad Vilbel - Stockheim Route Add-On (AppID: 2970100)
addappid(2970100)
addappid(2970100, 1, "95237691301a2d4ed766dff15648fae214f49333bdfef4943532147902a72507") -- Train Sim World 5 Niddertalbahn Bad Vilbel - Stockheim Route Add-On - Depot 2970100
setManifestid(2970100, "7813863263785677942", 0)

-- Train Sim World 5 Schnellfahrstrecke Koln-Aachen Route Add-On (AppID: 2970110)
addappid(2970110)
addappid(2970110, 1, "77361b13f96ef195d2a40ee481aff3d9221b580627f7d694fbab4426319e82d7") -- Train Sim World 5 Schnellfahrstrecke Koln-Aachen Route Add-On - Depot 2970110
setManifestid(2970110, "2484462064264865308", 0)

-- Train Sim World 5 Bakerloo Line Route Add-On (AppID: 2970120)
addappid(2970120)
addappid(2970120, 1, "694cd03f06d1423dcc5c69064a4ef468960c3df2d4df99a42e7e37c1b043988a") -- Train Sim World 5 Bakerloo Line Route Add-On - Depot 2970120
setManifestid(2970120, "4581492851215545601", 0)

-- Train Sim World 5 Sand Patch Grade Route Add-On (AppID: 2970130)
addappid(2970130)
addappid(2970130, 1, "d573a783d122b17a034bc01a48a698ac417ed51112f83797a05eb69adff26f03") -- Train Sim World 5 Sand Patch Grade Route Add-On - Depot 2970130
setManifestid(2970130, "5928376171061048468", 0)

-- Train Sim World 5 Union Pacific Heritage Livery Collection (AppID: 2970140)
addappid(2970140)
addappid(2970140, 1, "ed09c789f0cd45ad5f5870c4e35fada779cca9b0662d5e9ff115b3b6dd1522cc") -- Train Sim World 5 Union Pacific Heritage Livery Collection - Depot 2970140
setManifestid(2970140, "1065348399250934853", 0)

-- Train Sim World 5 Island Line 2022 BR Class 484 EMU Add-On (AppID: 2970150)
addappid(2970150)
addappid(2970150, 1, "8ee059cd1f11e13649a849fd788c87e59f554b5e038c0419261ff39bf24e3a92") -- Train Sim World 5 Island Line 2022 BR Class 484 EMU Add-On - Depot 2970150
setManifestid(2970150, "716678978053516253", 0)

-- Train Sim World 5 Rail Head Treatment Train Add-On (AppID: 2970170)
addappid(2970170)
addappid(2970170, 1, "d5d7a18854f81b7f1615d2216497fd36e535d2f0880251d39a3eb08a82194e55") -- Train Sim World 5 Rail Head Treatment Train Add-On - Depot 2970170
setManifestid(2970170, "2875603475048109846", 0)

-- Train Sim World 5 Santa Fe F7 Add-On (AppID: 2970180)
addappid(2970180)
addappid(2970180, 1, "bc8e14309015faa6c990567f700a6349c58d392845b4d605800ba87fa0630c2f") -- Train Sim World 5 Santa Fe F7 Add-On - Depot 2970180
setManifestid(2970180, "3607734152154098115", 0)

-- Train Sim World 5 Dispolok BR 182 Add-On (AppID: 2970190)
addappid(2970190)
addappid(2970190, 1, "ab6be5a2a7f52dfe34e9f24f783dfe9532e79d82b891db0950f438508af45cd6") -- Train Sim World 5 Dispolok BR 182 Add-On - Depot 2970190
setManifestid(2970190, "8332784243587412097", 0)

-- Train Sim World 5 Birmingham Cross-City Line Lichfield - Bromsgrove  Redditch Route Add-On (AppID: 2970200)
addappid(2970200)
addappid(2970200, 1, "695a48effbffb391303e9efe441a6f376dbb912bcba592b03a264767d5c045d0") -- Train Sim World 5 Birmingham Cross-City Line Lichfield - Bromsgrove  Redditch Route Add-On - Depot 2970200
setManifestid(2970200, "812506209510352545", 0)

-- Train Sim World 5 Bahnstrecke Bremen - Oldenburg Route Add-On (AppID: 2970210)
addappid(2970210)
addappid(2970210, 1, "fb2dd62f868828e41e17ce9f85f6c7f0f9653770b8c5a4d375425f47ec5ec458") -- Train Sim World 5 Bahnstrecke Bremen - Oldenburg Route Add-On - Depot 2970210
setManifestid(2970210, "8805478959279846298", 0)

-- Train Sim World 5 New Journeys - Silver 1972 Stock Add-On (AppID: 2970220)
addappid(2970220)
addappid(2970220, 1, "9a5171c77bb4b2014a368dcd1c4d17ca1b21ca38d7d450864b7fbed226cb4933") -- Train Sim World 5 New Journeys - Silver 1972 Stock Add-On - Depot 2970220
setManifestid(2970220, "314883064329862602", 0)

-- Train Sim World 5 New Journeys - CSX SD40 Add-On (AppID: 2970230)
addappid(2970230)
addappid(2970230, 1, "ff40f7efcad7b650b36e8e1e4c76e00ad91098546776617fd7638e50bf14c641") -- Train Sim World 5 New Journeys - CSX SD40 Add-On - Depot 2970230
setManifestid(2970230, "2532457344569083456", 0)

-- Train Sim World 5 New Journeys - S-Bahn Kln BR 423 Add-On (AppID: 2970240)
addappid(2970240)
addappid(2970240, 1, "a5dc09d84d76417e19f465ba9b06a2ecbbac4d6e1bac76fc50cbe6c87d313353") -- Train Sim World 5 New Journeys - S-Bahn Kln BR 423 Add-On - Depot 2970240
setManifestid(2970240, "5355106840587580729", 0)

-- Train Sim World 5 The Holiday Express - Runaway Elf (AppID: 2970250)
addappid(2970250)
addappid(2970250, 1, "dee86ecb17f9c1ad0cb96fd1116ec068da9a379998a1df99e4de6b69ba485da6") -- Train Sim World 5 The Holiday Express - Runaway Elf - Depot 2970250
setManifestid(2970250, "101350161837844288", 0)

-- Train Sim World 5 ScotRail Express Edinburgh - Glasgow Route Add-On (AppID: 2970260)
addappid(2970260)
addappid(2970260, 1, "7969fc1998c86ff80b4b7b847b1985e2f153a272d367578bf2193530cda2976f") -- Train Sim World 5 ScotRail Express Edinburgh - Glasgow Route Add-On - Depot 2970260
setManifestid(2970260, "2130350294197551975", 0)

-- Train Sim World 5 West Cornwall Steam Railtour Add-On (AppID: 2970270)
addappid(2970270)
addappid(2970270, 1, "a84f15463c27a4c1147807a47fa9aac03e0d8cbe7eb12e37572339e6aaefd726") -- Train Sim World 5 West Cornwall Steam Railtour Add-On - Depot 2970270
setManifestid(2970270, "5744426146420821872", 0)

-- Train Sim World 5 Amtraks Acela (AppID: 2970280)
addappid(2970280)
addappid(2970280, 1, "e213c57ac5d16787100035fb6b56647c54ebfc7a99416ec874a3c4ec150695d7") -- Train Sim World 5 Amtraks Acela - Depot 2970280
setManifestid(2970280, "4666900799196802314", 0)

-- Train Sim World 5 Thameslink BR Class 7000 EMU Add-On (AppID: 2970290)
addappid(2970290)
addappid(2970290, 1, "e1d77a032bc5638169fd8980a5ec6229d78dd49441c5297a6683cf1bc1726c69") -- Train Sim World 5 Thameslink BR Class 7000 EMU Add-On - Depot 2970290
setManifestid(2970290, "7276292532781869883", 0)

-- Train Sim World 5 Northeast Corridor New York - Trenton (AppID: 2970300)
addappid(2970300)
addappid(2970300, 1, "063f5f0003d3fc22c5779d42f19a8906d70148f5070c02bb7755d8b4f09bce06") -- Train Sim World 5 Northeast Corridor New York - Trenton - Depot 2970300
setManifestid(2970300, "4950799341989279625", 0)

-- Train Sim World 5 Peak Forest Railway Ambergate - Chinley  Buxton Route Add-On (AppID: 2970310)
addappid(2970310)
addappid(2970310, 1, "30e13cebf677aae992519a30e1203e1c8249d53f840be6b24f80446ae5628534") -- Train Sim World 5 Peak Forest Railway Ambergate - Chinley  Buxton Route Add-On - Depot 2970310
setManifestid(2970310, "960013977613528701", 0)

-- Train Sim World 5 Blackpool Branches Preston - Blackpool  Ormskirk Route Add-On (AppID: 2970320)
addappid(2970320)
addappid(2970320, 1, "2f8c8757dd2dc9501a8eeddb92cb7197d6681a99f36558b2b950c27dcbc7a1d8") -- Train Sim World 5 Blackpool Branches Preston - Blackpool  Ormskirk Route Add-On - Depot 2970320
setManifestid(2970320, "6105945707028477916", 0)

-- Train Sim World 5 Linke Rheinstrecke Mainz - Koblenz Route Add-On (AppID: 2970330)
addappid(2970330)
addappid(2970330, 1, "b3278bcfad24136357ede9c5519dba3d416b076db626230e941b74b5f6e58858") -- Train Sim World 5 Linke Rheinstrecke Mainz - Koblenz Route Add-On - Depot 2970330
setManifestid(2970330, "4062879658161680775", 0)

-- Train Sim World 5 Midland Main Line Leicester - Derby  Nottingham Route Add-On (AppID: 2970350)
addappid(2970350)
addappid(2970350, 1, "8758d70643bf99b4bca30151151d15fbfa0353a3d63200cee38928e8dfc67438") -- Train Sim World 5 Midland Main Line Leicester - Derby  Nottingham Route Add-On - Depot 2970350
setManifestid(2970350, "7562879392659399569", 0)

-- Train Sim World 5 BNSF SD70ACe Add-On (AppID: 2970360)
addappid(2970360)
addappid(2970360, 1, "1050f615fded86d01c0f9ff5ec13c038505e1319cb5caba926c0988cda340ef3") -- Train Sim World 5 BNSF SD70ACe Add-On - Depot 2970360
setManifestid(2970360, "4814916133265295614", 0)

-- Train Sim World 5 Rail Operations Group BR Class 377 Add-On (AppID: 2970370)
addappid(2970370)
addappid(2970370, 1, "a28fb405e1281b433c88b444ad86f32b370ef85d3f208fee6a1bd1e3cae5f607") -- Train Sim World 5 Rail Operations Group BR Class 377 Add-On - Depot 2970370
setManifestid(2970370, "5684483472299639379", 0)

-- Train Sim World 5 DB BR 403 ICE 3 Railbow Add-On (AppID: 2970380)
addappid(2970380)
addappid(2970380, 1, "e32db1e15a46b45f438cb1767cf351cdb4942de8fb48a0bfb2d3c4793519336b") -- Train Sim World 5 DB BR 403 ICE 3 Railbow Add-On - Depot 2970380
setManifestid(2970380, "8546669342227506427", 0)

-- Train Sim World 5 Railpool BR 193 Vectron Loco Add-On (AppID: 2970390)
addappid(2970390)
addappid(2970390, 1, "3984b0eb331720f55235c68df699a02daf94cae70aea8847d570dae1df6b166e") -- Train Sim World 5 Railpool BR 193 Vectron Loco Add-On - Depot 2970390
setManifestid(2970390, "4993064330580929239", 0)

-- Train Sim World 5 Glossop Line Manchester - Hadfield  Glossop Route Add-On (AppID: 2970400)
addappid(2970400)
addappid(2970400, 1, "dea56d5214cd7ce403bbcff2f34e18eaeb6d662480d72ed86aa33b61ebf427a9") -- Train Sim World 5 Glossop Line Manchester - Hadfield  Glossop Route Add-On - Depot 2970400
setManifestid(2970400, "4510678378842220864", 0)

-- Train Sim World 5 LNER Class A3 60103 Flying Scotsman Steam Loco Add-On (AppID: 2970410)
addappid(2970410)
addappid(2970410, 1, "48a35c99de1d4d587124b2fbc98cf38d3649862bba97d34256cab3afd5fb74ae") -- Train Sim World 5 LNER Class A3 60103 Flying Scotsman Steam Loco Add-On - Depot 2970410
setManifestid(2970410, "8352994852831705276", 0)

-- Train Sim World 5 Antelope Valley Line Los Angeles - Lancaster Route Add-On (AppID: 2970420)
addappid(2970420)
addappid(2970420, 1, "7098cd9597d431b0b2601a3edf015be9df55b1c16d7d554b96f1cd933e14ac0b") -- Train Sim World 5 Antelope Valley Line Los Angeles - Lancaster Route Add-On - Depot 2970420
setManifestid(2970420, "2731975826900827060", 0)

-- Train Sim World 5 East Coast Main Line Peterborough - Doncaster Route Add-On (AppID: 2970430)
addappid(2970430)
addappid(2970430, 1, "dbd37e53c12e1b62e145473304d5ca038a7b95c756fbe7c42703bc4322813f32") -- Train Sim World 5 East Coast Main Line Peterborough - Doncaster Route Add-On - Depot 2970430
setManifestid(2970430, "1003297890574914016", 0)

-- Train Sim World 5 S-Bahn Vorarlberg Lindau - Bludenz Route Add-On (AppID: 2970440)
addappid(2970440)
addappid(2970440, 1, "a868b1ce79db87ee5605b37d92df6097ea05b60f4fe3b0bf7630cd058f6fe5ad") -- Train Sim World 5 S-Bahn Vorarlberg Lindau - Bludenz Route Add-On - Depot 2970440
setManifestid(2970440, "5345126525386097371", 0)

-- Train Sim World 5 Norfolk Southern Heritage Livery Collection Add-On (AppID: 2970450)
addappid(2970450)
addappid(2970450, 1, "00effa62a220605cdaf3b240b8c0c61b9b30ca403c03bceda8824e92a0b03652") -- Train Sim World 5 Norfolk Southern Heritage Livery Collection Add-On - Depot 2970450
setManifestid(2970450, "5251319357710923893", 0)

-- Train Sim World 5 Maintalbahn Aschaffenburg - Miltenberg Route Add-On (AppID: 2970460)
addappid(2970460)
addappid(2970460, 1, "c4906a2267f58e9483258a70d6dfba68ebd9406ca6e8b05eb0e7b65c531318da") -- Train Sim World 5 Maintalbahn Aschaffenburg - Miltenberg Route Add-On - Depot 2970460
setManifestid(2970460, "2075598629618843553", 0)

-- Train Sim World 5 RhB Arosa Aggregates Pack (AppID: 2970480)
addappid(2970480)
addappid(2970480, 1, "4eea97e7f2c9182fca794a8402d57050dcd18ec9bbaa8b0edc3440e17503c3cc") -- Train Sim World 5 RhB Arosa Aggregates Pack - Depot 2970480
setManifestid(2970480, "2625464447697640654", 0)

-- Train Sim World 5 Cargo Line Vol. 1 - Petroleum (AppID: 2970490)
addappid(2970490)
addappid(2970490, 1, "fb7b2155302471f2d57da3930b70bd8c028a515b337088c1c95b98bc64e23c37") -- Train Sim World 5 Cargo Line Vol. 1 - Petroleum - Depot 2970490
setManifestid(2970490, "319363963528368203", 0)

-- Train Sim World 5 Centro Regional Railways BR Class 323 Add-On (AppID: 2970500)
addappid(2970500)
addappid(2970500, 1, "f645889ec271f49a6d68f8a2ffaa90a3e87023c219ef2ff513f1960a280045e7") -- Train Sim World 5 Centro Regional Railways BR Class 323 Add-On - Depot 2970500
setManifestid(2970500, "1943646762321608375", 0)

-- Train Sim World 5 Edinburgh - Glasgow Engineering Express Pack (AppID: 2970510)
addappid(2970510)
addappid(2970510, 1, "be794ef4e6cc3233299833a862fd4ce0a6811e2f050312b51c1b8aa286cb0d46") -- Train Sim World 5 Edinburgh - Glasgow Engineering Express Pack - Depot 2970510
setManifestid(2970510, "5463265523439903098", 0)

-- Train Sim World 5 Berninalinie Tirano - Ospizio Bernina Route Add-On (AppID: 2970520)
addappid(2970520)
addappid(2970520, 1, "b9952fd62c62db9e1e9042276d3ae98a2edf692362abbb4f90671322d16d248d") -- Train Sim World 5 Berninalinie Tirano - Ospizio Bernina Route Add-On - Depot 2970520
setManifestid(2970520, "6499148265013405277", 0)

-- Train Sim World 5 LIRR Commuter New York - Long Beach, Hempstead  Hicksville Route Add-On (AppID: 2970530)
addappid(2970530)
addappid(2970530, 1, "641154c3ca19b8d28c209e20ab94136b595f9dd182cd2ae941a9319312dc7649") -- Train Sim World 5 LIRR Commuter New York - Long Beach, Hempstead  Hicksville Route Add-On - Depot 2970530
setManifestid(2970530, "2146615997206158098", 0)

-- Train Sim World 5 Bahnstrecke Salzburg - Rosenheim Route Add-On (AppID: 2970540)
addappid(2970540)
addappid(2970540, 1, "7dbcc005ee4e48f117b3413a8251ff5bfdef77a067169efd85cc3cb3f76dcf16") -- Train Sim World 5 Bahnstrecke Salzburg - Rosenheim Route Add-On - Depot 2970540
setManifestid(2970540, "4815908617165847325", 0)

-- Train Sim World 5 London Overground Suffragette line Gospel Oak - Barking Riverside Route Add-On (AppID: 2970550)
addappid(2970550)
addappid(2970550, 1, "18f91a6a1abe401c98c57406b58c3e6af1bc5e45654b653333c7a9d6301ce904") -- Train Sim World 5 London Overground Suffragette line Gospel Oak - Barking Riverside Route Add-On - Depot 2970550
setManifestid(2970550, "7191299208340105022", 0)

-- Train Sim World 5 Cargo Line Vol. 2 - Aggregates (AppID: 2970560)
addappid(2970560)
addappid(2970560, 1, "ee6df76625e3ad89f3bbb170834d4bf467e9696268e611bad475c17b79e503fe") -- Train Sim World 5 Cargo Line Vol. 2 - Aggregates - Depot 2970560
setManifestid(2970560, "5734886619684616184", 0)

-- Train Sim World 5 Fife Circle Line  Levenmouth Rail Link Route Add-On (AppID: 2970580)
addappid(2970580)
addappid(2970580, 1, "1391028771652830cd76b44b6239fac7746643aeabb0114a8215b9dc94d93e58") -- Train Sim World 5 Fife Circle Line  Levenmouth Rail Link Route Add-On - Depot 2970580
setManifestid(2970580, "6298279202025634041", 0)

-- Train Sim World 5 ScotRail BR Class 158 Sprinter DMU Add-On (AppID: 2970610)
addappid(2970610)
addappid(2970610, 1, "318fad4782f66ddaba23c8cd35ed1b73798192f6ce0253b3ebe1d164a261a557") -- Train Sim World 5 ScotRail BR Class 158 Sprinter DMU Add-On - Depot 2970610
setManifestid(2970610, "5833932458627674769", 0)

-- Train Sim World 5 ECML Diesel Railtour Pack (AppID: 2970630)
addappid(2970630)
addappid(2970630, 1, "3bda2355cdb873ae14d2a00923bcac65243ae548fb063c99df454dc798bf0f57") -- Train Sim World 5 ECML Diesel Railtour Pack - Depot 2970630
setManifestid(2970630, "6866403210777668806", 0)

-- Train Sim World 5 Semmeringbahn Wiener Neustadt - Mrzzuschlag Route Add-On (AppID: 2970660)
addappid(2970660)
addappid(2970660, 1, "8e6189d4ebe8da8d17ffc9ed823f6dffa6b66e930bfb81137a435d1bc0bc392a") -- Train Sim World 5 Semmeringbahn Wiener Neustadt - Mrzzuschlag Route Add-On - Depot 2970660
setManifestid(2970660, "8002532991792361177", 0)

-- Train Sim World 5 West Coast Main Line Preston - Carlisle Route Add-On (AppID: 2970680)
addappid(2970680)
addappid(2970680, 1, "77f0518507b23fe26a2849e2c96ae0f5a7b609cf8fa63e3f6952760f707eb54f") -- Train Sim World 5 West Coast Main Line Preston - Carlisle Route Add-On - Depot 2970680
setManifestid(2970680, "6011251981924721702", 0)

-- Train Sim World 5 DB BR 218 Diesel Loco Add-On (AppID: 2970700)
addappid(2970700)
addappid(2970700, 1, "0deec306c613ee644b578978b9ecc372a5eb8051595c6a68cb2e356947d59347") -- Train Sim World 5 DB BR 218 Diesel Loco Add-On - Depot 2970700
setManifestid(2970700, "8307007884808473979", 0)

-- Train Sim World 5 Expert DB BR 101  IC Steuerwagen Loco Add-On (AppID: 2970750)
addappid(2970750)
addappid(2970750, 1, "ed5c1f0ececa2881912b3e8a96abd3b7c84bdcee6ec1000822e685bdf7418783") -- Train Sim World 5 Expert DB BR 101  IC Steuerwagen Loco Add-On - Depot 2970750
setManifestid(2970750, "6262313862294791143", 0)

-- Train Sim World 5 ScotRail BR Class 380 EMU Add-On (AppID: 2970760)
addappid(2970760)
addappid(2970760, 1, "0ffa29a78a918bc368e36e925f3dd5b61c54378995a58668380210c7c5ebbf22") -- Train Sim World 5 ScotRail BR Class 380 EMU Add-On - Depot 2970760
setManifestid(2970760, "9075121846005826424", 0)

-- Train Sim World 5 San Bernardino Line Los Angeles - San Bernardino Route Add-On (AppID: 2970790)
addappid(2970790)
addappid(2970790, 1, "b01559260932f3ba0d1b0796e2ba6446e04ca161ea99a638db5288d7bae235f6") -- Train Sim World 5 San Bernardino Line Los Angeles - San Bernardino Route Add-On - Depot 2970790
setManifestid(2970790, "5446604986393936201", 0)

-- Train Sim World 5 West Coast Main Line London Euston - Milton Keynes Route Add-On (AppID: 2970800)
addappid(2970800)
addappid(2970800, 1, "2658aa87e62128d623dca3fb4e91f6965f68ee6a0651ab5a6eadd0511ecf2c5b") -- Train Sim World 5 West Coast Main Line London Euston - Milton Keynes Route Add-On - Depot 2970800
setManifestid(2970800, "1929567087241877233", 0)

-- Train Sim World 5 Frankfurt - Fulda Kinzigtalbahn Route Add-On (AppID: 2970810)
addappid(2970810)
addappid(2970810, 1, "0ef93d70af550d1f7248a7a9ff16b8f3ea6bbcb8f8811bee2613d536c4b52fd1") -- Train Sim World 5 Frankfurt - Fulda Kinzigtalbahn Route Add-On - Depot 2970810
setManifestid(2970810, "6306100962868639031", 0)

-- Train Sim World 5 Avanti West Coast BR Class 390 Pendolino EMU Add-On (AppID: 2970820)
addappid(2970820)
addappid(2970820, 1, "040b7a1b54ca42cef4f6fc4d320d8992ac8f308bba6cae57693f917e1a43993b") -- Train Sim World 5 Avanti West Coast BR Class 390 Pendolino EMU Add-On - Depot 2970820
setManifestid(2970820, "8301228794640750656", 0)

-- Train Sim World 5 FlixTrain BR 193 Vectron Loco Add-On (AppID: 2970830)
addappid(2970830)
addappid(2970830, 1, "9250a4a6aa94f80d86cf47efef9e14933c1f4fa2caca986b8a5cca4cd5bc7c26") -- Train Sim World 5 FlixTrain BR 193 Vectron Loco Add-On - Depot 2970830
setManifestid(2970830, "2043039605609759089", 0)

-- Train Sim World 5 Mittenwaldbahn Innsbruck - Garmisch-Partenkirchen Route Add-On (AppID: 2970840)
addappid(2970840)
addappid(2970840, 1, "add9dc26764e17fdf94d6ad00555ca6fcc9f15d71c247e3ee1b41a5fa8020cd7") -- Train Sim World 5 Mittenwaldbahn Innsbruck - Garmisch-Partenkirchen Route Add-On - Depot 2970840
setManifestid(2970840, "8317221942172739336", 0)

-- Train Sim World 5 MBTA Commuter Boston - FraminghamWorcester Line Route Add-On (AppID: 2970920)
addappid(2970920)
addappid(2970920, 1, "63286aaa6bf81d62ea0450b311fc7b04c20020738b3b293c7b680bc8a3612d03") -- Train Sim World 5 MBTA Commuter Boston - FraminghamWorcester Line Route Add-On - Depot 2970920
setManifestid(2970920, "2103250316330528405", 0)

-- Train Sim World 5 Pflzische Ludwigsbahn Mannheim - Kaiserslautern Route Add-On (AppID: 2971180)
addappid(2971180)
addappid(2971180, 1, "99f393f27f3f01183e44e847b481afc840a05e1fe8861de9711378c8a5e55fbf") -- Train Sim World 5 Pflzische Ludwigsbahn Mannheim - Kaiserslautern Route Add-On - Depot 2971180
setManifestid(2971180, "84208415091531437", 0)

-- Train Sim World 5 London Overground Mildmay line Stratford - Willesden Junction Route Add-On (AppID: 2971190)
addappid(2971190)
addappid(2971190, 1, "1d4d5d2cdbcc76e1f34f4d9467d5de07ffb5245a0ced0708c1b4858ff4694858") -- Train Sim World 5 London Overground Mildmay line Stratford - Willesden Junction Route Add-On - Depot 2971190
setManifestid(2971190, "7248406306024806498", 0)

-- Train Sim World 5 Cargo Line Vol. 3 - Intermodal  (AppID: 2971210)
addappid(2971210)
addappid(2971210, 1, "63e9ac2e0ca4be6c058ff4f6c26951ac1cfa9a62b0449c89b794f69a4007f9e4") -- Train Sim World 5 Cargo Line Vol. 3 - Intermodal  - Depot 2971210
setManifestid(2971210, "4256113113360240990", 0)

-- Train Sim World 5 Cardiff City Network Radur  Coryton  Penarth  Bae Caerdydd Route Add-On (AppID: 2971220)
addappid(2971220)
addappid(2971220, 1, "64575197980e9a4180fa1723efd52edcd49d59a58f62f8956aac5d564404f3ff") -- Train Sim World 5 Cardiff City Network Radur  Coryton  Penarth  Bae Caerdydd Route Add-On - Depot 2971220
setManifestid(2971220, "3238158651109115157", 0)

-- Train Sim World 5 Thomas  Friends Visit the West Somerset Railway  (AppID: 2971230)
addappid(2971230)
addappid(2971230, 1, "e6646f8e0e1f5dc0ebaa808317c0619fad821792824ddf1949fa46ef70dcc976") -- Train Sim World 5 Thomas  Friends Visit the West Somerset Railway  - Depot 2971230
setManifestid(2971230, "1646162300554227626", 0)

-- Train Sim World 5 Metrolink Holiday Train Pack  (AppID: 2971240)
addappid(2971240)
addappid(2971240, 1, "f8e73faf7422edf1beb8f42ff13a3d32054fb8e64a7f302ddaa4743b0e2b4718") -- Train Sim World 5 Metrolink Holiday Train Pack  - Depot 2971240
setManifestid(2971240, "5028713188687594609", 0)

-- Train Sim World 5 HKA Bogie Hopper Wagon Pack  (AppID: 2971250)
addappid(2971250)
addappid(2971250, 1, "a860ac6cd7dfc944406d855da6ae1a17bb6a3e92adcd22137aa38548a39fd220") -- Train Sim World 5 HKA Bogie Hopper Wagon Pack  - Depot 2971250
setManifestid(2971250, "8502271642125150822", 0)

-- Train Sim World 5 DB BR 111  n-Wagen Pack (AppID: 2971260)
addappid(2971260)
addappid(2971260, 1, "ac2115032b724eeeb7b3ebc9e65a78afd46e43ce2873bff7108d18a48eacc776") -- Train Sim World 5 DB BR 111  n-Wagen Pack - Depot 2971260
setManifestid(2971260, "4307931909909661224", 0)

-- Train Sim World 5 Spoorlijn Zwolle - Groningen Route Add-On  (AppID: 2971270)
addappid(2971270)
addappid(2971270, 1, "f23fa21ba10cd4c3fe4b11d1bcb3a0b6a1630501eb452de6af1f419d4b48857c") -- Train Sim World 5 Spoorlijn Zwolle - Groningen Route Add-On  - Depot 2971270
setManifestid(2971270, "4611061018541694839", 0)

-- Train Sim World 5 Metrolink F59PHR Loco Add-On  (AppID: 3260370)
addappid(3260370)
addappid(3260370, 1, "400fe6b15b0958f3b646173106a40072399b2cef6d164044904bd0f1a72b41ed") -- Train Sim World 5 Metrolink F59PHR Loco Add-On  - Depot 3260370
setManifestid(3260370, "9080592309811088864", 0)

-- Train Sim World 5 Cargo Line Vol. 4 - Military (AppID: 3260410)
addappid(3260410)
addappid(3260410, 1, "08d09d53aef90488fd829abb114b7688050d5c1b377383c185f1f5224e0dadc5") -- Train Sim World 5 Cargo Line Vol. 4 - Military - Depot 3260410
setManifestid(3260410, "5107095073784319991", 0)

-- Train Sim World 5 Frankfurt S-Bahn S1, S8  S9 Route Add-On  (AppID: 3260440)
addappid(3260440)
addappid(3260440, 1, "b3192a7104f490ec077b63807b4cfcea2aadfaf1d63332b233e5e7cb1ac64d00") -- Train Sim World 5 Frankfurt S-Bahn S1, S8  S9 Route Add-On  - Depot 3260440
setManifestid(3260440, "5597492232909280698", 0)

-- Train Sim World 5 Thomas  Friends 80th Anniversary Expansion (AppID: 3457350)
addappid(3457350)
addappid(3457350, 1, "ea542c47eeb1efaedb5c39a7f4b6a32acaf1f198f3e51a2b7e1293cbc2c92576") -- Train Sim World 5 Thomas  Friends 80th Anniversary Expansion - Depot 3457350
setManifestid(3457350, "8708563215434037167", 0)
