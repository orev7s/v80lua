-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(534380, 1, "da5060467c4b9199432fb5d9ba41ae2896a9c4a4705bc8e8f426155dc8efae83") -- Dying Light 2: Reloaded Edition

-- MAIN APP DEPOTS
addappid(534381, 1, "fec776617825a7f3e61dd191f407bd23c6f60ba1056a506f1facb4fd74d9f7e2") -- data_common
setManifestid(534381, "2431211655003768534", 0)
addappid(534382, 1, "cf933660206b892b3d32060682d4063e7a42482428b1cbb3f0b8fed43cdfee45") -- binaries_windows
setManifestid(534382, "1973955231117206288", 0)
addappid(534383, 1, "1a2b6e67c39a9803c80ab38c1be8b25b112ae32eaa1872b6cd42db109049e007") -- data_windows
setManifestid(534383, "6639748655531310770", 0)
addappid(534384, 1, "b5e4f819a4ac1b9e78bca8293db8428a4eea8a95b6913fc32842010060db425e") -- data_lang_en
setManifestid(534384, "900395428038630535", 0)
addappid(534385, 1, "c7a22e2cab3e656efbdaceb8e2a7b76748c1790517faf3283beaa2cf761f5dc0") -- data_windows_lang_en
setManifestid(534385, "4975424511675893864", 0)
addappid(534387, 1, "d3fcdef424d1ec4c1a72bc78a8ae5364b74a5abd23ef7cbeca64996cad28b24b") -- data_lang_ar
setManifestid(534387, "1935456551746027043", 0)
addappid(534388, 1, "9af548a883576aa8eb98d69ceef4d0a50b7e5beebe14744e078cd2f47ace909b") -- data_lang_br
setManifestid(534388, "7734306966367034259", 0)
addappid(534389, 1, "3e6c48fa5a81522f18e7633fa89b6ea95f05d991c626ee9ceaebecf711cd6e72") -- data_windows_lang_br
setManifestid(534389, "1300212907823593285", 0)
addappid(1741780, 1, "56a0e9c235e8305b7e1f1e722252b52918ea0003a341b5901c42ec0d39cd449c") -- data_lang_cn
setManifestid(1741780, "6540041772615006948", 0)
addappid(1741781, 1, "42678fed970f2d33723e75c88c27c4d19278d40ddbea2be652c02d7dfb41404f") -- data_windows_lang_cn
setManifestid(1741781, "7370229488720708177", 0)
addappid(1741782, 1, "26d52711c65b1d4c96eb06fb7fba2a68e80984a9828a074bf8a5384c16e86433") -- data_lang_cntr
setManifestid(1741782, "5111549044329075420", 0)
addappid(1741783, 1, "f1fd93f6cd43dbde9dfecda6beceaec208b0c3842cd34ded16b3f31ae7984f0b") -- data_lang_cz
setManifestid(1741783, "3489386982795606791", 0)
addappid(1741784, 1, "56ca0a485646ce4d5fb8163100b5f62610f743c214fabd9133f57b3dc3720d44") -- data_lang_de
setManifestid(1741784, "4250953824362817398", 0)
addappid(1741785, 1, "377954647d348be60b76ce49cae9b13763ad66aba3ce9ec5e1b0ba1f9f6c7a49") -- data_windows_lang_de
setManifestid(1741785, "6811508315827086568", 0)
addappid(1741786, 1, "19a6afcb6a47753b8b8d5f8a0febea931845a56103db941a3cedc57fa4fa3632") -- data_lang_el
setManifestid(1741786, "5745490560579869331", 0)
addappid(1741787, 1, "a2dcee88dfd62b92c47a6260dd083eefd70bb504b41012881ef45e10d3ef31e4") -- data_windows_lang_el
setManifestid(1741787, "7269720910837587775", 0)
addappid(1741788, 1, "5647c59ff805db90b39f2286a138774c318579addeb0ae3cd67cb37be8391794") -- data_lang_es
setManifestid(1741788, "1029618011306315267", 0)
addappid(1741789, 1, "d45069f6f74b78a88a6d5bd30c9e7e56cb00c84e80957adc473e0815581f8ca5") -- data_windows_lang_es
setManifestid(1741789, "6643666169597174051", 0)
addappid(1741790, 1, "ffb3557cf402c7a2847a17a705d05cc02b1c921cedb1a4e33c0965c3ef3b8ead") -- data_lang_fr
setManifestid(1741790, "6412698918778375817", 0)
addappid(1741791, 1, "83833d3a3c1d59757bd4fd32fe79b0498cfdbd4ba1a4c770319bf58734d3220c") -- data_windows_lang_fr
setManifestid(1741791, "7985642131435435878", 0)
addappid(1741792, 1, "eec928bf10da86f55bc03800c52b9292406c09c72e9d5ef99373c846e960f5ca") -- data_lang_it
setManifestid(1741792, "5667776213858150255", 0)
addappid(1741793, 1, "4dd7ff0cb01db2bf5c574054353078bef596a1cd611a8268bd5a023c65022278") -- data_lang_jp
setManifestid(1741793, "7712872807986339616", 0)
addappid(1741794, 1, "17d125330d6f175e6c28c56630312084fe07a44a06bcbffc530c3f590d01667c") -- data_windows_lang_jp
setManifestid(1741794, "4000949483817469060", 0)
addappid(1741795, 1, "8b0095c3dc40776199884af8ac54987c23277a352c03f79acdbf51eea7ef6191") -- data_lang_ko
setManifestid(1741795, "5708377914858544403", 0)
addappid(1741796, 1, "6d55d6c6f95126badb8fc4d39fafcd9abfe6470847f8c3a81057aa9b260c6107") -- data_lang_pl
setManifestid(1741796, "2673483473009527883", 0)
addappid(1741797, 1, "b3c0705864ffb87b5be6890de5ecd919959de996b6a9a60ec6f84a3bea7bd768") -- data_windows_lang_pl
setManifestid(1741797, "2086682394900066193", 0)
addappid(1741798, 1, "dac1cd4282c31bca5e08c68b37b3939433252e9716025c74c0eef121dcc56938") -- data_lang_pt
setManifestid(1741798, "3842467555925097725", 0)
addappid(1741799, 1, "962cef0a55b1ae29a391f43431ee4b98a4f54bb40cab9b0a047491df31d5b6c2") -- data_lang_ru
setManifestid(1741799, "8557508875599521571", 0)
addappid(1741800, 1, "85cbd9ea07b0212def7701851f906cfc2015697823afa00849e0ffadacb4ee2c") -- data_windows_lang_ru
setManifestid(1741800, "6931320953933785693", 0)
addappid(1741801, 1, "8d26e4e39b3d4f7beec6b01e44a9c7caf7d5e9eae6e499ef414cde2d79caa94b") -- data_lang_tr
setManifestid(1741801, "2724688667461108035", 0)
addappid(1741802, 1, "0452622d330096a7e928803be80e7f859a861c522eebb67fc338824122ea90cb") -- data_windows_lang_ar
setManifestid(1741802, "8369068266057563647", 0)
addappid(1741803, 1, "921360aefff71e9ec8ab8a2ee251e4b718ff615f3183c5fe0e0080bf7f434766") -- data_windows_lang_cntr
setManifestid(1741803, "9165989432588229945", 0)
addappid(1741804, 1, "6d1931aa3987c3bf777944cd3240584ed15e169dc8ad97da57449f72730911cb") -- data_windows_lang_ko
setManifestid(1741804, "2382853488395355170", 0)

-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 0)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "550968249685141759", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Dying Light 2 Stay Human Bloody Ties (AppID: 1537624)
addappid(1537624)
addappid(1741805, 1, "7fd30a7a706af1dc2c94010cf7486ebf1d49af69f2aebe663075b6810d1dd527") -- Dying Light 2 Stay Human Bloody Ties - Depot 1741805
setManifestid(1741805, "5373479986815706731", 0)

-- Dying Light 2 - Developer Tools (AppID: 2217480)
addappid(2217480)
addappid(1263581, 1, "b7e959a2f431a626db99f0f9d3e4f9da7b5f725308214738c3f93ecc70aec314") -- Dying Light 2 - Developer Tools - Depot 1263581
setManifestid(1263581, "4576148900009433954", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1537620) -- Dying Light 2 - Deluxe Pack
addappid(1537621) -- Dying Light 2 - Ultimate pack
addappid(1537622) -- Dying Light 2 - Artbook
addappid(1537623) -- Dying Light 2 - Pre-order pack
addappid(1864100) -- Dying Light 2 - Peacekeeper 01
addappid(1864200) -- Dying Light 2 - Peacekeeper 02
addappid(1864230) -- Dying Light 2 - Peacekeeper 03
addappid(1864240) -- Dying Light 2 - Survivor 01
addappid(1864250) -- Dying Light 2 - Survivor 02
addappid(1864260) -- Dying Light 2 - Survivor 03
addappid(1888510) -- Dying Light 2 - Soundtrack
addappid(1937530) -- Dying Light 2 - Deluxe Upgrade
addappid(1937531) -- Dying Light 2 - Ultimate Upgrade
addappid(2108090) -- Dying Light 2 - The Aristocrat Pack
addtoken(2108090, "7241572958295469293")
addappid(2156750) -- Dying Light 2 - Dying Laugh Bundle
addappid(2210190) -- Dying Light 2 - Nutcracker Bundle
addappid(2269810) -- Dying Light 2 - Rais Skin Bundle
addappid(2269820) -- Dying Light 2 - Brecken Skin Bundle
addappid(2330980) -- Dying Light 2 - Chicken Bundle
addappid(2370460) -- Dying Light 2 - Rahim Bundle
addappid(2370480) -- Dying Light 2 - Gunslinger Bundle
addappid(2370700) -- Dying Light 2 - Post-apo Bundle
addappid(2370710) -- Dying Light 2 - Nightrunner Bundle
addappid(2400900) -- Dying Light 2 Stay Human The Walking Dead Bundle
addappid(2456710) -- Dying Light 2 - Hakon Bundle
addappid(3453200) -- Dying Light 2 Stay Human G.R.E. Hazmat Bundle
