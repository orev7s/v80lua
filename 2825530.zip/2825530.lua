addappid(2825530)
addappid(2825531,0,"9c431873f776d9053638ad83bb819f7f4b0333e29467bca05809f8ca19e1aec9")
setManifestid(2825531,"2433872507592348212")




--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]