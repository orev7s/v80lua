-- Made by f1uxin, please read the read me TXT file
-- MAIN APPLICATION
addappid(3676960) -- The Last Train

-- MAIN APP DEPOTS
addappid(3676961, 1, "dbe396514ce3fc8be3577f1f52fa9aaafae776560598070c625c0c4878fae30a") -- Depot 3676961
setManifestid(3676961, "4779868834228722503", 0)
