addappid(1231560)
addappid(1231561,0,"fd1c18a5c89c59cf23926c576d78b90028d7bde9a857b8ce9579d893305ebbd5")
setManifestid(1231561,"6402543383554775381")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]