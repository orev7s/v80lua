-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(3401000) -- Car Mechanic Shop Simulator

-- MAIN APP DEPOTS
addappid(3401001, 1, "e0805c6da423b023a4aaee83809cef9ebdc1eca5a36d64e0733c52862c667161") -- Main Game Content (Windows Content)
setManifestid(3401001, "3431651457997593276", 0)
