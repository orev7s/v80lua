-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(991260) -- Borderlands 2 VR

-- MAIN APP DEPOTS
addappid(991261, 1, "a3dfffbc00e24551b2cff222f4736d383a960a1957e5afd4e69b287cfc6b5400") -- Protea Binaries
setManifestid(991261, "2594482743839673571", 0)
addappid(991262, 1, "57ce37728eaf3997849c2ae529c6ead9c222df09124cc9b9329d024cee2f6261") -- Protea Content
setManifestid(991262, "2492999669730761521", 0)
addappid(991263, 1, "11ec3c62a62929b4027a35b2c385326fa9d36916cf986980bfb21530c866aaef") -- Protea INTLoc
setManifestid(991263, "3886563136252809433", 0)
addappid(991264, 1, "1147224f62bac402a19d38b9d90523d13a0bd405840ab0e5b5c2002c1fdf765b") -- Protea FRALoc
setManifestid(991264, "2104169220596163748", 0)
addappid(991265, 1, "4c1d83a76df93ae73096c5dd162b43bccfce3005a3075bbf4c862c188904d362") -- Protea ITALoc
setManifestid(991265, "343205011938971620", 0)
addappid(991266, 1, "6b0ebca423aede7881a7ef794875a37b7c94337e00e9e7b86eb899127fd378d5") -- Protea DEULoc
setManifestid(991266, "8718485485347051257", 0)
addappid(991267, 1, "a0d234a92ff2917f195800c3ce65e8a34b87d1cd68ae58b3eee5a9c3796cc139") -- Protea ESNLoc
setManifestid(991267, "8803429855327714345", 0)
addappid(991268, 1, "60cbceed6feb7311365f59d8da2a8f579126ce9725299188c2be1457089ccb25") -- Protea JPNLoc
setManifestid(991268, "4133101178963447382", 0)

-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- BAMF DLC PACK (AppID: 1046900)
addappid(1046900)
addappid(1046900, 1, "55d0f7a80b7f1a01e0b40c604a4e5a810430edb01c3f12997fc50fe44769605f") -- BAMF DLC PACK - Protea Test Pack 1 (1046900) Depot
setManifestid(1046900, "1221998979517157683", 0)
addappid(1046901, 1, "2f5b88d9270432a6bfe8270e0337d0085df2084cc48f866d50a0f7a25618be0d") -- BAMF DLC PACK - Protea Test Pack 1 INTLoc
setManifestid(1046901, "4847984316409922859", 0)
addappid(1046902, 1, "364759724e505695c0259a7147cfffc94dae610956e02e203e3b4497fb93cb0e") -- BAMF DLC PACK - Protea Test Pack 1 FRALoc
setManifestid(1046902, "677235297889830388", 0)
addappid(1046903, 1, "2353c38580a8f1bcd47bed40743a8ef4201bdfe2a528cc8a9ec995d483f7cc57") -- BAMF DLC PACK - Protea Test Pack 1 ITALoc
setManifestid(1046903, "891902819793351459", 0)
addappid(1046904, 1, "d06209eb4f51030bd357dd24e934f4c596694a680cd99c9492831fd098115bfd") -- BAMF DLC PACK - Protea Test Pack 1 DEULoc
setManifestid(1046904, "4807309417527600954", 0)
addappid(1046905, 1, "3a23e71e3dc70ab78d8346b44912ad8a648cd3cfe8740be07a9715de2e1138d0") -- BAMF DLC PACK - Protea Test Pack 1 ESNLoc
setManifestid(1046905, "703040252076982561", 0)
addappid(1046906, 1, "0efa7c679205db259e9a7013aed1906659470bbee7870b9e0edc75ba1488cb7c") -- BAMF DLC PACK - Protea Test Pack 1 JPNLoc
setManifestid(1046906, "613706115367783983", 0)
