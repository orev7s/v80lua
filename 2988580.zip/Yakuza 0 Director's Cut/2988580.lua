-- 2988580's Lua and Manifest Created by Morrenus
-- Yakuza 0 Director's Cut
-- Created: December 08, 2025 at 12:23:26 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2988580) -- Yakuza 0 Director's Cut
-- MAIN APP DEPOTS
addappid(2988581, 1, "5dd1da6fa3ee7c2ba5ff647beb5b4fd9899f1ed4c421a6af79eb65b7ce38cb6e") -- Depot 2988581
setManifestid(2988581, "2658804794365441837", 92661549303)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)