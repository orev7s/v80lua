-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(1401730) -- Crashlands 2

-- MAIN APP DEPOTS
addappid(1401731, 1, "9feb5500bb35f27058f1c86e3a465a1f4904b2f5abe5ff891a9928cb702fea64") -- Depot 1401731
setManifestid(1401731, "1086217142447527629", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Crashlands 2 Soundtrack (AppID: 3593320)
addappid(3593320)
addappid(3593321, 1, "f269062a16381157e8ae373ae1403169c9bcf17eeacd95af10c65d3a6660be97") -- Crashlands 2 Soundtrack - Depot 3593321
setManifestid(3593321, "5580063018933945586", 0)
addappid(3593322, 1, "c87866f70266b56d29c3ce956843372caa5f1620cc544eb699cff6c9dea03ebd") -- Crashlands 2 Soundtrack - Depot 3593322
setManifestid(3593322, "7801655496472368158", 0)
