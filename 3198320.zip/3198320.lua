-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(3198320) -- Willie's Nightfall

-- MAIN APP DEPOTS
addappid(3198321, 1, "a68fc92a25b2bf2e6d42ee742bff66d75ec40c1c92792805843b22375ab07851") -- Main Game Content (Windows Content)
setManifestid(3198321, "908822591183782709", 0)
