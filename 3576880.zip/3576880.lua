-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(3576880) -- Dreadline: Net Quota

-- MAIN APP DEPOTS
addappid(3576881, 1, "305a917fb951148e78dda70afd6cc512e4515b8cc9702304f2eeef6e3f44a2b5") -- Depot 3576881
setManifestid(3576881, "5264425530738085260", 0)

-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 0)
