addappid(1978720)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1978721,0,"c96e53b578cd0f6a533c9d82aef22990c5d8ae7a0625cbfad49bd3a0eff808fc")
setManifestid(1978721,"5929957955181670447")
addappid(2436880,0,"30aabeca75c1a99444db3744e3942f2c04c85f0af6b3992ecb7ed504010c670e")
setManifestid(2436880,"8950426244924249066")
addappid(2444360,0,"57265a62990b1959b8bf9ed272e37da31fdf2580937dfc340e5ceaf52af97e3e")
setManifestid(2444360,"5820591128768548634")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]