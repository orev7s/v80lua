-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(3706960) -- Ranch Farm and Store Simulator

-- MAIN APP DEPOTS
addappid(3706961, 1, "a1a4f83bc536c658071ce64e3c7693d17ed422982ef1da9b0fa7e579f9f347c0") -- Depot 3706961
setManifestid(3706961, "3766611244910088634", 0)
