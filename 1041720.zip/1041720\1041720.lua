addappid(1041720)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1041722)
addappid(1041721,0,"dc263061e909d671e1ef975d8405074724bbdb4528043bf746f0b92609816114")
setManifestid(1041721,"5908969417997115625")
addappid(1278260,0,"ffb3bd4a4a80e1c9ad24ece61bd05b4e830141fff5814bffaa0467bd0ad2be13")
setManifestid(1278260,"2202970019104823585")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]