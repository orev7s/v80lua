addappid(1489630)
addappid(1489631,0,"4aeaff33ce828e179d33a551109dd8861c61ced318318f07de6b519f081231b3")
setManifestid(1489631,"3743097997792179251")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]