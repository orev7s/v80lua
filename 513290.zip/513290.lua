-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(513290) -- Lucius III

-- MAIN APP DEPOTS
addappid(513291, 1, "6425e4416cefc0fe94d6337364cc6749165a2912c7e469709aa2a259febad6bc") -- Lucius III Content
setManifestid(513291, "2859760995296585728", 0)

-- DLCS EXCLUDED (NO DEPOT KEYS, NO DEDICATED DEPOTS)
-- addappid(985190) -- Lucius III - Soundtrack (no keys available)
