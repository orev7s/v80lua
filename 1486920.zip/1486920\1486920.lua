addappid(1486920)
addappid(228989)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1486921,0,"26528db8fe19a223ddd4dbc280b52006e6b4aad5884ce084762e313c91d0de46")
setManifestid(1486921,"4776977188543296732")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]