-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @F1uxin on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!)

-- MAIN APPLICATION
addappid(816120) -- First Winter

-- MAIN APP DEPOTS
addappid(816121, 1, "42f1b0b4824bfb4aa11998b87a5875fd677c6c968433683dad139726f3cb2409") -- Main Game Content (Windows Content)
setManifestid(816121, "929670119117721077", 0)
