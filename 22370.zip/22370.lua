-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(22370) -- Fallout 3 - Game of the Year Edition

-- MAIN APP DEPOTS
addappid(22371, 1, "4069e70a8a61568f540e8d6e7dabfcbe023909bc7423b7bcde27f916522fd6c9") -- fallout 3 goty content
setManifestid(22371, "2416786561786063548", 0)
addappid(22376, 1, "a9c84228fa12f03277d50abecbc3e09b97bbaf73080e3daadc0e9ddd9413a4a5") -- fallout 3 goty LV content
setManifestid(22376, "574311061399254078", 0)
addappid(22372, 1, "992a52b45d1b8af30bcc671ea17458c8cd25785e847c3f4ded78e1235cf25a03") -- Fallout 3: Game of the Year Edition French
setManifestid(22372, "827002912150357260", 0)
addappid(22373, 1, "46ab6de47092933c1b88ff77f62d3050e519e29058052a97d301acf46c2980e7") -- Fallout 3: Game of the Year Edition German
setManifestid(22373, "179161400861758364", 0)
addappid(22374, 1, "9e2a7fd390fdab4dca859aec379e420b50bdb8b15fe5b23c4f01d7040cef5de9") -- Fallout 3: Game of the Year Edition Spanish
setManifestid(22374, "5562528913773688286", 0)
addappid(22375, 1, "cf22e4172975f6c93ea05c6f2583c36154c90319229ef6d78e518abe641ea27a") -- Fallout 3: Game of the Year Edition Italian
setManifestid(22375, "5343648328298172273", 0)

-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
