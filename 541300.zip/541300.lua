-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(541300, 1, "896ff4574203f7469c3b05fee9977c6daa524514998849dd4406ffe2b5451465") -- Survive the Nights

-- MAIN APP DEPOTS
addappid(541301, 1, "b7b1714545390bb091ec6e388ea12b869fffbebbedf1ede843274799b1d6bb73") -- Survive the Nights Mac
setManifestid(541301, "9147263525803475405", 0)
addappid(541302, 1, "e108e3e856b5624a39650b492d6fe4fc7d5f3818db8ea9cab1c8e4560fa39f7e") -- Survive the Nights Windows
setManifestid(541302, "1289975079939446578", 0)
