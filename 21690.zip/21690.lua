-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(21690) -- Resident Evil 5

-- MAIN APP DEPOTS
addappid(21692, 1, "556f26dec9fcd54f1ecb0f2af6b1259a325a3eed959c0b242c83fa176c74971d") -- Resident Evil 5 (non-GFWL)
setManifestid(21692, "8019335905957731486", 0)
addappid(21691, 1, "b3ad2af3d25d179accc032ae7853c6f8a916bba21b5f0be9f11f22f0938110a4") -- resident_evil_5_content
setManifestid(21691, "2911490666295175655", 0)
addappid(21693, 1, "a07f44cc54133c4921ca14f7014ea4a5fd0aa0dbc36d13f3d7abe5f3be00c564") -- resident evil 5 / biohazard 5 Test Depot
setManifestid(21693, "3603548504038570692", 0)

-- SHARED DEPOTS (from other apps)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- VC 2005 Redist (Shared from App 228980)
setManifestid(228981, "7613356809904826842", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Resident Evil 5 - UNTOLD STORIES BUNDLE (AppID: 352000)
addappid(352000)
addappid(352000, 1, "dba46409b51f3da1c7669a74a091ce7725eb5969705192edbb9ba3f9abd096d3") -- Resident Evil 5 - UNTOLD STORIES BUNDLE - Resident Evil 5 - DLC Pack (352000) Depot
setManifestid(352000, "455789278129163691", 0)
