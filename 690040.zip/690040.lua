-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(690040) -- SUPERHOT: MIND CONTROL DELETE

-- MAIN APP DEPOTS
addappid(690041, 1, "d7b6546532d440e08e3070be7a2f40cc462135f7a99604b2b8f4bac641ec5819") -- SUPERHOT : DISK 2 Content
setManifestid(690041, "1019339867738125367", 0)
addappid(690042, 1, "e1b7d8c628e8b58b309617e4b36023dd4c5ed0593bdec2db83a7077db8aca9e4") -- SUPERHOT : DISK 2 Depot - Mac
setManifestid(690042, "5352521899812584566", 0)
addappid(690043, 1, "9fd622d1ccbd15efa14c398acb544facdae92d714fe48c707ebbffe217073c05") -- SUPERHOT : DISK 2 Depot - Linux
setManifestid(690043, "2780744448761455312", 0)

-- SHARED DEPOTS (from other apps)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- .NET 4.7 Redist (Shared from App 228980)
setManifestid(229006, "1784011429307107530", 0)

-- DLCS WITH DEDICATED DEPOTS
-- SUPERHOT MIND CONTROL DELETE Soundtrack (AppID: 1261380)
addappid(1261380)
addappid(1261384, 1, "5afc9946955f6a508873bf3e741f56e7625bc953f35f77bdf794c02d14c4a086") -- SUPERHOT MIND CONTROL DELETE Soundtrack - SUPERHOT: MIND CONTROL DELETE Soundtrack WAV
setManifestid(1261384, "7833430045984200695", 0)
addappid(1261385, 1, "a7699c29ec41b8aa0126952818c176f3033123efa31f83b56e4a991fa96238b7") -- SUPERHOT MIND CONTROL DELETE Soundtrack - SUPERHOT: MIND CONTROL DELETE Soundtrack MP3
setManifestid(1261385, "7879592702160038029", 0)
