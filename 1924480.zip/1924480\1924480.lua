addappid(1924480)
addappid(1924481,0,"ff635112056ca80dc0760a59372d872768946344dc5d10a5e63676f081245cf7")
setManifestid(1924481,"7156778105120861530")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]