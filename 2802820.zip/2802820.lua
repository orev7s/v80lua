-- Made By @F1uxin
-- MAIN APPLICATION
addappid(2802820) -- School 666

-- MAIN APP DEPOTS
addappid(2802821, 1, "b9b87b3927b1b8e5a42ff1c971d8e7da18f4471694f024fd2f9d55402345a76f") -- Main Game Content (Windows Content)
setManifestid(2802821, "132532695961006283", 0)

-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "550968249685141759", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
