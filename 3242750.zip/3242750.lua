-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(3242750) -- Level Devil

-- MAIN APP DEPOTS
addappid(3242751, 1, "20715373400230b7184afdfb64c33c5a97093edd019c92ada23c16db734de7b3") -- Main Game Content (Windows Content)
setManifestid(3242751, "3424665579187520361", 0)
