addappid(1906020)
addappid(1906021,0,"71625ccc26c54523aca402bba21808bb3473b5fe3428f415a43052c54335af7a")
setManifestid(1906021,"349546685870181251")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]