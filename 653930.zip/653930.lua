-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(653930)
addappid(653932,0,"8c3d3c7df4b3f0f5c06bce6e886996cdb7e5ed68b44abb328ec1cd246a3a7e22")
setManifestid(653932,"2796213461782136813")
addappid(885071,0,"92713d9003ef44a8b42be593458eae807f2735e33136dd416b89a4defcb098a4")
setManifestid(885071,"2175170737769915241")
addappid(885070,0,"7645db3b811103b456c927515aa8a54f77cd75c5574787ac81c976b200b83533")
setManifestid(885070,"6897530295272713260")