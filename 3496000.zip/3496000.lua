-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(3496000) -- Ship, Inc.

-- MAIN APP DEPOTS
addappid(3496001, 1, "ab5f7aa3985fbccdb6589b71db8c36547133ecf078cf8935abd0f2964f35f10a") -- Depot 3496001
setManifestid(3496001, "1100073554326351770", 0)
