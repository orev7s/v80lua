addappid(1273400)
addappid(1273401, 1, "7ac6b6d000ec93fdd41c708fdaa554b3b457d5e9c07bb1947f2d555502c12b28")
setManifestid(1273401, "3865778386251301607", 0)
addappid(2295811, 1, "81149cf5bfb357c4d5e9ca09e28b9bb871218513bf57671f45b4db19322e3987")
setManifestid(2295811, "3383914678723808175", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]