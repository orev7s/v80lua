-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(3321360) -- Seedbo And That Time The Sun Exploded

-- MAIN APP DEPOTS
addappid(3321361, 1, "72131654c944fed113550e8c585eaab9d4b010fa6f5a3d3d070c6ab54efb3214") -- Depot 3321361
setManifestid(3321361, "6194207117121473464", 0)
