-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(874260) -- The Forgotten City

-- MAIN APP DEPOTS
addappid(874261, 1, "3b1c4d8d491dc8fd3c3008d70b84c957db612d2b51979b810b16af4043994602") -- The Forgotten City Content
setManifestid(874261, "5370425040235436106", 0)

-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- The Forgotten City Soundtrack (AppID: 1662400)
addappid(1662400)
addappid(1662401, 1, "34efa269911aa1e31f0da24c422e4e5ef7e2842785030dd495d78566c9dea920") -- The Forgotten City Soundtrack - The Forgotten City Soundtrack Content
setManifestid(1662401, "4812467436640825718", 0)
addappid(1662402, 1, "0d1de7b85b3fcdd2274c22ba9e207366a689d7d765e640cb35bc077ec5c5ee53") -- The Forgotten City Soundtrack - The Forgotten City Soundtrack Depot WAV
setManifestid(1662402, "5210657442143489175", 0)

-- The Forgotten City - Collectors DLC (AppID: 1662430)
addappid(1662430)
addappid(1662430, 1, "76c7803b10279dd7ffe2bfb17f597ea39152272bfa09e024299cb80f9b37864f") -- The Forgotten City - Collectors DLC - The Forgotten City - Collector's DLC (1662430) Depot
setManifestid(1662430, "7608235754557237185", 0)
