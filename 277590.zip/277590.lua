-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy

-- MAIN APPLICATION
addappid(277590) -- Assassin's Creed Freedom Cry

-- MAIN APP DEPOTS
addappid(277591, 1, "78c2c8401115c053bafc67ee78274b0842e4cea71428bd07e00a086cbd93f4ed") -- Assassin's Creed Freedom Cry Content
setManifestid(277591, "6746774040519376819", 0)

-- SHARED DEPOTS (from other apps)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
setManifestid(228982, "6413394087650432851", 0)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- .NET 4.5.2 Redist (Shared from App 228980)
setManifestid(229004, "5220958916987797232", 0)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
setManifestid(1716751, "818295193716041715", 0)
