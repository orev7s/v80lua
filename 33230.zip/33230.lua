-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy

-- MAIN APPLICATION
addappid(33230) -- Assassin's Creed II

-- MAIN APP DEPOTS
addappid(33231, 1, "2d55de76a7fadc044cb4cf31eafd8546b8195eaf62d2476381df93bb84da56a5") -- assassins creed 2 content
setManifestid(33231, "6394869848543559007", 0)
addappid(33232, 1, "bb47c7fd504af5f9c703505e3886ccd9f0bf6482b591d0479043ed17da8cba3c") -- Assassin's Creed 2 French
setManifestid(33232, "7358374191055485996", 0)
addappid(33233, 1, "c623e9ef962e7a4f1a15fb1a4d60a3c060dcb6d5edd8955784809ea2a353bbb1") -- Assassin's Creed 2 German
setManifestid(33233, "6158833659408950236", 0)
addappid(33234, 1, "a62469abd90a4a4fc14bd4efe3d8f86635472cb0bb2d89dad78f415838bd5979") -- Assassin's Creed 2 Italian
setManifestid(33234, "3898055547501430026", 0)
addappid(33235, 1, "4a72fe9f21a6aad35d811cce424fe7dceb343419dd1943b2fe3b053b70f6332c") -- Assassin's Creed 2 Spanish
setManifestid(33235, "515782916759688319", 0)
addappid(33236, 1, "9f21cd6947593ed39cd345b6a5c1d16fd6a4d232352a7d2d39643200e7705f62") -- Assassin's Creed 2 Danish
setManifestid(33236, "7365193316111076013", 0)
addappid(33237, 1, "a0fd6cec45483682d1a2f4af1556b207a2d152a672fef795eb7385a14622d133") -- Assassin's Creed 2 Dutch
setManifestid(33237, "1200263841047134715", 0)
addappid(33238, 1, "c8266b60146e36ce9074dde2d5ce00a881f0437d828424ef9a0ba0c850009cf6") -- Assassin's Creed 2 Swedish
setManifestid(33238, "1813419851790652824", 0)
addappid(33239, 1, "269f77ce459a48a1f72bc418b53c21332b6e71db25b9ce46014e68d1a3a68338") -- Assassin's Creed 2 Norwegian
setManifestid(33239, "7535424137247575657", 0)
addappid(48171, 1, "6e38cabfcfea523490556c8c067f4971a66ec29cf2a3a9d0cbac5490f5b39298") -- Assassin's Creed 2 Mac Swedish
setManifestid(48171, "1936508653316340502", 0)
addappid(33363, 1, "e6b75b3f156b9c95b07d81a84370cffc3943b21aab950b6b2011047ad523a0b3") -- Assassin's Creed 2 Mac Danish
setManifestid(33363, "866226270040308685", 0)
addappid(33364, 1, "f75daebf1ddb79e9d4fff7e76a4a417fa9b91ee9919d7b997ce0db6da28b7b8c") -- Assassin's Creed 2 Mac Dutch
setManifestid(33364, "2216763090182997672", 0)
addappid(33365, 1, "49d452369642af482f7d74f5845f5574273844c7c1861eddb42ee46621757bf5") -- Assassin's Creed 2 Mac French
setManifestid(33365, "5284580050494942022", 0)
addappid(33366, 1, "830f62a662d17cebbfc2382023056991bd67f13eec0880797252f14cddf45f23") -- Assassin's Creed 2 Mac German
setManifestid(33366, "3348410246272123668", 0)
addappid(33367, 1, "0e7cdad7d5579a45e04d42e82590af56ef96789402fcc80a30e9a231515d7540") -- Assassin's Creed 2 Mac Italian
setManifestid(33367, "5663227002960473005", 0)
addappid(33368, 1, "af2f917a622faf61caaf7d7f0596e8d3d1ddcbf9528b6d3bf05b441a661a42f3") -- Assassin's Creed 2 Mac Norwegian
setManifestid(33368, "6149972289376771243", 0)
addappid(33369, 1, "2a270970213ccbc862dadbab5582fac1c7dd9c158d729fd8ad1a57e2cf93b97e") -- Assassin's Creed 2 Mac Spanish
setManifestid(33369, "4064048511977242320", 0)
addappid(48172, 1, "61aa72ecd727cb31ae0b456c3702fccf431f957f9ce15c2759cf77af038a87a2") -- assassins creed 2 mac application support
setManifestid(48172, "3795673990686183367", 0)
addappid(588820, 1, "eb6c5d5554bf95e20923d93601807f0429fe062e6a421b4f1aede7aae0ba1aae") -- Assassin's Creed 2 Korean
setManifestid(588820, "669229144561365127", 0)
addappid(588821, 1, "b2a2b44e26b2801b498ba14a685ccefff99f19228f7e16cfbae3a835581b9195") -- Assassin's Creed 2 SChinese
setManifestid(588821, "5900380671197258506", 0)
addappid(588822, 1, "9349bdd9444c11bd3fed26480a0859677527975396eeafd345416303be2f4cf2") -- Assassin's Creed 2 TChinese
setManifestid(588822, "2725349922684911919", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Assassins Creed 2 - Mac (AppID: 33362)
addappid(33362)
addappid(33362, 1, "5bd43a8931cfe3b851ef2e72884997aa81605878c95f67c75275a017779d4866") -- Assassins Creed 2 - Mac - assassins creed 2 mac content
setManifestid(33362, "4758459184864595027", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(33360) -- Assassins Creed II - CD Key
addappid(33361) -- Assassins Creed II - Deluxe CD Key
addappid(48173) -- Assassins Creed II - Unlockable Content Key
