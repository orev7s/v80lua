-- Made By @F1uxin
-- MAIN APPLICATION
addappid(2404880) -- Car Dealer Simulator

-- MAIN APP DEPOTS
addappid(2404881, 1, "dd3322cbddd81741e4bd8f3d9d08fbe6ff172e3f5c36fec42e215f6661d3ea4f") -- Main Game Content (Windows Content)
setManifestid(2404881, "291469732890498508", 0)
