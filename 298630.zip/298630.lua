-- Made by f1uxin, please read the read me TXT file.
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship
addappid(298630) -- The Escapists

-- MAIN APP DEPOTS
addappid(298631, 1, "1d951ecd65bb56f9ac888d6ed015d2d558b2218346eb1485de6c6aca1a07bbef") -- The Escapists Content
setManifestid(298631, "3705448727285462895", 0)
addappid(298632, 1, "7396f73eac3a5f853e36cfb0041ac6ff26a835fe0a567b808521adf5029f58cc") -- The Escapists Linux Content
setManifestid(298632, "7521584516501617485", 0)
addappid(298633, 1, "b319a3ad78dabe07a922c9392fb68d528c4bf4d01852c9369434920ff1eeb15b") -- The Escapists Mac Content
setManifestid(298633, "1012100071233032982", 0)

-- DLCS WITH DEDICATED DEPOTS
-- The Escapists - Fhurst Peak Correctional Facility (AppID: 349310)
addappid(349310)
addappid(349310, 1, "8e29ac1144ff441c25724d10863fe688c108476c9163c9f49bb14d3040585d06") -- The Escapists - Fhurst Peak Correctional Facility - The Escapists - Fhurst Peak Correctional Facility (349310) Depot
setManifestid(349310, "3685392368747036082", 0)

-- The Escapists - Alcatraz (AppID: 349350)
addappid(349350)
addappid(349350, 1, "996e19c72e4b20610d25e52b076ac0321f0cdb204614fd68066a15ca80b55527") -- The Escapists - Alcatraz - The Escapists - Alcatraz (349350) Depot
setManifestid(349350, "3970956800506777810", 0)

-- The Escapists - Escape Team (AppID: 376700)
addappid(376700)
addappid(376700, 1, "169c06e841e445c6b833f607ac76d4a6ab7b57fa27d6fdbbd13bd07af2e2ab46") -- The Escapists - Escape Team - The Escapists - Escape Team (376700) Depot
setManifestid(376700, "312259889671056474", 0)

-- The Escapists - Duct Tapes are Forever (AppID: 408730)
addappid(408730)
addappid(408730, 1, "892a6122b6b21edf0bedd26e0eda1ac7236c4097fb4480c0b596f7a7097546a6") -- The Escapists - Duct Tapes are Forever - The Escapists - Duct Tapes are Forever (408730) Depot
setManifestid(408730, "4112014082010754446", 0)

-- The Escapists - Santas Sweatshop (AppID: 412990)
addappid(412990)
addappid(412990, 1, "47ff1b671257eb43cbb08cca679d4627099b13dc15a66539bd65fff80aa1fb37") -- The Escapists - Santas Sweatshop - The Escapists - Santa's Sweatshop (412990) Depot
setManifestid(412990, "755713797482290020", 0)
