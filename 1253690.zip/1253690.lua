-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(1253690) -- Teke Teke - テケテケ

-- MAIN APP DEPOTS
addappid(1253691, 1, "749d95f6bb06981f740138285e0c4fef787fc22d3c9645008ccc4c90cd2f9c9b") -- Teke Teke - テケテケ Content
setManifestid(1253691, "1828792389967898454", 0)
