-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(2101960)
addtoken(2101960, "2704160378812211529")
addappid(2101961, 1, "7f2c42a3171b51a0ea7463a8acbf143d1341f27c8e7babad3fa9eeef66f133eb")
setManifestid(2101961, "3456900193582232476", 24464731047)
addappid(2101962, 1, "d3f3ea72d940025825a5859f4747ec70d37c6b3df38f8ec038c1c70911d4e0ac") 
setManifestid(2101962, "2694394940284212263", 22682915851)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") 
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf")
setManifestid(229000, "4622705914179893434", 242743889)