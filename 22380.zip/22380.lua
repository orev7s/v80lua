-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(22380) -- Fallout: New Vegas

-- MAIN APP DEPOTS
addappid(22393, 1, "89906a2ccfd74e276ed8b836d6be1267ca7fa05709f557a421136aa8293eff56") -- FalloutNV_Bin
setManifestid(22393, "8227935753987096201", 0)
addappid(22381, 1, "cd475383b32cb0055c08242d5763a28aca80d1cbf045b269f24ae042e89dc2d7") -- FalloutNV_Base
setManifestid(22381, "8327177303444281069", 0)
addappid(22387, 1, "b5c70b33a3eff20fab8e75116d229c67ea408dbbca69cc3bb587d6fa8d84ecf3") -- Fallout New Vegas German NoGore
setManifestid(22387, "3818383330290936329", 0)
addappid(22382, 1, "2d796b58fa6f1f9b028825154ca1a9bd2dbff242545dac86ec8511e900d161d7") -- Fallout New Vegas English
setManifestid(22382, "1869121858616960493", 0)
addappid(22383, 1, "75128c281ae3cb6cb0bc7bf86da45dea7e9dfe6098bd6fe7f6c6da6de120cc75") -- Fallout New Vegas French
setManifestid(22383, "4908451661450393672", 0)
addappid(22384, 1, "434a35920c90e3e871ed5d24f0d57f1f8632cc1f4656e4c09e5a7fd4e7ee9cd6") -- Fallout New Vegas Italian
setManifestid(22384, "3154332352227781227", 0)
addappid(22385, 1, "ad0401193707f7c4b033c05bdcc4847759096ef83550a919a1dc55a3aa2689ae") -- Fallout New Vegas German
setManifestid(22385, "1254217014717060816", 0)
addappid(22386, 1, "48a3041470c08682b168808d468f75d2205e48445e30219816671687a8e2004e") -- Fallout New Vegas Spanish
setManifestid(22386, "8761564382862573338", 0)
addappid(22461, 1, "715e6d6a48bbec863b544f02620ec237b58c629393de3c89cd06ab1f7185a189") -- Fallout New Vegas French CaravanPack
setManifestid(22461, "5904002363925640566", 0)
addappid(22462, 1, "c5df4dd61e97547c88d55b64a94c3e31daaf2dbd6cf37e896726c83451300eb0") -- Fallout New Vegas Italian CaravanPack
setManifestid(22462, "4866927589704494894", 0)
addappid(22463, 1, "0a31656e5cbec09662724a0ccc794d62ddfd229404f57de8d8005e190bd34e8e") -- Fallout New Vegas German CaravanPack
setManifestid(22463, "2606574133782217517", 0)
addappid(22464, 1, "9096370be01d17fef5c317cfa6f115b57553915ca7c823af6539856645dda719") -- Fallout New Vegas Spanish CaravanPack
setManifestid(22464, "3566069208831073571", 0)
addappid(22466, 1, "74f97d3b550a83b5d675b855f66bab5602e5a79a8734da5d756d3ffeb202f64d") -- Fallout New Vegas French ClassicPack
setManifestid(22466, "1510770969128417196", 0)
addappid(22467, 1, "7d3447ad35f425c5736cc139dc25b30256fa118f202255a353fd0ac6095a9e89") -- Fallout New Vegas Italian ClassicPack
setManifestid(22467, "3538923246242403538", 0)
addappid(22468, 1, "a7f134560d67bec74bf05e83d9431f90b53384045a5455a24cb0daf38b3139ae") -- Fallout New Vegas German ClassicPack
setManifestid(22468, "4054403017816647337", 0)
addappid(22469, 1, "372e99a3651a6e94455ec47269fd5ad66608202ce5a66d8002637777211a7c76") -- Fallout New Vegas Spanish ClassicPack
setManifestid(22469, "2754265232492844016", 0)
addappid(22471, 1, "236f4c81fd2126401b552f0696096c2b91a1f374a39ab3c1aa6358b430201491") -- Fallout New Vegas French MercenaryPack
setManifestid(22471, "7317844635982217214", 0)
addappid(22472, 1, "77d7bcca0d0334ca6996e2655ef34dd42a1c8ad3c4db30d846516e7d9cec5650") -- Fallout New Vegas Italian MercenaryPack
setManifestid(22472, "1132709297122659322", 0)
addappid(22473, 1, "fa8df8e5f58dafb1d8dd2a01cd6e2483b52fae6e97b2e052da688ddb7e18f09c") -- Fallout New Vegas German MercenaryPack
setManifestid(22473, "6438309698058593440", 0)
addappid(22474, 1, "9552cca5dacba14521e41a718cd4fac6a23d7dc02cbb83888105749bd6641747") -- Fallout New Vegas Spanish MercenaryPack
setManifestid(22474, "4369356280283756406", 0)
addappid(22476, 1, "720342929c87baba4a85288d6edda2c4bb3d2ad5ff8cd6797e89fecbd84f0ca8") -- Fallout New Vegas French TribalPack
setManifestid(22476, "4281683315724973816", 0)
addappid(22477, 1, "89520fa2e9cd54a2e5abce7c3792746e9b0fbba8b3cdb415bbed2242b9478f32") -- Fallout New Vegas Italian TribalPack
setManifestid(22477, "7147209989063233162", 0)
addappid(22478, 1, "7f5d209ecb84e486a3af31970da276d8b99169958406de5ef112c1f93a217727") -- Fallout New Vegas German TribalPack
setManifestid(22478, "6144308732856631726", 0)
addappid(22479, 1, "13c7190f4be9631c12ce01da049fc311b050ef4a9a0f9d6138577f9d4d36a935") -- Fallout New Vegas Spanish TribalPack
setManifestid(22479, "5039947182700550471", 0)
addappid(22493, 1, "d1e9d45635bac03bab00d0f21e102e68d19fe1d7fb5b8efe1f97c465702a31f2") -- Fallout New Vegas English
setManifestid(22493, "2502952557192596705", 0)
addappid(22494, 1, "3f1282a3b7b757873abd8b31efc7e18a9c280ee934cbc608780c501776ba96ef") -- Fallout New Vegas Polish
setManifestid(22494, "172761448805198342", 0)
addappid(22495, 1, "e0bdf67491de1e581c521d4a973c94548c6a1476d5b9284cd008dbdd398fb37c") -- Fallout New Vegas Czech
setManifestid(22495, "3899563573656223062", 0)
addappid(22496, 1, "b77f71428f243b3229f931191ab72d860f1b18425582b3cb78ebf328c5fd6a73") -- Fallout New Vegas Russian
setManifestid(22496, "2854660838749520858", 0)
addappid(72702, 1, "8793398558a68feecce561d6e436d29a3b0e35ac56e73255fffb31afaccb798b") -- Fallout New Vegas Polish CaravanPack
setManifestid(72702, "218001916733409543", 0)
addappid(72703, 1, "f90e63c33b303af852cc74146623864ee5b322eceddb4724c2fc830bbe22f413") -- Fallout New Vegas Czech CaravanPack
setManifestid(72703, "8704668556634681206", 0)
addappid(72704, 1, "b2b1ba6b1db4dec2bf21483d339cc10179f7c18cc5ccea0fa340af680dd37eeb") -- Fallout New Vegas Russian CaravanPack
setManifestid(72704, "5027314936807090238", 0)
addappid(72706, 1, "785fa36d1aa58ebc5e8518938432f32518a22229d0f4f2355ebfb39a03e7490f") -- Fallout New Vegas Polish ClassicPack
setManifestid(72706, "4769162033996668390", 0)
addappid(72707, 1, "248b35386a772a915b02dcc3bb2d484907019231c6304d4bce77951f64faf336") -- Fallout New Vegas Czech ClassicPack
setManifestid(72707, "2475543823682564198", 0)
addappid(72708, 1, "efef498f39390f0476f4da7d6adebd88a3cbe2f111616792722d3d14fc6534c1") -- Fallout New Vegas Russian ClassicPack
setManifestid(72708, "2833359475025167693", 0)
addappid(72710, 1, "fd7ed03d0f6e6965b3fd30c49b7854a798a6562d898f34edb208f01e15ccd1f2") -- Fallout New Vegas Polish MercenaryPack
setManifestid(72710, "4444319566282062264", 0)
addappid(72711, 1, "b062729ac6f1d229dc036823575b74b7a262670f0b0e6d792200700f17b08a89") -- Fallout New Vegas Czech MercenaryPack
setManifestid(72711, "5188458997640746773", 0)
addappid(72712, 1, "a8348d71f8696612b2a9c9a2c54be6699de424cd6c74f651e089a54334eadcfd") -- Fallout New Vegas Russian MercenaryPack
setManifestid(72712, "851361898012512096", 0)
addappid(72714, 1, "f7407b1b98a8c024b7d169406efdc87fd6c615de133750db77c4f5fba2310894") -- Fallout New Vegas Polish TribalPack
setManifestid(72714, "2877250838608166760", 0)
addappid(72715, 1, "dcf9186da62d3d6fd78ff7cb16c63f80c2878c6807f69ad6b6b64beb7fbced65") -- Fallout New Vegas Czech TribalPack
setManifestid(72715, "7383312129410005891", 0)
addappid(72716, 1, "9a9075240c133375247bade717df5903aee68278c5f8fe5a1354747e294c22fe") -- Fallout New Vegas Russian TribalPack
setManifestid(72716, "6186740497873431344", 0)
addappid(72732, 1, "4ec8cc64e5643b45a9c1e2e66b28ff702633c3a367b4a2c204550cf8ca72f0d1") -- Fallout New Vegas English DLC1
setManifestid(72732, "4131381354636064588", 0)
addappid(72733, 1, "39ab2790e703286c5232e1d9fbe65b3782d405ad560ddace5f22da6430bc2e02") -- Fallout New Vegas French DLC1
setManifestid(72733, "4152591146727673335", 0)
addappid(72734, 1, "cc62bffbe340b091f2d23491dd4ddd28f361d7f59063adf8edf8f91ae01c896f") -- Fallout New Vegas Italian DLC1
setManifestid(72734, "3274733605889166985", 0)
addappid(72735, 1, "268db77712725105c67132142113dd3c8e6548f52f5eae7f3abd5a30bde32bb9") -- Fallout New Vegas German DLC1
setManifestid(72735, "8677900210824532806", 0)
addappid(72736, 1, "4733b367dbaeb48f94ec9bf424c2bc6f645bf2d93ae1389f4ced7bf38626fc41") -- Fallout New Vegas Spanish DLC1
setManifestid(72736, "7999052110491368290", 0)
addappid(72742, 1, "55df3ea4deaf2fd9be3812522cf229514cee7c8508e9955a242151ce9e4d3160") -- Fallout New Vegas English DLC2
setManifestid(72742, "4517089570337326424", 0)
addappid(72743, 1, "6febb595197d13fd0e61a7d7224372b491a893042a7f9e839492936dfbd8ecd3") -- Fallout New Vegas French DLC2
setManifestid(72743, "5251151026503673295", 0)
addappid(72744, 1, "86168e82762ade1c0d49d1e7ba1379ea30fedb786240339a0f28cbaee0efb3e4") -- Fallout New Vegas Italian DLC2
setManifestid(72744, "1305099132607763646", 0)
addappid(72745, 1, "a424dd72a830a08a5fce0a3ce26c359f34914fe3e6b526e7012cb0e26b27f3dc") -- Fallout New Vegas German DLC2
setManifestid(72745, "1687258286902847069", 0)
addappid(72746, 1, "2d697bce916edfe94201b4a274897759bdde4b1227c02126f858e96f723ebbc9") -- Fallout New Vegas Spanish DLC2
setManifestid(72746, "8215456132420404126", 0)
addappid(72751, 1, "1fe48d0caa9e8bfafd0a139b9d554778fb293231606714dcca09f0503832dedc") -- Fallout New Vegas English DLC3
setManifestid(72751, "1624841217294494503", 0)
addappid(72752, 1, "8247db1ae1bf38cca5a60daa980d8458d8bf72374cc6e3fead49e9485d50aa53") -- Fallout New Vegas French DLC3
setManifestid(72752, "7666384873706904799", 0)
addappid(72753, 1, "cf4ad9dc49dbf41b5af0dea87013467adf8fb5ec4e0e1ac74379cad5b5e1d257") -- Fallout New Vegas Italian DLC3
setManifestid(72753, "8226671937990042355", 0)
addappid(72754, 1, "c6650ab15edb30cddc86fa07f03fbc0e7ffc7b0662d264b81db33aa340543690") -- Fallout New Vegas German DLC3
setManifestid(72754, "6027990557909752884", 0)
addappid(72755, 1, "6502388d13e40487e0a2ffadc639ed9a9027d31ba0e6281ac9d61ffa47ec7bbd") -- Fallout New Vegas Spanish DLC3
setManifestid(72755, "2158729683026608055", 0)
addappid(72761, 1, "19f003199bccdeef63c38e7f3cb6d1d09cd0cc065d30e6c12d71074ad7b66bd2") -- Fallout New Vegas English DLC4
setManifestid(72761, "5717050455382180241", 0)
addappid(72762, 1, "ea9a9a1a70df0989e6d0017eea026e4a4d867caaeb2abefb14974f150222036f") -- Fallout New Vegas French DLC4
setManifestid(72762, "7641337957345960590", 0)
addappid(72763, 1, "ded10ebe02d7d4905248baec5ea1a6071a24ed91819d9219c13061f000979899") -- Fallout New Vegas Italian DLC4
setManifestid(72763, "8371948547095099581", 0)
addappid(72764, 1, "71562e7f368b3d46b351b879204a750703da48ac0184ab7eec2501e69f9af107") -- Fallout New Vegas German DLC4
setManifestid(72764, "4409623748397178295", 0)
addappid(72765, 1, "e9a3d37a39109313c436f779027a564e0b8ec6672c021b39a4e826d1be9bab0b") -- Fallout New Vegas Spanish DLC4
setManifestid(72765, "4696146338252983690", 0)
addappid(72841, 1, "2871acee28140d256d44e651c3502baa2afc4ef50cbd02f1027c07ea3c409072") -- Fallout New Vegas English DLC5
setManifestid(72841, "7404324045800590955", 0)
addappid(72842, 1, "64defef2134518527b18985bfd21f999e574a5fc2edbe51c5ed6c9147d8a7a5b") -- Fallout New Vegas French DLC5
setManifestid(72842, "1434764155323580833", 0)
addappid(72843, 1, "8d7ed689ee27d75452e8d16761d68b5a8ca734d818b2134210f94b619266024f") -- Fallout New Vegas Italian DLC5
setManifestid(72843, "7904639580398839628", 0)
addappid(72844, 1, "4e4e0e52c1b1c4ada00e734528d6d5b58d0d35cd4793b0500977c4d9cca02802") -- Fallout New Vegas German DLC5
setManifestid(72844, "6599444621768713933", 0)
addappid(72845, 1, "2376c79a868ed20778a2676617f82651d78937669b23a4b67cd17b3d7ae5df2d") -- Fallout New Vegas Spanish DLC5
setManifestid(72845, "7165809099252444575", 0)

-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Fallout New Vegas CaravanPack (AppID: 22460)
addappid(22460)
addappid(22460, 1, "00e0b66517ddabddbc468b1fa3864d7823c4254d6dd73e0a538f3e9658867bfe") -- Fallout New Vegas CaravanPack - Fallout New Vegas CaravanPack
setManifestid(22460, "7297705168696770122", 0)

-- Fallout New Vegas ClassicPack (AppID: 22465)
addappid(22465)
addappid(22465, 1, "44a0925e44d6fdd2ea6fd27f6d7d789b8cc85b4f931c88e0b92a730d3c939258") -- Fallout New Vegas ClassicPack - Fallout New Vegas ClassicPack
setManifestid(22465, "1831628242600766040", 0)

-- Fallout New Vegas Couriers Stash (AppID: 22470)
addappid(22470)
addappid(22470, 1, "9b7f69d1e722488fa7e97161cc103396f45c9c1f4aab698d79b76ace413d388b") -- Fallout New Vegas Couriers Stash - Fallout New Vegas MercenaryPack
setManifestid(22470, "3345471689591269370", 0)

-- Fallout New Vegas TribalPack (AppID: 22475)
addappid(22475)
addappid(22475, 1, "33fe497f51187957bb00de95f094b4e4788e744c478d58a48533aea9272c735f") -- Fallout New Vegas TribalPack - Fallout New Vegas TribalPack
setManifestid(22475, "2098145519916214977", 0)

-- Fallout New Vegas Dead Money (AppID: 72730)
addappid(72730)
addappid(72731, 1, "c55a8372d51c90c5c08d7a4d33f877dfaa42fc07647ac6645ef65271d061897f") -- Fallout New Vegas Dead Money - FNVDLC01 Base
setManifestid(72731, "8907026380183228960", 0)

-- Fallout New Vegas Honest Hearts (AppID: 72740)
addappid(72740)
addappid(72740, 1, "c48f8f6b86b390e0e45fca2b23115c0d97c85ba843bcb6e036601f9ec4b663cc") -- Fallout New Vegas Honest Hearts - Fallout New Vegas Honest Hearts DLC
setManifestid(72740, "4489420091293378368", 0)

-- Fallout New Vegas Old World Blues (AppID: 72750)
addappid(72750)
addappid(72750, 1, "0734ae858b1b7316d6db4273c27dda530696aa51a4f29917fb11240671da8656") -- Fallout New Vegas Old World Blues - Fallout New Vegas Old World Blues
setManifestid(72750, "3995530604401716079", 0)

-- Fallout New Vegas Lonesome Road DLC (AppID: 72760)
addappid(72760)
addappid(72760, 1, "853a5cdad970f827bee0b5097f09c74a6f0ae7debdf3bda4a1abc81d2442431a") -- Fallout New Vegas Lonesome Road DLC - Fallout New Vegas DLC4
setManifestid(72760, "4819448886064400670", 0)

-- Fallout New Vegas Gun Runners Arsenal (AppID: 72840)
addappid(72840)
addappid(72840, 1, "1107e230761457d87f553468c15f2c3db0904433af9c165f2ccc3fca2d9a25e0") -- Fallout New Vegas Gun Runners Arsenal - Fallout New Vegas DLC5
setManifestid(72840, "6228338984629967746", 0)

-- DLCS EXCLUDED (NO DEPOT KEYS, NO DEDICATED DEPOTS)
-- addappid(461160) -- Fallout New Vegas - Soundtrack (no keys available)
