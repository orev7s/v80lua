addappid(1359980)
addappid(1359981,0,"4407b8f39b12b4d47ebb635bc862313dc9e3f5afe62b8cbbd0314223eead3856")
setManifestid(1359981,"5196373497457366568")
addappid(1359982)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]