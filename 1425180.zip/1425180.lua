-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(1425180) -- Vessels Of Decay

-- MAIN APP DEPOTS
addappid(1425181, 1, "4777e9f37c831bd644d2310265434ec3f91e0790244a4273771453e8ff54f7db") -- Depot 1425181
setManifestid(1425181, "1886983699537982397", 0)
