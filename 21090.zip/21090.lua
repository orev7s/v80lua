-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(21090) -- F.E.A.R.

-- MAIN APP DEPOTS
addappid(21091, 1, "1df364cb738cb58b23727f9f7e40884522090c881afb5915e7315e779f9b9472") -- fear content
setManifestid(21091, "8127606915127768126", 0)
