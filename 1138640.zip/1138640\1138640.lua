addappid(1138640)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1138641,0,"3595306a899c5b04a6dccc4ce52479d7e971074b71b2e8a5c187f24fa229945f")
setManifestid(1138641,"3300151411924338232")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]