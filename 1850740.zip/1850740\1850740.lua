addappid(1850740)
addappid(1850741, 1, "a830d518fb69395dfac8536575b35f141dc0ccb74f84bb08dad20556b7050c1e")
setManifestid(1850741, "4300620274148410482", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]