-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(1346840)
addappid(1346841,0,"97c6131497053c1bb5d67ba18ab299d620ed9102c349d33a39a88f631ffbea41")
setManifestid(1346841,"4785986818608701145")
addappid(1346842,0,"639e6998b8fd3c6504cc09f16dc96c068665e905632e4045daa48aae2f01c32c")
setManifestid(1346842,"8498148427209618157")