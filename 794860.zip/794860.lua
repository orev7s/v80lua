-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(794860) -- eSail Sailing Simulator

-- MAIN APP DEPOTS
addappid(794861, 1, "35a0131cbd83b246f13a3abe94f1b3b58934ac648918f770493d7eda3f9c995d") -- eSail Windows
setManifestid(794861, "5422382513366781777", 0)
addappid(794863, 1, "8a9a9941ba0c8bc7af420c385ae2305a89dcc8fd3559a664c2ab082a8cab6001") -- eSail Mac
setManifestid(794863, "6959571839235260485", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1121600) -- eSail Man Overboard (MOB)
addappid(1853470) -- eSail Pro
