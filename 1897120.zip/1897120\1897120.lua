addappid(1897120)
addappid(1897121,0,"b55056806cd1d9ee4f5b9cb6760a7488028681e4c9e7894ea3971f7ce3589f17")
setManifestid(1897121,"3787560285886358276")
addappid(1897122,0,"c90aab7a426acef9a6d7713d10692a2777f7d7f2646396f27cecc1e8ae2fbeff")
setManifestid(1897122,"2335594394506823178")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]