-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(32500) -- STAR WARS™: The Force Unleashed™ II

-- MAIN APP DEPOTS
addappid(32501, 1, "35b1b5fdcf3803d161fec434ad7aa9463f7cad667ad4086f9b6c2a5c865c14c9") -- STFU2 Content
setManifestid(32501, "7046856841289178616", 0)
addappid(32502, 1, "2bf1ebfe91d219e0a96890ce46dd2d8af98e02badf5a5de304bbe3ed8fe21d59") -- Star Wars The Force Unleashed 2 Russian
setManifestid(32502, "2422242795659314641", 0)
addappid(32503, 1, "c7e1b842997f64b8ebf68d26d3c88ae266b370fca8cc4e0973e0183511e3dc80") -- Star Wars The Force Unleashed 2 Polish
setManifestid(32503, "7278927256669937519", 0)

-- SHARED DEPOTS (from other apps)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
setManifestid(228982, "6413394087650432851", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- .NET 3.5 Redist (Shared from App 228980)
setManifestid(229000, "4622705914179893434", 0)
