addappid(1718870)
addappid(1718871,0,"f16482d24a5c12c5db47dcd5072957a40d57a63f89a7d46dde0360f092d68d16")
setManifestid(1718871,"3544118826082821448")
addappid(1718874,0,"a86c65b9f38edda4bf5645431a5c72d9d0a93677f9359379ddf8b8034f28be97")
setManifestid(1718874,"1273812378941765483")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]