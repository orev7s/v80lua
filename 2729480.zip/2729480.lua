-- Made By @F1uxin
-- MAIN APPLICATION
addappid(2729480) -- NightClub Simulator

-- MAIN APP DEPOTS
addappid(2729481, 1, "a888843dc7baaa68b8424ca0216fce2c36531da9f8266b9dbd656f37cf619746") -- Main Game Content (Windows Content)
setManifestid(2729481, "5384826008061036737", 0)
