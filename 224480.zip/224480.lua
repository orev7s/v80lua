-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(224480) -- Octodad: Dadliest Catch

-- MAIN APP DEPOTS
addappid(224484, 1, "57a0ab06475197f953f5fbec310f366741442aadbb562181b2cb89e85b2dd8c7") -- Octodad Content Linux
setManifestid(224484, "4253549932522289047", 0)
addappid(224482, 1, "63e1888aaccd1bd13a2d01fd28b08d3a8c0e9e80968521dbe4ef45fdae3632a0") -- Octodad Content OSX
setManifestid(224482, "2782582796488406357", 0)
addappid(224481, 1, "0c445f92664319a109907a326398699a92ae30a44c196554a7667f54088b463b") -- Octodad Content Windows
setManifestid(224481, "8491811867326479954", 0)
addappid(224483, 1, "7d5fa7d187fa069a17bc3b7759270c4f1e6b8c1409a0bc26f47089d49f02df63") -- Main Octodad Shared Content
setManifestid(224483, "542502232443733342", 0)
addappid(296170, 1, "28354c9b84b75dfd88b68705a69e7f3c4aad351080e1b068747996b253e77159") -- Octodad: Dadliest Catch - Soundtrack (296170) Depot
setManifestid(296170, "1366459023872831277", 0)

-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Octodad Dadliest Catch - Soundtrack (AppID: 296170)
addappid(296170)
addappid(296171, 1, "deebf74d0bd9cb13adcf4e14f54d2bb87d41bd19f9c0b6289473b1fa103335a6") -- Octodad Dadliest Catch - Soundtrack - Main Content
setManifestid(296171, "3502651802867608616", 0)
addappid(296172, 1, "455b5f685d31f70389c930e695c8a3d5a0f5379ebcec77e6283f6597398fd2d4") -- Octodad Dadliest Catch - Soundtrack - Main Content
setManifestid(296172, "1117392335375617943", 0)
