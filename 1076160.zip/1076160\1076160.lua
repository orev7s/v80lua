addappid(1076160)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229002)
setManifestid(229002,"7260605429366465749")
addappid(229007)
setManifestid(229007,"4477590687906973371")
addappid(1076161,0,"7382251e4b0b939ed609909546aa5b1f2eba470796291b9b7a586fc7be38612d")
setManifestid(1076161,"6357109347403495907")
addappid(1076162,0,"180fe6de8201be6c1ab969105660e0ecd48339b08119cbf85b0dd48096faee67")
setManifestid(1076162,"650631900831656841")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]