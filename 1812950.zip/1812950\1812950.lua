addappid(1812950)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1812955,0,"0c84ccdf1f4b74a2e1b5c0e8501d8b4d56dd1a25eef2aad96aabdff81634620a")
setManifestid(1812955,"3914985156840623043")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]