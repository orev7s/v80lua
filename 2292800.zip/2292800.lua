-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(2292800) -- Blacksmith Master

-- MAIN APP DEPOTS
addappid(2292801, 1, "eabaeaf0e86b550dc3dfb73dbfc87bf0ef141f3279e04f2e41ed631dc95c8f08") -- Depot 2292801
setManifestid(2292801, "4328738244469071757", 0)
addappid(2292802, 1, "7a289474a74fc72804ca64ca9f591d55f818de4a9735a0d632cc35d703d75ed7") -- Depot 2292802
setManifestid(2292802, "5881965689653718729", 0)
addappid(2292803, 1, "a87e91706df691b1d3a12b0b4d30d275ce14e2cbe02eb5d8af7ad8789552776c") -- Depot 2292803
setManifestid(2292803, "6839294000487001199", 0)
