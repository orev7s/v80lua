-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(1207650)

addappid(1207651, 1, "e962f7f3acaa1caae21e3a4b34d2c88979477e1e5c6343007e2b688814031f1b")
setManifestid(1207651, "2271015952219600344", 0)
addappid(1207652, 1, "eec4a5f35bdeae4e24e087931ce32ca88abc8136a7f68f3fcf2c207145696479")
setManifestid(1207652, "7463067820562131265", 0)

addappid(1252140)
addappid(1252141, 1, "f06a5be907cd04be8e13a18c3bf99ffee05e8dc7c4caed8fb70467f4a9417097")
setManifestid(1252141, "838627558293275080", 0)
addappid(1252142, 1, "2a4738905f8a1927a46867f51b871655b75049b3a068729766ea4848598ab5d9")
setManifestid(1252142, "8825148148100787890", 0)

addappid(2352340)
addappid(2435940)
addappid(2794000)
