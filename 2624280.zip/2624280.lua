-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @F1uxin on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!)

-- MAIN APPLICATION
addappid(2624280) -- 420BLAZEIT2: GAME OF THE YEAR -=Dank Dreams and Goated Memes=- [#wow/11 Like and Subscribe] Poggerz Edition

-- MAIN APP DEPOTS
addappid(2624281, 1, "14e69537f39dc7ed1d11d71d8a4c1e4abd47974f686cbb00f2ca617e8d0654bd") -- Main Game Content (Windows Content)
setManifestid(2624281, "3495383802610127588", 0)
