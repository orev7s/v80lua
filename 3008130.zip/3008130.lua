-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(3008130)
addappid(3592041,0,"32f10ad2de76688dc0970aebede422b2921593489edc03e6e1e90d447aeb3890")
setManifestid(3592041,"1168744117357550454")
addappid(3008139,0,"9ca49a179625bb0a94c6cef85afa175dbf6f70f640eea01565cf29ee9b89b1a4")
setManifestid(3008139,"744044841696959165")