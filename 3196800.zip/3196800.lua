-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(3196800) -- Barman Simulator

-- MAIN APP DEPOTS
addappid(3196801, 1, "ffc840c1e225c5b4a5e1b7f6d92182c9a2f96ba0ef6dfe74bc72304037163823") -- Depot 3196801
setManifestid(3196801, "6129948220647230629", 0)
