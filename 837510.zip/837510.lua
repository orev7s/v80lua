-- Made by f1uxin, read the (README) file if you want to see more info, and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username : "f1uxin", nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(837510)
addappid(837512,0,"31b95e27dd7bd4bc564c67f9de8b278a309430afe7f353634d7911a19d2f69f0")
--setManifestid(837512,"23702992719154989")
addappid(837513,0,"bb6f61aa7254b90e546e44285095ee66cb27fa5c6cf3445f41385a6ab34e8329")
--setManifestid(837513,"890277827220228773")