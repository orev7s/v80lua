addappid(1150590)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"5087715316087945828")
addappid(229005)
setManifestid(229005,"7992454656023763365")
addappid(1150591,0,"7e64949511fb7797e94c062b1483e46e4b941ad39acb357e5896759494d81b52")
setManifestid(1150591,"4993293984609253105")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]