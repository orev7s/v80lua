addappid(1047440)
addappid(228987)
setManifestid(228987,"4302102680580581867")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1047441,0,"42c300ed85d7618f3fa71ad5ba690b96a67971de91e986d9e920527d400ec700")
setManifestid(1047441,"8193004425746969958")
addappid(1055670,0,"8fc5e53493b08c7ffb83539a743a7c012b87566802eb320fc37fc43c7dae751a")
setManifestid(1055670,"4108107192910403638")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]