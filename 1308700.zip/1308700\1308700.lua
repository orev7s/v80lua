addappid(1308700)
addappid(1308701,0,"8e2cd6a1a36611d2a178edb5ddef89704391742fef5c9384d80a4c93029fc61e")
setManifestid(1308701,"42321664483973436")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]