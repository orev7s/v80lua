addappid(1153410)
addappid(1153411,0,"aae6e034473725f27603fc003f2520e4df8111c1433317b84a92e8bb8fb64913")
setManifestid(1153411,"7138815302572124104")




--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]