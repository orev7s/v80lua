addappid(2089980)
addappid(2089981, 1, "5373f2e2eddeefa6ec7bb22bd940c35cc36e8b5ecab7f222c7a6bc0abecbd38e")
setManifestid(2089981, "2155690818754053918", 0)