addappid(949960)
addappid(949961, 1, "1cc80c1eb9a8cb6442e83a5ba0b19e35e7e3bda2cdf1a739efbeaac1b211e4fd")
setManifestid(949961, "968335889940424438", 0)