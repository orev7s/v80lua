-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(847370)
addappid(847371, 1, "d05c427fd369235384c4b3d6de5431f6103a8cb8dbc4518c43d5fd059dd46d8b")
setManifestid(847371, "2745499824144496649", 0)