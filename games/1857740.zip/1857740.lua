addappid(1857740)
addappid(1857741,0,"1b6b6376286e53470ca940fd111f876f883e516565d137e2f6a449ee0efdfae8")
setManifestid(1857741,"2757532284865098251")





--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]