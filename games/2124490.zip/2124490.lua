-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(2124490)
addappid(2124491, 1, "1a14569bdc22983489a37bb81ed420c6230f43e84548d0ec0d4a3e9687861955")
setManifestid(2124491, "6030786832332563114", 0)