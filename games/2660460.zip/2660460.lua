addappid(2660460)
addappid(2660461,0,"20759e43cbde1f884d0690ee03b21326da837eb3937e6c811d57f5669dc3b9d2")
setManifestid(2660461,"8447217017621019590")




--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]