addappid(711990)
addappid(711991, 1, "43e23dc10ff4a012a2cf4a0d6c6f05aec79fa655adabf5ce391bb90cafaf1e5a")
setManifestid(711991, "7480935112328424176", 0)