addappid(502400)
addappid(502401, 1, "d11f274a337cdc28d9dd9f5da81ee4bafe5abfa6a64b6eaa1209ebff8942bbe7")
setManifestid(502401, "5810241414216040799", 0)