-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(232770)
addappid(232771,0,"0b3f5b747a013904638183986855f8b765d1b10511e01b47ab925bfde5e8e53f")
setManifestid(232771,"4856268982824038014")
addappid(232772,0,"b5903d85c4944c3fabf3e8dde5605f844dd40e486ef7e470469b8aed1e70ded2")
setManifestid(232772,"7418282084983807069")
addappid(232773,0,"45dc820b369b0449f1be5fe2eae2ba13e602422a26d9f2809a0c0dea00000ebb")
setManifestid(232773,"1739770070415342406")