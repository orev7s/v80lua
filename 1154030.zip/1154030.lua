-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(1154030) -- Titan Quest II
-- MAIN APP DEPOTS
addappid(1154031, 1, "e4c24aa5ff3a15fba8dcb2762211078a3f284a840b9514a64e6694e2acbb33b3") -- Depot 1154031
setManifestid(1154031, "4773618536299084955", 24026735046)
addappid(1154032, 1, "43500c93da407fa7209d086b870b5e21bf2fe23eb5b4222593992edd340ca26e") -- Depot 1154032
setManifestid(1154032, "8943718197483663397", 581991195)
addappid(1154033, 1, "fd8d7e7db90c144288acda1e77897ffd3ecc1acc26408079c1c8f54c095d3f49") -- Depot 1154033
setManifestid(1154033, "5675640506793085519", 25736176321)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)