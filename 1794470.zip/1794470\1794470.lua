addappid(1794470)
addappid(1794471,0,"a7e5fd06c7ec54dabf87b3070a0c6d78e76be65dbc44c376cf9c67b38c1f3dff")
setManifestid(1794471,"5411055194289173329")
addappid(1794472,0,"f7ad1c6021a1ed8741d58f122e8a1b2df45a47cae95efb3f3aa71c0bfcf9a295")
setManifestid(1794472,"398768327293509753")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]