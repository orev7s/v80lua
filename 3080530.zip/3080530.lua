-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3080530)
addappid(3080531,0,"beecb048a770e2f5b2ac449a00614a67ff8e0dddcefccb46ecaf516407fe5b52")
setManifestid(3080531,"3812473782948141496")