-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(250260) -- Jazzpunk: Director's Cut

-- MAIN APP DEPOTS
addappid(250261, 1, "e41ee24f8fe4f6752e6f9031a9bff87d60bdea0b2b140f184c214bfd2e97d737") -- Jazz Punk Content
setManifestid(250261, "5699221551175979522", 0)
addappid(250262, 1, "4eb06dd4dbb5fadf237b93f9018e961a33cbc9db15f8dd8a8a369db46978d8cc") -- Jazzpunk Depot Linux
setManifestid(250262, "4380595589446190236", 0)
addappid(250263, 1, "cb68f02e2a582d0620b455632ca09e7aa9293bd4446db73ce2592e2bc00ad901") -- Jazzpunk Depot Mac
setManifestid(250263, "3322491401207139581", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Jazzpunk Flavour Nexus (AppID: 649410)
addappid(649410)
addappid(250264, 1, "37340d89f31079be84e9dc9b5e58e1b774c4dbedc91a4949a848a4b00fd32d9b") -- Jazzpunk Flavour Nexus - Jazzpunk Depot Windows - Flavour Nexus
setManifestid(250264, "2134173645821750339", 0)
addappid(649410, 1, "1c83509694eae6538f38282b9cd40457ab5447bc4318d8ef5ef37507e9bf0f69") -- Jazzpunk Flavour Nexus - Jazzpunk: Flavour Nexus (649410) Depot
setManifestid(649410, "265956986413104604", 0)

-- DLCS EXCLUDED (NO DEPOT KEYS, NO DEDICATED DEPOTS)
-- addappid(2729590) -- Jazzpunk Original Soundtrack (no keys available)
