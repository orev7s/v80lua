-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy

-- MAIN APPLICATION
addappid(781640) -- Run Jump Fail

-- MAIN APP DEPOTS
addappid(781641, 1, "bac6f3bcc1085c3ea52ce43b04003856dc9924fe3c637a6c6c4897f384a54af1") -- Run Jump Fail Content
setManifestid(781641, "8755816494643551252", 0)
