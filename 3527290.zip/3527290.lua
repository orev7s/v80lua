-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(3527290, 1, "499eb049b24a30730d5926e9cf72bfa9237d1a7f6de06e94a05e9c2c01348478") -- PEAK
-- MAIN APP DEPOTS
addappid(3527291, 1, "f55585bb6a00ba332421256f80ba05e27afc38fec6170b9a763138244c506f05") -- Depot 3527291
setManifestid(3527291, "3688074374567593439", 3867807688)