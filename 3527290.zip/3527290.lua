-- Made by f1uxin, please read the read me TXT file
-- MAIN APPLICATION
addappid(3527290) -- PEAK

-- MAIN APP DEPOTS
addappid(3527291, 1, "f55585bb6a00ba332421256f80ba05e27afc38fec6170b9a763138244c506f05") -- Depot 3527291
setManifestid(3527291, "6960028543313449724", 0)
