-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @F1uxin on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!)

-- MAIN APPLICATION
addappid(376870) -- Minecraft: Story Mode - A Telltale Games Series

-- MAIN APP DEPOTS
addappid(376871, 1, "e40b44c85e3f954d9ad5e92573b2ab88abdd20dacf5920154099b45769d2a757") -- Red Brass Kitten PC
setManifestid(376871, "5621137552341032518", 0)
addappid(376872, 1, "fe0ec3732373e06d26cbe0da6331d19f612c1636eee6411e00bb531e3d3b9f0e") -- Red Brass Kitten Mac
setManifestid(376872, "1252395573035928717", 0)
addappid(376873, 1, "2e62cb878cd67432b9097c01a6542e03e6479cf0a96151f2f3482a34cfd50258") -- EP2 PC
setManifestid(376873, "3138617374259771046", 0)
addappid(376874, 1, "0656889dc42eebebd535abe82b7cd36c8a1e164d4eae121d1d8ab1e85ea03777") -- EP2 Mac
setManifestid(376874, "1476509975152775211", 0)
addappid(376876, 1, "9bb02630fbb94fdce93b07fbb9fdd44e2eb00ada8ccc1007e8d68eeed9a864e1") -- EP3 PC
setManifestid(376876, "8971926279932152209", 0)
addappid(376877, 1, "a314bfb0c30bdb75a15db4e228424dcfc6a3ba6754b2b0be810756d3d5c9f7bb") -- EP3 Mac
setManifestid(376877, "2227024461442707871", 0)
addappid(376878, 1, "aad419ea9896b3ce820778ad229eae053ad7185caf594f540c1807f2a9fe0561") -- EP4 PC
setManifestid(376878, "5805188047120125978", 0)
addappid(376879, 1, "f0de3e7c40cb3a734285afe871552a659443a72fe88fed5926519738831680c1") -- EP4 Mac
setManifestid(376879, "1211848128568422943", 0)
addappid(450900, 1, "4244360394b880db9de3ffc942193179d1b31324a3c694051dfd5f71b9cfc47b") -- EP5 PC
setManifestid(450900, "4083170370313241360", 0)
addappid(450901, 1, "7b6a9a760fa8434058e018a78d76bac0d576e7761133d8889e44194bd3851f1f") -- EP5 Mac
setManifestid(450901, "1562103247147954372", 0)
addappid(456638, 1, "9d6deb9f7e1e6896c4779ea8738047c7ec074b01ddc328382bc3b922db9d0307") -- Internal PC
setManifestid(456638, "6050508492648663536", 0)
addappid(456639, 1, "a9dcced58ab88e7333c9831332e4bf06f2f5ff53785afa845dce842e1be3dbbb") -- Internal Mac
setManifestid(456639, "1038366271082762156", 0)
addappid(450908, 1, "c85d463a6ef2e72a1acb5f67ae23aa27d18a9cbb5799e812f3366045aebad916") -- PC Patch 1
setManifestid(450908, "5997656139808696380", 0)
addappid(450909, 1, "66b9acde44e8b03e4fde5c5bfde73344db624adcadf8abdbea43840b43f685c6") -- Mac Patch 1
setManifestid(450909, "7189177249684838442", 0)

-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Minecraft Story Mode - Adventure Pass (AppID: 456630)
addappid(456630)
addappid(456630, 1, "12a422195a461a9b4e57b81eb96dbe1b5641ad349574fff7007bbea8ff213161") -- Minecraft Story Mode - Adventure Pass - AP
setManifestid(456630, "5565357343425985685", 0)
addappid(450902, 1, "a94e3808af37da4815d0491ef8dbbb045af09407c7ab7448b11ebd9dfb341bfe") -- Minecraft Story Mode - Adventure Pass - EP6 PC
setManifestid(450902, "6426175610746165025", 0)
addappid(450904, 1, "2a61872fff50d0b35e3b64ba00d9b908d8ac39354d8cae325e7d5430485cc3c5") -- Minecraft Story Mode - Adventure Pass - EP7 PC
setManifestid(450904, "8756011117889374630", 0)
addappid(450906, 1, "a40dad556c7a6d74e92fd3578aa260d22cc19dcdaf638c2f6e3eda4ad5365554") -- Minecraft Story Mode - Adventure Pass - EP8 PC
setManifestid(450906, "4249820327639899061", 0)
