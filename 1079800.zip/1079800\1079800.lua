addappid(1079800)
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228987)
setManifestid(228987,"4302102680580581867")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229002)
setManifestid(229002,"7260605429366465749")
addappid(229004)
setManifestid(229004,"5220958916987797232")
addappid(229005)
setManifestid(229005,"7992454656023763365")
addappid(229006)
setManifestid(229006,"1784011429307107530")
addappid(1079801,0,"42658144daff10982bfa06dcdc13b2fea75268b2c08496130a993f270e3d9bad")
setManifestid(1079801,"1936419570724387563")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]