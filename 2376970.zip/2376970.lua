-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(2376970) -- My Horse: Bonded Spirits

-- MAIN APP DEPOTS
addappid(2376971, 1, "8040973d3327f9158b0235b7364eb9772befe6e4add9bc83ae1a8c26f70485a2") -- Main Game Content (Windows Content)
setManifestid(2376971, "1295847580587337259", 0)
