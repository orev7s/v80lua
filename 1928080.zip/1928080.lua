-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(1928080) -- Prospector
-- MAIN APP DEPOTS
addappid(1928082, 1, "69801bcc38926135f052c49ed4d230f0e3283790bbc4427a5327406e1386f551") -- Depot 1928082
setManifestid(1928082, "3316563802928370424", 891509329)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3812350) -- Prospector - Supporter pack