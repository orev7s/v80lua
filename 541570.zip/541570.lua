-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(541570) -- Sally Face - Episode One

-- MAIN APP DEPOTS
addappid(541571, 1, "7caf433d7b05ced5e4100662143874a646974177d10023150f1a469f9ba04737") -- Sally Face Content
setManifestid(541571, "2809394139841862888", 0)
addappid(541572, 1, "6c44656fc557d3073823098a5fe4c2893ff2b4af4310d4fedf38498fba40f1ea") -- Sally Face Mac
setManifestid(541572, "7223373619665278277", 0)
addappid(541573, 1, "c1a2a0e882dbcb82bb71e7caaec0f9f86e1dd16504758ed61ff427fc18d43700") -- Sally Face Linux
setManifestid(541573, "9135803698058989571", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Sally Face - Season Pass (AppID: 567990)
addappid(567990)
addappid(567990, 1, "a256619574a2ab955723020302a9cb466b2c08d3b826ba819b09346e05d17a5b") -- Sally Face - Season Pass - Sally Face - Season Pass (567990) Depot
setManifestid(567990, "3814564499766467774", 0)
addappid(541574, 1, "861f24df3232ded92d1705842975f7f7a3d8b082387d24cfb7839ab693fe960b") -- Sally Face - Season Pass - Sally Face - Season Pass [Mac]
setManifestid(541574, "5548270519226605183", 0)
addappid(541575, 1, "a734c8aa5682e747741f2e96c3d3f5bf42668834b6f9f1abc9c1d3b739230f1b") -- Sally Face - Season Pass - Sally Face - Season Pass [Linux]
setManifestid(541575, "9104403471409155188", 0)
