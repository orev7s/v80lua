addappid(1373880)
addappid(1373881,0,"347cd235e921626e36b3aa7cc46bbf987d31329c05875307e7ddbdc2c162e128")
setManifestid(1373881,"7306731710098062645")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]