-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(1525890) -- Death Park 2

-- MAIN APP DEPOTS
addappid(1525891, 1, "860decafe72c377f69723bcf7f2a743293af372aae7888ca60c36f774311a3db") -- Death Park 2 Content
setManifestid(1525891, "877797820084084441", 0)
