-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(781050) -- Evie

-- MAIN APP DEPOTS
addappid(781051, 1, "c7effca1a425d6cf1dc1f8269c8ce6749b56cb578c1546a1b1b08c052f6f7606") -- Evie 1.16.2018
setManifestid(781051, "1693555287144854849", 0)
