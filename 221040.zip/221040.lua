-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(221040) -- Resident Evil 6

-- MAIN APP DEPOTS
addappid(221041, 1, "0caaeec12d875fdc90b98bc67e35c76e8783d1dcd937cf35c40a9c24e3a6255d") -- Resident Evil 6 Content
setManifestid(221041, "8522634851660930798", 0)
addappid(221042, 1, "6a1e95acc180950d80167ccc4f012db4f7db4bd51e7816f2a00359383633a0bf") -- Resident Evil 6 LV German
setManifestid(221042, "6745134263174508495", 0)
addappid(221043, 1, "02962ce3b494d53c57bd61a826554005fb222503e6c0060bd26e2cc579a50b77") -- Resident Evil 6 LV Japan
setManifestid(221043, "5001018017832008532", 0)
addappid(221044, 1, "3dd6e6a48115cfd940f98db42ea65096953bfeb0f276b9920dac8b314ac80baf") -- resident evil 6 / biohazard 6 Test Depot
setManifestid(221044, "8789929426254680097", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Resident Evil 6 Mercenaries No Mercy (AppID: 228580)
addappid(228580)
addappid(228580, 1, "2424887018c8183e1490b98ae7786a90d24e24cb4c46a61c123930c78811ab97") -- Resident Evil 6 Mercenaries No Mercy - Resident Evil 6 LV German Hyper Mercenaries
setManifestid(228580, "8273703995269190886", 0)

-- Resident Evil 6 Art Book (AppID: 232490)
addappid(232490)
addtoken(232490, "18232185815196388220")
addappid(232490, 1, "5576dff2e35fbdbe881daa2b22f385222145d8b2016560f8b83f15a8275b90b5") -- Resident Evil 6 Art Book - Resident Evil 6: Art Book
setManifestid(232490, "4766891803519297317", 0)

-- Resident Evil 6 Art Book Japanese (AppID: 232491)
addappid(232491)
addappid(232491, 1, "ce138b6addc4abf27fdae757fee938ddc6cc2a0fc526ddb484c39f0b022293f3") -- Resident Evil 6 Art Book Japanese - Resident Evil 6: Art Book Japanese
setManifestid(232491, "1501175007995626401", 0)

-- Resident Evil 6 Soundtrack (AppID: 232510)
addappid(232510)
addappid(232510, 1, "869fa259e1abbcfb8025c3df14623821df402e9d48f7fb24fba8c705c072a868") -- Resident Evil 6 Soundtrack - Resident Evil 6: Soundtrack
setManifestid(232510, "3325491477400887902", 0)

-- Resident Evil 6 Onslaught mode (AppID: 232530)
addappid(232530)
addappid(232530, 1, "9c993db672f4e320225bbfab9902a6fae2222734c907028fcb48eacd096a1578") -- Resident Evil 6 Onslaught mode - Resident Evil 6: Onslaught Mode
setManifestid(232530, "4578502731029880419", 0)

-- Resident Evil 6 Predator mode (AppID: 232550)
addappid(232550)
addappid(232550, 1, "6affc24729a4aa5d5f02e24aaf03e5f0421bad2aa32c382f53bc5bc17778b3c7") -- Resident Evil 6 Predator mode - Resident Evil 6: Predator Mode
setManifestid(232550, "6419035047511949838", 0)

-- Resident Evil 6 Siege Mode (AppID: 232570)
addappid(232570)
addappid(232570, 1, "7272f338b0b950923367dc0643d2ef343c943311af70b29001da02e114e31c90") -- Resident Evil 6 Siege Mode - Resident Evil 6: Siege Mode
setManifestid(232570, "4380680925184539415", 0)

-- Resident Evil 6 Survivors Mode (AppID: 232590)
addappid(232590)
addappid(232590, 1, "de3eaf13095e5567e271b41dd9ccc82f4f25a75b3a7d360dc52164bd56b08b62") -- Resident Evil 6 Survivors Mode - Resident Evil 6: Survivors Mode
setManifestid(232590, "5373308995109810588", 0)

-- Resident Evil 6 Wallpaper (AppID: 236080)
addappid(236080)
addtoken(236080, "17069571701871843363")
addappid(236080, 1, "7cb295a70dfbb52b081ad5da1559010aba2c5244a4eb50a78970b04a2da695eb") -- Resident Evil 6 Wallpaper - Resident Evil 6: Wallpaper
setManifestid(236080, "7387874972474539378", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(235560) -- RESIDENT EVIL 6  BIOHAZARD 6 Season Pass
