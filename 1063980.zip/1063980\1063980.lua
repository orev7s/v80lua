addappid(1063980)
addappid(1063981,0,"dd9b06b4ac4d3d258bd3c740d1d37080978b868ec1ed43cf67321b5826c1f93a")
setManifestid(1063981,"1862259269499192493")
addappid(1063982,0,"6c605fb6a282d3d5429584514def3807dc2bad83637b8f517c5463edf9dce611")
setManifestid(1063982,"1330044887015253485")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]