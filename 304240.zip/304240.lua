-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(304240) -- Resident Evil

-- MAIN APP DEPOTS
addappid(304241, 1, "628406156243272990c118c3a8497b1bdc8b03a11cd1b21e986ff86c89a45f49") -- Mansion Content
setManifestid(304241, "110278523771241710", 0)
addappid(304242, 1, "e86af320324228098bed69cf389ccd1b7af582a1f5725a1952a5815fd7cc1313") -- Mansion Content WorldWide
setManifestid(304242, "9087090834863155228", 0)

-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Resident Evil HD REMASTER - Sountrack selections (AppID: 345190)
addappid(345190)
addappid(345190, 1, "60ab048988d781e57c9bbc1881b3a4fbc67178b649d758ef782277efc5f073f5") -- Resident Evil HD REMASTER - Sountrack selections - Resident Evil HD REMASTER - Sountrack selections (345190) Depot
setManifestid(345190, "7864329718337415853", 0)

-- Resident Evil HD REMASTER - Artbook selections (AppID: 345191)
addappid(345191)
addappid(345191, 1, "eb7b2280a99010609c30169ce5ea98a4052c54a7139feab5e3ffacdac64035fd") -- Resident Evil HD REMASTER - Artbook selections - Resident Evil HD REMASTER - Artbook selections (345191) Depot
setManifestid(345191, "7576499935902985330", 0)
