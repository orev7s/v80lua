-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(631510)
addappid(631511,0,"79183f987f646ce0abe58d2a413285f83e8bc0d045c01864d28e30bb6ee37ae2")
setManifestid(631511,"7018858071300627307")
addappid(811840,0,"16b5d8916c93e2e48652438e21a29ca27db96cdf30f095c95d0ee9eec24cf34b")
setManifestid(811840,"1956669955052522073")