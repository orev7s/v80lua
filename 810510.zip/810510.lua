-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(810510) -- Welcome Back Daddy

-- MAIN APP DEPOTS
addappid(810511, 1, "e8c056cc9de874d1c77bac139240e6650e3182ad8e35698e9787161f0561ac4c") -- Welcome back Daddy Depot
setManifestid(810511, "5796668747636691388", 0)
