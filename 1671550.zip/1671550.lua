-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(1671550) -- The Night Way Home | 帰り道

-- MAIN APP DEPOTS
addappid(1671551, 1, "a90450ca8cdad91e953978cc2d5645458747bebdb7f8ac5f896ab74b2366fb5a") -- Walk Home | 帰り道 Content
setManifestid(1671551, "8324271080916194595", 0)
