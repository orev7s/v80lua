-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy / https://discord.gg/m8PxjTwrnv
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(667970) -- VTOL VR

-- MAIN APP DEPOTS
addappid(667971, 1, "34da89de74099b39413bba485bc7fff7a4bebaad40a894b31bcbee4b3f207a0e") -- VTOL VR Content
setManifestid(667971, "2244450996154306151", 0)

-- DLCS WITH DEDICATED DEPOTS
-- VTOL VR EF-24 Mischief - Electronic Warfare (AppID: 2531290)
addappid(2531290)
addappid(2531290, 1, "d5fd310d63d0468ce9b645c74008874bedc3c31bc1e6d1d774b896306c6d10e8") -- VTOL VR EF-24 Mischief - Electronic Warfare - Main Content
setManifestid(2531290, "1746642230860805602", 0)

-- DLCS EXCLUDED (NO DEPOT KEYS, NO DEDICATED DEPOTS)
-- addappid(1770480) -- VTOL VR AH-94 Attack Helicopter (no keys available)
-- addappid(2141700) -- VTOL VR T-55 Tyro - Trainer Jet (no keys available)
