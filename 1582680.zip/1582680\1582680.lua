addappid(1582680)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1582681,0,"6777aac904aa3af99ba8147dc462a6ffd184255b8fba3a0ec5a9fc171bf2dd6c")
setManifestid(1582681,"7007998724030429617")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]