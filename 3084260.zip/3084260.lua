-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(3084260) -- Ink Reverie

-- MAIN APP DEPOTS
addappid(3084261, 1, "30de38a7e6d36bfc6744f2410d44d88b677d525ec40f25d8eee660fcd130a4eb") -- Depot 3084261
setManifestid(3084261, "7240473748729840323", 0)

-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Ink Reverie Soundtrack (AppID: 3844250) - missing depot keys
-- addappid(3844250)
