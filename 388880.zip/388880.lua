-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(388880) -- Oxenfree

-- MAIN APP DEPOTS
addappid(388881, 1, "dd211a172b43410e44d92b89c5615f2eadb5f6dcac614e5a7e389a8fbae36cdf") -- Oxenfree Windows x64 Content
setManifestid(388881, "1977046335184630494", 0)
addappid(388883, 1, "01d2d8cee8efa32284c76efa8b21bf155307c4a341145c9a67e0c7bb50d1073d") -- Oxenfree Windows x86 Content
setManifestid(388883, "5428810816993209399", 0)
addappid(388882, 1, "c1a947eceeacd834d08a0eda02fcebad654f3279963d4218a5ec4f1cf3ddb063") -- Oxenfree Mac Universal Content
setManifestid(388882, "4919353673322061966", 0)
addappid(388884, 1, "a125da1fad20abeb76ee3014727e885a27d2b66b4b6b820f96d3fcbf13d84142") -- Oxenfree Linux Universal Content
setManifestid(388884, "7108578419670967731", 0)
addappid(388885, 1, "a774d69747d607c5f6f9f398548e34569a441c43b009e51fe581a3abe19b3cf2") -- Steam API - Linux x64
setManifestid(388885, "760220395727681197", 0)
addappid(388886, 1, "72af340112f261a37b219d7b4bb77b3d1208d412a060e7a2daed851d940f07f9") -- Steam API - Linux x86
setManifestid(388886, "4817487458570974807", 0)

-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Oxenfree - OST (AppID: 433430)
addappid(433430)
addappid(433430, 1, "21e3deebd082cf433e7dfe8f5bd0eddea4c92ae13ea20576515778257dfbd749") -- Oxenfree - OST - Oxenfree - OST (433430) Depot
setManifestid(433430, "6967261710161510923", 0)
