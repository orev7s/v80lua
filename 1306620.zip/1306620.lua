-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(1306620) -- Missing Children | 行方不明

-- MAIN APP DEPOTS
addappid(1306621, 1, "70e41151f37c562c4c6f08b2bc8a0d0bf84b75414f5bc3f04ff8bf4cb2d0a480") -- Missing Children | 行方不明 Content
setManifestid(1306621, "2187053497035625862", 0)
