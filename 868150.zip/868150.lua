-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪username - f1uxin, on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy / https://discord.gg/m8PxjTwrnv
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(868150) -- Takelings House Party

-- MAIN APP DEPOTS
addappid(868151, 1, "18885cd77c8888cc10a3a749c2e9f60e1a7c71d546844da66a4885c97cc5d4f9") -- Takelings House Party Content
setManifestid(868151, "979477833760716620", 0)
