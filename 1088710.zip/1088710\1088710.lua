addappid(1088710)
addappid(1088711, 1, "c1b7e189e92f1444dccf6f8b7f8e0210e613a88b9d8de8c178044862d9c946f4")
setManifestid(1088711, "5255602264781295535", 0)
addappid(1088712, 1, "cca872cb599f2e4755fe421841cf97f37a1664954eb4f96f09edd06b956da99e")
setManifestid(1088712, "8896346631425795919", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]