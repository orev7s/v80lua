addappid(1237610)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1237611,0,"8370fb42f03fbdf42876ca7fc785e7fb335451dfc9b8523d99c7aebec51c17f1")
setManifestid(1237611,"5396373659173756083")
addappid(1351270,0,"56b4b370f435a1a1d29cd2e154ab7019e44c056a710d5ea39c14217ae09b92dc")
setManifestid(1351270,"2302141453877750441")
addappid(1351271,0,"fd34d2633b7f037d44262c1b084a34d15637951367ef8acbbb4b72ae4d51db94")
setManifestid(1351271,"8809359763593543026")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]