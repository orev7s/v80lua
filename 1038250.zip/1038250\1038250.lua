addappid(1038250)
addappid(1038251, 1, "43d22ea77f4f8585fe8af24877fe8922406632b6508c6adf08509fdae67d2e62")
setManifestid(1038251, "9032882404118680792", 0)
addappid(1038252, 1, "8373feec31992e456a798b03476b51d4ebdb5b673a5405323ecfb1ea4dd777f8")
setManifestid(1038252, "3184626638537455302", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]