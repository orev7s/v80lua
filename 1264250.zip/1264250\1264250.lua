addappid(1264250)
addappid(1264251,0,"f66ccb885e4950a5302d658fe1d9b31398819fcb553f67adb7e677cb2650975f")
addappid(1264252,0,"b0cf1577edc1154850e8c555c5dbde9ced82806c8729d8e69709f79d146fde12")
setManifestid(1264251,"9132090305696491358")
setManifestid(1264252,"8953107235105912665")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]