addappid(1766060)
addappid(1766061,0,"33229ac4689c705f913fd8f448d3f896fe128255629ad018dca089578dbf85c3")
setManifestid(1766061,"8962383569507229882")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]