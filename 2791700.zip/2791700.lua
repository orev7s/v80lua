-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(2791700) -- Infantry Attack

-- MAIN APP DEPOTS
addappid(2791701, 1, "12642b33843bc523f6a5daf518c326c5ac04348b5a10db889642e67e9e16c0b8") -- Main Game Content (Windows Content)
setManifestid(2791701, "4649323198611796670", 0)
