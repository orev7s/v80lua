addappid(1452250)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228989)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229007)
setManifestid(229007,"4477590687906973371")
addappid(1452251,0,"ce6083023fe1c79bd239730313703f8074978705a075f13dd6234c45b8d79156")
setManifestid(1452251,"7001688681830891154")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]