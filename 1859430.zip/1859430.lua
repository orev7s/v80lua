-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is.
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(1859430) -- Shadow Labyrinth

-- DLCS WITH DEDICATED DEPOTS
-- Shadow Labyrinth - Original Arcade SFX (AppID: 3349710)
addappid(3349710)
addappid(3349710, 1, "7da5a6c00b768ae8d7316817e8f473b6c9aa267597c56f170e39bb08fed2d278") -- Shadow Labyrinth - Original Arcade SFX - Depot 3349710
setManifestid(3349710, "8895139168915558811", 0)

-- Shadow Labyrinth - Digital Artbook  Soundtrack  (AppID: 3349720)
addappid(3349720)
addappid(3349720, 1, "4d36c89f489cdbc426e6020f4eda05eb8827a63a9688cb668819bb38cb6addbf") -- Shadow Labyrinth - Digital Artbook  Soundtrack  - Depot 3349720
setManifestid(3349720, "8118426722462723039", 0)
