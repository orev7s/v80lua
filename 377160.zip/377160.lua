-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(377160) -- Fallout 4

-- MAIN APP DEPOTS
addappid(377161, 1, "cf55ff4eb121541f33f811d2d6ea719ca07d31a0fd0538d919681f88d65f4ded") -- Fallout 4 content_a
setManifestid(377161, "7332110922360867314", 0)
addappid(377162, 1, "9359116457874510935256b2afa0ee9a9a9f9d5f2f2f73ebd4572c10a12151ed") -- Fallout 4 exe
setManifestid(377162, "5698952341602575696", 0)
addappid(377163, 1, "f03ba1f9873bd21c81244e645173f5af3e91835b639d3844e9056884e8adec69") -- Fallout 4 content_b
setManifestid(377163, "8681102885670959037", 0)
addappid(377164, 1, "56581e69491ba1f0201475f72b87e17a3cc811af69f607b347a2e4ae9186bd91") -- Fallout 4 english
setManifestid(377164, "8492427313392140315", 0)
addappid(377165, 1, "aaa48ad43bfc6f4d98f66db3d51885094a8a76a000a631accd7b31b77e60551f") -- Fallout 4 french
setManifestid(377165, "8045191663392248690", 0)
addappid(377166, 1, "3b2ed944d6d06581d05a9e39624d2ec0072a0e1874f68bcbd3d79720f107b8c6") -- Fallout 4 german
setManifestid(377166, "5181861686732774133", 0)
addappid(377167, 1, "8b387ace74796c278318d32849b1166cc5e8cf903737fd373283bfc378b13c03") -- Fallout 4 italian
setManifestid(377167, "6159581842674600625", 0)
addappid(377168, 1, "989db8879bc65a93a05f637822e2f8f5ae6bdba3e8c4deabe2de7537d8c5dd90") -- Fallout 4 spanish
setManifestid(377168, "2941745134283711063", 0)
addappid(393880, 1, "be371c5fd2f17bb744a123119f2183e056f126efe4840e31ef78c5910c6dde15") -- Fallout 4 polish
setManifestid(393880, "4656512446653497676", 0)
addappid(393881, 1, "7ea60442ab1956fbaad239a5ad4689865408d828dd33f61b2a77000432e93532") -- Fallout 4 russian
setManifestid(393881, "9220466047319762009", 0)
addappid(393882, 1, "dbdd032f2bba74024f7e997d9e3d6f887d807d93079e4351695bb5ee6471e1cf") -- Fallout 4 portuguese-br
setManifestid(393882, "8191305962459798887", 0)
addappid(393883, 1, "c42701914a636c3fff6384296da4d88fdd40e1bda656e28f7aaa2a1e9c7bd4ff") -- Fallout 4 traditional chinese
setManifestid(393883, "8665224215527782698", 0)
addappid(393884, 1, "a67dc17de7b3199a0ff3856ce2e26674c4f27e3c11584b8bbafe75a8742e19ec") -- Fallout 4 japanese
setManifestid(393884, "6797758859461570066", 0)

-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Fallout 4 - Automatron (AppID: 435870)
addappid(435870)
addtoken(435870, "17969553131570605880")
addappid(435870, 1, "fd023abf6834589abe5b821cacd216be0e8d5a9e9721ab8ebe31dcf701c0de7d") -- Fallout 4 - Automatron - Fallout 4 - Automatron (435870) Depot
setManifestid(435870, "1213339795579796878", 0)
addappid(435871, 1, "aacc0920e891440700301b37b1cb8b69e1d5cf1b32a92922b10278b19660d804") -- Fallout 4 - Automatron - Fallout 4 - Automatron english
setManifestid(435871, "7785009542965564688", 0)
addappid(435872, 1, "01f0ec6bf3f63f16575ea6641475c57d01d3b8dc20a3c39cd8ceacf79f588c44") -- Fallout 4 - Automatron - Fallout 4 - Automatron french
setManifestid(435872, "7005875929366232340", 0)
addappid(435873, 1, "599277603b3eda83869261b13e66050cc02e26f31f1fe08c8ec5900b64062334") -- Fallout 4 - Automatron - Fallout 4 - Automatron german
setManifestid(435873, "7032871961633882628", 0)
addappid(435874, 1, "4c5e3baa3d3e4e68a04f56628c8cbd33a0596bfa535e85e901270eb7b14af989") -- Fallout 4 - Automatron - Fallout 4 - Automatron italian
setManifestid(435874, "3456890184317469397", 0)
addappid(435875, 1, "814fa019490218c830186ed12559f0eabe59d24f3bb7e7d3522d358679330c71") -- Fallout 4 - Automatron - Fallout 4 - Automatron spanish
setManifestid(435875, "3302169299215915593", 0)
addappid(435876, 1, "a13a6971709630b53e7ff6229bda149bb26c32db6be18ba9b5ee3bf2e4b3474d") -- Fallout 4 - Automatron - Fallout 4 - Automatron polish
setManifestid(435876, "3855123742386435744", 0)
addappid(435877, 1, "3d24c99bdda19313f7a226584b9e85e89dd7f94cab42186d7748939d09c9de18") -- Fallout 4 - Automatron - Fallout 4 - Automatron russian
setManifestid(435877, "7266521576458366233", 0)
addappid(435878, 1, "f8d3fefa3a0dc6478c310aac162f0188fae8a6a2882b3f217f1023409ce2d999") -- Fallout 4 - Automatron - Fallout 4 - Automatron portuguese-br
setManifestid(435878, "2863491461978199343", 0)
addappid(435879, 1, "2ee9553b4473c82551838b6b6414bc2fbe36c2e95a6e0067dd00043d982d97f4") -- Fallout 4 - Automatron - Fallout 4 - Automatron traditional chinese
setManifestid(435879, "2755212490240557490", 0)
addappid(404091, 1, "3dd27f593b9f0930a8a3b98b55a389b64f2fa4f9bf5ff34ba6005bb3bb2cb845") -- Fallout 4 - Automatron - Fallout 4 - Automatron japanese
setManifestid(404091, "1644608195071865486", 0)

-- Fallout 4 - Wasteland Workshop (AppID: 435880)
addappid(435880)
addtoken(435880, "17715695874793604951")
addappid(435880, 1, "13b5b5f94eefcc14fabb0b56123feb7e52721ab1102049bc32bfcd3e725019e8") -- Fallout 4 - Wasteland Workshop - Fallout 4 - Wasteland Workshop (435880) Depot
setManifestid(435880, "366079256218893805", 0)

-- Fallout 4 - Far Harbor (AppID: 435881)
addappid(435881)
addappid(435881, 1, "4731dc8b04e4489853ae1c53e3acc9f0a01e825b40b7fc9a4a42caba6ac1b827") -- Fallout 4 - Far Harbor - Fallout 4 - Far Harbor (435881) Depot
setManifestid(435881, "1207717296920736193", 0)
addappid(435882, 1, "104a86e91eee18c19b3510432a7af8070a1f8f1c4503eb14bff5b4403277b58c") -- Fallout 4 - Far Harbor - Fallout 4 - Far Harbor english
setManifestid(435882, "8482181819175811242", 0)
addappid(435883, 1, "86da5aac15b38aabc81cb05fd6a22ed668c8c0df9f59a970363bf07ec3c02a1d") -- Fallout 4 - Far Harbor - Fallout 4 - Far Harbor french
setManifestid(435883, "8148702710057205377", 0)
addappid(435884, 1, "600d918749fe3c1b474a4f35006093da7b776c1d22f77631c54c79178d9d7d04") -- Fallout 4 - Far Harbor - Fallout 4 - Far Harbor german
setManifestid(435884, "1583726361179064237", 0)
addappid(435885, 1, "5ec02acad9ff3460418cd29f03fc1dbee198928c39480eaad5893a9d1f1b19fd") -- Fallout 4 - Far Harbor - Fallout 4 - Far Harbor italian
setManifestid(435885, "545294059663977441", 0)
addappid(435886, 1, "0252bc7861d5e8f23b05868f9c426858bf394c1cb31d55a1d8698d38fa6e51d6") -- Fallout 4 - Far Harbor - Fallout 4 - Far Harbor spanish
setManifestid(435886, "6337694505107499720", 0)
addappid(435887, 1, "2be8d5ae343e13852b44df46e61c82d40ca24cbfcff9c5c47ede9f67c138128f") -- Fallout 4 - Far Harbor - Fallout 4 - Far Harbor polish
setManifestid(435887, "1696734609684135531", 0)
addappid(435888, 1, "6694db4f8104eddbfe57cff2b59f32d4bf8f5dde0e53cdb14cb5b72c1e27605f") -- Fallout 4 - Far Harbor - Fallout 4 - Far Harbor russian
setManifestid(435888, "2814340383581262374", 0)
addappid(435889, 1, "7ee24d3ddff2cced1b3db1dde5a525b2e425b82c95de0c85fcce2f628dbe94a7") -- Fallout 4 - Far Harbor - Fallout 4 - Far Harbor portuguese-br
setManifestid(435889, "3739447432423498108", 0)
addappid(404092, 1, "5c000d51b29a21009a0c34676736af0489b84ff04d95ffaad51b2e08edb11cbc") -- Fallout 4 - Far Harbor - Fallout 4 - Far Harbor traditional chinese
setManifestid(404092, "6806984433357643395", 0)
addappid(404093, 1, "86e7040eb97d187726bd865bf08c7448cd80b7f8f24aebf859517b949bc92b96") -- Fallout 4 - Far Harbor - Fallout 4 - Far Harbor japanese
setManifestid(404093, "1398706778481280442", 0)

-- Fallout 4 - Contraptions Workshop (AppID: 480630)
addappid(480630)
addappid(480630, 1, "6953ddb6e356d189e09f0b50251b037ac8c81936dbc4565e090d496c0be8b873") -- Fallout 4 - Contraptions Workshop - Fallout 4 - Contraptions Workshop (480630) Depot
setManifestid(480630, "5527412439359349504", 0)

-- Fallout 4 - Vault-Tec Workshop (AppID: 480631)
addappid(480631)
addappid(480631, 1, "a88d4ec336a1ba15e5717651684218f13a243e72bce1b32b71b7f31c53fb5237") -- Fallout 4 - Vault-Tec Workshop - Fallout 4 - Vault-Tec Workshop (480631) Depot
setManifestid(480631, "6588493486198824788", 0)
addappid(393885, 1, "d9971261bad1c0f7aefc8827764b4219e13aadb91470775669b513c82c15e187") -- Fallout 4 - Vault-Tec Workshop - Fallout 4 - Vault-Tec Workshop english
setManifestid(393885, "5000262035721758737", 0)
addappid(393886, 1, "e0c2c543eab3d78f84738d8aa943f6b11459da98c357eadd718eaf4f2adde66a") -- Fallout 4 - Vault-Tec Workshop - Fallout 4 - Vault-Tec Workshop french
setManifestid(393886, "4075502974578231964", 0)
addappid(393887, 1, "e10a31c16258cb554f492a5e621311ac36ec9dc81d3c1e130763b4143280d192") -- Fallout 4 - Vault-Tec Workshop - Fallout 4 - Vault-Tec Workshop german
setManifestid(393887, "4458604458983717666", 0)
addappid(393888, 1, "70bfc01d0911594548dcb656c8c812377d1ebe7e77388a69c6578af1f9c929fb") -- Fallout 4 - Vault-Tec Workshop - Fallout 4 - Vault-Tec Workshop italian
setManifestid(393888, "4182964460983125860", 0)
addappid(393889, 1, "86ef9bb8655900e4d97dc8296e267e88f864810ed6f68726643b16ab404ea584") -- Fallout 4 - Vault-Tec Workshop - Fallout 4 - Vault-Tec Workshop spanish
setManifestid(393889, "7553859846726526417", 0)
addappid(393890, 1, "a8fd2b3208528a9b01591d8ac5b602d9cf9e7e6d4dc2965252737af6729d0dd9") -- Fallout 4 - Vault-Tec Workshop - Fallout 4 - Vault-Tec Workshop polish
setManifestid(393890, "1765554658221186452", 0)
addappid(393891, 1, "08d7dbf14f3d6009b1b2b0ec03018fef84715f166df545508f7c98271759bd01") -- Fallout 4 - Vault-Tec Workshop - Fallout 4 - Vault-Tec Workshop russian
setManifestid(393891, "631542034352937768", 0)
addappid(393892, 1, "3d75cb3eef28d199fcb66a190f1be5b8b2e7cf4f3fbcf5dc7836b4f20596d97e") -- Fallout 4 - Vault-Tec Workshop - Fallout 4 - Vault-Tec Workshop portuguese-br
setManifestid(393892, "1388883862084490494", 0)
addappid(393893, 1, "fdbad14eaa02a4794dcdf2cfb2737262057045d7dd0e97647a5aaab843c7491c") -- Fallout 4 - Vault-Tec Workshop - Fallout 4 - Vault-Tec Workshop traditional chinese
setManifestid(393893, "442593679549850747", 0)
addappid(393894, 1, "6b64b629795dde4903ab8c5bef8f4222d1d67849e677d6f9b0941c859767d13f") -- Fallout 4 - Vault-Tec Workshop - Fallout 4 - Vault-Tec Workshop japanese
setManifestid(393894, "284738489375199037", 0)

-- Fallout 4 - Nuka-World (AppID: 490650)
addappid(490650)
addappid(490650, 1, "587e38c20a8f18f3825470a5c22ebd0c2c3cb86df75f3b8fed4bfe3c0dcfe35a") -- Fallout 4 - Nuka-World - Fallout 4 - Nuka-World (490650) Depot
setManifestid(490650, "4873048792354485093", 0)
addappid(393895, 1, "89cc7d9d61ec6f74626b9b2dc202339a17fed368450352256d6876d8e26ff7ca") -- Fallout 4 - Nuka-World - Fallout 4 - Nuka-World english
setManifestid(393895, "7677765994120765493", 0)
addappid(393896, 1, "92ede763b94b9b539344f426567b63ceb14eb58f1046c285dacbce4d28cdf65d") -- Fallout 4 - Nuka-World - Fallout 4 - Nuka-World french
setManifestid(393896, "4271967849859961419", 0)
addappid(393897, 1, "66d2d640107c97b2f9e6938c760a2e6ca4e1d9b6da94dc0d145fec9bcee4d63e") -- Fallout 4 - Nuka-World - Fallout 4 - Nuka-World german
setManifestid(393897, "1357704281835463005", 0)
addappid(377169, 1, "1d098c24441e5a8a452c9f364f13a8e141956089d1631f12d969e38b405588f6") -- Fallout 4 - Nuka-World - Fallout 4 - Nuka-World italian
setManifestid(377169, "2112185424871906435", 0)
addappid(393898, 1, "300e5b750a37042421928a85da7379f0699b335c7faa850e0565fc54f66abcd1") -- Fallout 4 - Nuka-World - Fallout 4 - Nuka-World spanish
setManifestid(393898, "8573679706590820412", 0)
addappid(404097, 1, "51b10b95caf52ff20c3229ae88bc1864f4d6e551068210fb925f0c39240c7e9e") -- Fallout 4 - Nuka-World - Fallout 4 - Nuka-World polish
setManifestid(404097, "3040241873036299160", 0)
addappid(393899, 1, "7202ca82570a85a8a4b0b8bb2e71e2163dfbf4cf27ade944fa48b24a98b27b4e") -- Fallout 4 - Nuka-World - Fallout 4 - Nuka-World russian
setManifestid(393899, "1428451409051936353", 0)
addappid(404094, 1, "b03df53e25101784f9c0435d32a074f8bcb5722bb817f0e8500e68a017a826a1") -- Fallout 4 - Nuka-World - Fallout 4 - Nuka-World portuguese-br
setManifestid(404094, "2888111047071072771", 0)
addappid(404095, 1, "8c9c875159b7d5d1b83d8eb006c74c7d2b55a25eb16e698b1d4f3d023e260e64") -- Fallout 4 - Nuka-World - Fallout 4 - Nuka-World traditional chinese
setManifestid(404095, "3169890264626778200", 0)
addappid(404096, 1, "2b21b8ea82ac24e61036ef98a7d4ab8bf2a14f5d48c80165d4feccf3134815ca") -- Fallout 4 - Nuka-World - Fallout 4 - Nuka-World japanese
setManifestid(404096, "2951208112779014496", 0)

-- Fallout 4 - High Resolution Texture Pack (AppID: 540810)
addappid(540810)
addappid(540810, 1, "5dd2a475e216eeb88d5cd53029eca47658f369ba24850e133e54b0f0e4a716bb") -- Fallout 4 - High Resolution Texture Pack - Terrapin (540810) Depot
setManifestid(540810, "1558929737289295473", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(404090) -- Fallout 4 Season Pass
addtoken(404090, "9125628652905021850")
addappid(598110) -- Fallout 4 - Creations
