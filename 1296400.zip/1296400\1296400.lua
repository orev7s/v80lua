-- Made by f1uxin, please read the read me TXT file
addappid(1296400)
addappid(1296401,0,"4e7f5f76e4b45de0a1446e15e192444674e32ac61f103d7772d63b2b88e984a2")
setManifestid(1296401,"3177891525608257016")
