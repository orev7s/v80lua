addappid(1934570)
addtoken(1934570,4713076652622357934)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1934571,0,"8339de2d0121af2b4b3a7ec0b461091ae5a3dcfb4f531c1d45aa3640a8715d17")
setManifestid(1934571,"7224644666438026625")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]