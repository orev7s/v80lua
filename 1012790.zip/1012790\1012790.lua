addappid(1012790)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228987)
setManifestid(228987,"4302102680580581867")
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1012791,0,"569bd7c4d66094271837ea69868e6d849a17ad1d1190f5761f748639ed643f1f")
setManifestid(1012791,"8334610664114747949")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]