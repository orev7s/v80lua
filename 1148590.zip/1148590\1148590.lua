addappid(1148590)
addappid(1148591, 1, "81e323e091fc79632b94020332d7f5f4c5767b99fbf257ed30d61716370b01bc")
setManifestid(1148591, "1585039031650632684", 0)
addappid(1148592, 1, "bc4c97f55279905b9b59959067e5103d47a0efd4464607c1b659fe7ed2790d24")
setManifestid(1148592, "4603289903974203863", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]