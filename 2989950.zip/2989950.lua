-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(2989950) -- The Bathhouse | 地獄銭湯 Restored Ver.

-- MAIN APP DEPOTS
addappid(2989951, 1, "46ba9c35893709885a253dc16ae624a59f7ba30e7d5673c8d70bab12dd2dfa75") -- Main Game Content (Windows Content)
setManifestid(2989951, "8502982591506204150", 0)
