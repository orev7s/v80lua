-- Made by f1uxin, please read the read me TXT file
addappid(2737070)
addappid(2737071,0,"36e272c2274c8d6dbf4a697d1faa618de36bbacf8439215d60cca4350601aedb")
setManifestid(2737071,"2542679740768906713")