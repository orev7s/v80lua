-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(1766100) -- The Last Hero of Nostalgaia

-- MAIN APP DEPOTS
addappid(1766101, 1, "c240c1b2745b02faf40b44b09a7e9521cad742da85c3fa8153648375cfd01b35") -- Main Game Content (Windows Content)
setManifestid(1766101, "8091710384471440807", 0)

-- DLCS EXCLUDED (NO DEPOT KEYS, NO DEDICATED DEPOTS)
-- addappid(2132750) -- The Rise of Evil (no keys available)
