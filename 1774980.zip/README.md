# ManifestAutoUpdate
一个steam清单缓存仓库
