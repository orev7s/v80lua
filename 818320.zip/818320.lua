-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy

-- MAIN APPLICATION
addappid(818320) -- LEGO® The Incredibles

-- MAIN APP DEPOTS
addappid(818321, 1, "6ce5dfe98f68fe49ee0ca8464231b09d5d34c71227f41b4a98d2e77fea8a87da") -- Showtime Content
setManifestid(818321, "5082200738862381232", 0)
addappid(818322, 1, "bf53a94edb83cc75dc2db28f848f970ca181b78da71b13728f7a1541b9c62a42") -- Mac - Showtime Content (818321)
setManifestid(818322, "5630417122678099630", 0)

-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Parr Family Vacation Character Pack (AppID: 818330)
addappid(818330)
addappid(818330, 1, "d3782143e833f0a2ee1f432490d82e17dedc4b8ec937d351418e7285f5a7fa6e") -- Parr Family Vacation Character Pack - Parr Family Vacation Character Pack (818330) Depot
setManifestid(818330, "1680857634589086224", 0)
addappid(818323, 1, "f79b5fc4dd1d7295bce13c630425cf08596173103cbba38750a5d6f7dc6850b2") -- Parr Family Vacation Character Pack - Mac - Parr Family Vacation Character Pack (818330)
setManifestid(818323, "868116497700638192", 0)
