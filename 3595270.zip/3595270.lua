-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(3595270) -- Call of Duty®: Modern Warfare® III
-- MAIN APP DEPOTS
addappid(3603275, 1, "5ab825dc9a9ce12ed4c80b8c2350c71c045889faac2b0ead2da40b5bd6f3d383") -- Depot 3603275
setManifestid(3603275, "97812279956230496", 64369276201)
addappid(3603276, 1, "8e4afff2de1cf7e10417dcff72dfe50a0e3105c47eff17ffcef027a3deaac61c") -- Depot 3603276
setManifestid(3603276, "1369588035072732785", 742810467)
addappid(3603277, 1, "0c3755b90ad768ea9d8ac6947724b80867b35f67d07863e9af44e3089a9b5723") -- Depot 3603277
setManifestid(3603277, "6297716946734525264", 974041832)
addappid(3603464, 1, "e737e49205073cc67c92b462a1a247f3a3f1df8514f95b181676fc1f33a28360") -- Depot 3603464
setManifestid(3603464, "5696464031355307078", 13033676)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITH DEDICATED DEPOTS
-- Call of Duty Modern Warfare III - Campaign (AppID: 3603450)
addappid(3603450)
addappid(3603450, 1, "729168405a0d1171f42a3d94541d9e17a0c4f42fbac19df315ec777e49c1b239") -- Call of Duty Modern Warfare III - Campaign - Depot 3603450
setManifestid(3603450, "8580219281574796647", 47863641312)
addappid(3595272, 1, "4086d876414362977890e32aeb7aabcce058599bd6a954808d6604011a4c77b1") -- Call of Duty Modern Warfare III - Campaign - Depot 3595272
setManifestid(3595272, "9053682250443204265", 734720912)
addappid(3595273, 1, "dae927e306ed94b925fdb577c5a2eea433edc1a9ea4d2fb4014c4f5bdb9a665d") -- Call of Duty Modern Warfare III - Campaign - Depot 3595273
setManifestid(3595273, "5004507027799148762", 908396148)
addappid(3603229, 1, "2ec7842c457de11898a60de77c894c438bd73e8226acb7630978d909f9247dd0") -- Call of Duty Modern Warfare III - Campaign - Depot 3603229
setManifestid(3603229, "8478402319748958625", 12462160)
-- Call of Duty Modern Warfare III - Multiplayer (AppID: 3603460)
addappid(3603460)
addappid(3603460, 1, "9d1af2a2772c7609f565db8dafd7b69bab4852bb988208cdb670e6a52729fd80") -- Call of Duty Modern Warfare III - Multiplayer - Depot 3603460
setManifestid(3603460, "7511090104467066801", 33987541636)
addappid(3603234, 1, "7a30dd7cb27c6823e59d9c8de4bb5fc75f64dabf0e216ba6521bd1afd86a65c2") -- Call of Duty Modern Warfare III - Multiplayer - Depot 3603234
setManifestid(3603234, "4037436283071539951", 29413688)
addappid(3603251, 1, "1fbbf9543f2ae50498215aa68b2f6eaf1c6f1a8d9e5737fb059184741f3cc4b3") -- Call of Duty Modern Warfare III - Multiplayer - Depot 3603251
setManifestid(3603251, "452349824044422082", 2743972)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3603470) -- Call of Duty Modern Warfare III - Zombies