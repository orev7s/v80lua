-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(527450) -- Cockroach Simulator

-- MAIN APP DEPOTS
addappid(527451, 1, "5ba52ef653b6e42da1de630c7c9ba549c6bc3a2ff607681f3fdb504b40575628") -- cs windows
setManifestid(527451, "8400686662295205512", 0)
addappid(527452, 1, "61eaba5a893092d894477cd002ed515241ee3d76e3f8d55cc40d79232e302331") -- cs linux
setManifestid(527452, "5987335802532214658", 0)
addappid(527453, 1, "892099b24241c4bb5b6655c14c117820e8b9e333918e0410bca1cc3edcf82bfe") -- cs mac
setManifestid(527453, "1223411734536009508", 0)
