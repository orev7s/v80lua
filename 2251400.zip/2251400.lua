-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(2251400) -- Everdeep Aurora

-- MAIN APP DEPOTS
addappid(2251401, 1, "764d3b25a6137d9b57a29b8b0c012befe232474a74ad6789a8dba423bed4b5a5") -- Depot 2251401
setManifestid(2251401, "3810079374275650388", 0)
