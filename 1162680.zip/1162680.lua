-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(1162680) -- Stigmatized Property | 事故物件

-- MAIN APP DEPOTS
addappid(1162681, 1, "60d9432930d437183ede89e315f21a62ad1b6e8fca04cd9b0c91e1e25d280f90") -- Stigmatized Property | 事故物件 Content
setManifestid(1162681, "6373169439097478016", 0)
