-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 2215390 Manifest
-- Name: Five Nights at Freddy's: Secret of the Mimic
-- Generated: 2025-06-14 02:31:48
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2215390) -- Five Nights at Freddy's: Secret of the Mimic

-- MAIN APP DEPOTS
addappid(2215391, 1, "d87a5534a048a1a7a81c896212cff7fa105e3104a74914bf1473552d72347211") -- Main Game Content (Windows Content)
setManifestid(2215391, "3833650524465557678", 0)

-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "550968249685141759", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
