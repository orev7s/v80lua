addappid(1299690)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1299691,0,"e98ac5c23950700f14844776585c217a0931a6f1c7b9a60f2b931129107d80ff")
setManifestid(1299691,"3038959275478678369")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]