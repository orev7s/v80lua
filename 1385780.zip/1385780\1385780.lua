addappid(1385780)
addappid(1385781,0,"fdc852879405d80a605024d7e954a9f6e5b8aa00e6216addd621bd70c3d8640f")
setManifestid(1385781,"1049983357748669583")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]