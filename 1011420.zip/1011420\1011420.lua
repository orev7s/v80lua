addappid(1011420)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"5087715316087945828")
addappid(229006)
setManifestid(229006,"1784011429307107530")
addappid(1011421,0,"ff10b73cbc06a7339d5ca1d141f0a1f04c45aea81ff15c0afc783e8728fc2e08")
setManifestid(1011421,"3782575814715309544")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]