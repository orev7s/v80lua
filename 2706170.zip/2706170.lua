-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(2706170) -- Get To Work
-- MAIN APP DEPOTS
addappid(2706171, 1, "8bac962c79191db607320de0e50e8a4e2ecbe0ae551d23c1c869c3dd541ad093") -- Depot 2706171
setManifestid(2706171, "4524887695184888788", 5332662071)