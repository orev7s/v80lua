addappid(1509960)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1509961,0,"1ea9efc77f966369354189cff52ee9d118e406ff157718c1aa540beff716a879")
setManifestid(1509961,"3786873849308285650")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]