-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(2793370) -- Shinkansen 0 | 新幹線 0号

-- MAIN APP DEPOTS
addappid(2793371, 1, "6fa32d707cc6ffb49cd0cf356a2e40e5386a2d0edac95bcd5363be541d5dfb3c") -- Main Game Content (Windows Content)
setManifestid(2793371, "1575878992717971996", 0)
