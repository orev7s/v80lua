-- Made by f1uxin, please read the read me TXT file
-- MAIN APPLICATION
addappid(253430) -- CastleMiner Z

-- MAIN APP DEPOTS
addappid(253431, 1, "05b21341555aa79fb007f9b0df955981a059ceff1bc0f79b695c7b5e4764345e") -- CMZ Base Game
setManifestid(253431, "4705789583458261140", 0)

-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- .NET 4.0 Client Profile Redist (Shared from App 228980)
setManifestid(229003, "8740933542064151477", 0)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- XNA 4.0 Redist (Shared from App 228980)
setManifestid(229012, "4353723233161159493", 0)
