-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(209100) -- Resident Evil: Operation Raccoon City

-- MAIN APP DEPOTS
addappid(209101, 1, "0cb75133d130a7f7e5291ee1f5324f3eb890004c910cec3777467cbeb4d95840") -- Resident Evil Operation Raccoon City Worldwide Content
setManifestid(209101, "419826520612959058", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Resident Evil Operation Raccoon City - Free Echo Six Prologue Mission (AppID: 210011)
addappid(210011)
addappid(210011, 1, "1dbe894edc1b1c111f6f7156c42b1ff91a94ef953210399bbc345a9b76d287cf") -- Resident Evil Operation Raccoon City - Free Echo Six Prologue Mission - Resident Evil Operation Raccoon City Free Echo Six Prologue Mission
setManifestid(210011, "8733898632540622121", 0)

-- Resident Evil Operation Raccoon City - Echo Six Expansion Pack 1 (AppID: 210012)
addappid(210012)
addappid(210012, 1, "b66f99c08b15b07edaab9c45a6bddcecbda138e31c6136c9d9543278ff7cab7a") -- Resident Evil Operation Raccoon City - Echo Six Expansion Pack 1 - Resident Evil Operation Raccoon City Echo Six Expansion Pack 1
setManifestid(210012, "5768689185529545089", 0)

-- Resident Evil Operation Raccoon City - Echo Six Expansion Pack 2 (AppID: 210013)
addappid(210013)
addappid(210013, 1, "11a1d2d64ee443e4ac618d9c0d424ee6d68bb830034f70c6b33e455d5c7b4d28") -- Resident Evil Operation Raccoon City - Echo Six Expansion Pack 2 - Resident Evil Operation Raccoon City Echo Six Expansion Pack 2
setManifestid(210013, "8905134226746428943", 0)

-- Resident Evil Operation Raccoon City - USS Wolfpack Uniforms (AppID: 210014)
addappid(210014)
addappid(210014, 1, "ae16d95c7e1b1cb592a2256129cb9c3ab82d9c1c0e6b490cf6c1c5b9a741b9c0") -- Resident Evil Operation Raccoon City - USS Wolfpack Uniforms - Resident Evil Operation Raccoon City USS Wolfpack Uniforms
setManifestid(210014, "6929097708000127585", 0)

-- Resident Evil Operation Raccoon City - Power Weapons (AppID: 210015)
addappid(210015)
addappid(210015, 1, "5d91d23e61ddb257ac0fd2902243f3c45d2d52104361cb9492487ceb235ea014") -- Resident Evil Operation Raccoon City - Power Weapons - Resident Evil Operation Raccoon City Power Weapons
setManifestid(210015, "3095055180986312337", 0)

-- Resident Evil Operation Raccoon City - Renegade Weapons (AppID: 210016)
addappid(210016)
addappid(210016, 1, "f26ba9e157c543c4b85a9fc7752522028eb99b1ab154f8c7cd573a10d420a8eb") -- Resident Evil Operation Raccoon City - Renegade Weapons - Resident Evil Operation Raccoon City Renegade Weapons
setManifestid(210016, "8165546360368386361", 0)

-- Resident Evil Operation Raccoon City - Elite Weapons (AppID: 210017)
addappid(210017)
addappid(210017, 1, "7cc5209e5fa52feca4047b105ad0a3d9762e8a104ef91f64469c6ab8cdd2233c") -- Resident Evil Operation Raccoon City - Elite Weapons - Resident Evil Operation Raccoon City Elite Weapons
setManifestid(210017, "5881169774455065208", 0)

-- Resident Evil Operation Raccoon City - Classic Weapons (AppID: 210018)
addappid(210018)
addappid(210018, 1, "38daf59157cd92a5da021ac4bdfead8f1e6221cdd7d8626589ff842a05e74b9a") -- Resident Evil Operation Raccoon City - Classic Weapons - Resident Evil Operation Raccoon City Classic Weapons
setManifestid(210018, "8775897540560642606", 0)

-- Resident Evil Operation Raccoon City - Weapon stash  Wolfpack Uniforms (AppID: 210019)
addappid(210019)
addappid(210019, 1, "be0a09b9ce70a9f38db057df6085b3d644d941a9c31595ca64bebd86ac0a1671") -- Resident Evil Operation Raccoon City - Weapon stash  Wolfpack Uniforms - Resident Evil Operation Raccoon City Weapon Stash
setManifestid(210019, "1626462342786322075", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(210010) -- Resident Evil Operation Raccoon City DLC Range
