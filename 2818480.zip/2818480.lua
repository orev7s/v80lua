-- Made by f1uxin, please read the read me TXT file
-- MAIN APPLICATION
addappid(2818480) -- Chaos Express

-- MAIN APP DEPOTS
addappid(2818481, 1, "84526ae4986ee5db4c4e4c98ddfff9d3568e795bf1c06026e6146195d83fae42") -- Main Game Content (Windows Content)
setManifestid(2818481, "8525099570184788676", 0)
