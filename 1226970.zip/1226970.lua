-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(1226970) -- Disco Simulator

-- MAIN APP DEPOTS
addappid(1226971, 1, "c0fbd201860c52f99170078e2ad565ab45aad674d818ac9d1d04552f06489046") -- Main Game Content (Windows Content)
setManifestid(1226971, "1541913702292377391", 0)
