addappid(12130)
addappid(12132,0,"b545c3df7ebf6d20468062d5faa869c4ec31340b523260ac5e9b931316d0ede6")
setManifestid(12132,"192612270653630007")
addappid(12131,0,"7d982179160594794fd6947ae7585f4767f8844335209649ed3189b080f9e0fd")
setManifestid(12131,"8486237521343385769")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]