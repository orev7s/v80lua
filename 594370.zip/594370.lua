-- Made by f1uxin, please read the read me TXT file
addappid(594370)
addappid(594371,0,"aaddaab486effbcc7af177f14440b5dd24eda08496512247f8ceaa2b44db8ef0")
setManifestid(594371,"3695747739614361523")
