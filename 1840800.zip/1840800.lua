-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(1840800) -- Headquarters: World War II

-- MAIN APP DEPOTS
addappid(1840801, 1, "ff2d8c45c35e81391fda349955290d9ec6bb2125325841f63df17a59d559fcd1") -- Depot 1840801
setManifestid(1840801, "3082249692293023471", 0)
addappid(1840802, 1, "02d4624618c1b7a31579dc43a230a772f6573474738baadaec47e45debe14e0c") -- Depot 1840802
setManifestid(1840802, "5252889925552155376", 0)

-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- .NET 4.7 Redist (Shared from App 228980)
setManifestid(229006, "1784011429307107530", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Headquarters World War II Soundtrack (AppID: 2885300)
addappid(2885300)
addappid(2885301, 1, "8cd6c3cbbf85b1862106acea365460a4000b19738321f243b3b35d8c171937e3") -- Headquarters World War II Soundtrack - Depot 2885301
setManifestid(2885301, "216694775890539814", 0)
addappid(2885302, 1, "5b20c9916cda55b04976bd43f29f4c50212f9ff248105cfafcc1c6e78c0eadde") -- Headquarters World War II Soundtrack - Depot 2885302
setManifestid(2885302, "4454539431810602419", 0)

-- Headquarters World War II - Market Garden (AppID: 3047640)
addappid(3047640)
addappid(3047640, 1, "ccef1868801a9d1b50abe1161a90efdac4950ad7f57b5b04aa4f1704da6a178e") -- Headquarters World War II - Market Garden - Depot 3047640
setManifestid(3047640, "5695189259350974259", 0)

-- Headquarters World War II - Ardennes (AppID: 3295310)
addappid(3295310)
addappid(3295310, 1, "27d046f37b398876ab45a3f5e257a42e0b33f68061aef514b37fdb669e4b3559") -- Headquarters World War II - Ardennes - Depot 3295310
setManifestid(3295310, "1730317545977498354", 0)
