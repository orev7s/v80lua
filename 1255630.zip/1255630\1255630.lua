addappid(1255630)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(1255631,0,"b007a1653790676fe5be33fe530f9fc7c28d0837b268088f2fd79a24685839df")
setManifestid(1255631,"4961736494361133056")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]