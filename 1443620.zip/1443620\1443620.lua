addappid(1443620)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1443621,0,"1830a3a2b0baf49cc942d6979631b07c2b1ad486ef05ba95d2dd169c727312ee")
setManifestid(1443621,"8209857481814464481")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]