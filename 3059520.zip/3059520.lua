-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(3059520, 1, "74712f7ff33f8367396d6daccbdb2683ce1a5d574dee4bc060144d5b9db95bc4") 
addappid(3059521, 1, "69b468d1904c13ad60ff37077c6c6350439f3e70a1df3afcfc075f41325f6b8b") 
addappid(3059522, 1, "136b91fa8f220638f0a95077f481dbcb9c6f8d5a936401ec0222ddc2cc73de68") 
setManifestid(3059522, "5001141504202113278", 50025467063)
addappid(3059523, 1, "0fefd33650cc16731c9eaa7582b567f5ab2e1dfe22480ba457f704740cb59275")
setManifestid(3059523, "5193400739583936358", 5012616053)
addappid(3059524, 1, "0f267a629c6d00a85bbea9fcadd7a8031d68da2504ea8e24821967b15c695e01") 
setManifestid(3059524, "2970295120781387815", 630539847)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") 
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") 
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3335200) -- F1 25 Iconic Bumper Pack
addappid(3335210) -- F1 25 Iconic Content Pack
addappid(3335220) -- F1 25 F1 The Movie - Chapter Scenarios
addappid(3335250) -- F1 25 Standard Starter Pack
addappid(3335260) -- F1 25 F1 75 Celebration Pack
addappid(3493790) -- F1 TV Pro 1-Month Subscription
addappid(3493820) -- F1 25 Iconic Edition Upgrade
addappid(3493830) -- F1 25 Iconic Edition Upgrade
addappid(3546340) -- F1 25 APXGP Team Pack
addappid(3601380) -- F1 25 - EA Play Trial Key