addappid(1378990)
addappid(1378991,1,"f50ac282f4e8cd6aa1b2477faf75a2d4ac2257737e16ccc8c08533eed66df9c9")
setManifestid(1378991,"6531755016801697470",0)
addappid(1378992,1,"0472c66839b11731f139af60a48c4d4295051038aa705924072f4f5931162592")
setManifestid(1378992,"7776315403696891647",0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]