-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(231200) -- Kentucky Route Zero

-- MAIN APP DEPOTS
addappid(231203, 1, "828bdc92db9b07fd9ded2bc02e1c73e5e64020e213935474927fcb790aa609c7") -- KRZ Windows
setManifestid(231203, "4423469540433988208", 0)
addappid(231204, 1, "93550e0edd386cafaf41213830db2f7de822b7ae4b293a6c874eacd85f7ed57a") -- KRZ Mac
setManifestid(231204, "1752996963759455817", 0)
addappid(231205, 1, "d082b24835672e720a7b811bdd8a9981cb22f3680d53df44c0811185f2429505") -- KRZ Linux
setManifestid(231205, "7815316056948468833", 0)

-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
