-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(2235200) -- Neon Abyss 2

-- MAIN APP DEPOTS
addappid(2235201, 1, "64b6a7741dff52341709bb548d844f5cbfb4d551a165eba90db90d49ca88586c") -- Depot 2235201
setManifestid(2235201, "6493388818198407077", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3821980) -- Neon Abyss 2 - Supporter Pack

-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Neon Abyss 2 Original Soundtrack (AppID: 3821760) - missing depot keys
-- addappid(3821760)
