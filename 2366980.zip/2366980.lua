-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(2366980) -- Thank Goodness You're Here!

-- MAIN APP DEPOTS
addappid(2366981, 1, "436c3a988f36c4fc3f8bebe8661ad1a4ce467bfad673d0a76c1cc174a44792f0") -- Main Game Content (Windows Content)
setManifestid(2366981, "4960030984262173479", 0)
addappid(2366982, 1, "c3653cc3f2c3580882e504a12cad17115a9b5574f3a569a6625eddc03a1a7a02") -- Game Content (Linux Binaries)
setManifestid(2366982, "4467394041721781619", 0)
