(It is fine to delete/not add this TXT file).

Don't add this file with SteamTools if this is in a "Manifest & Lua file zip", its fine to add, it will do nothing to the game, but i believe it may add this file to your steam folders multiple times so it may take up extra space, so its recommended you just don't add it or just delete this after reading it.

And you should really check out my server (https://discord.gg/NmmpgnAgen), we show all of this manifest and lua stuff and just in general everything about piracy and very soon we will have things NO other server has/shows so stay tune! And all of it is for free, we do not ask for anything, we just show info/Stuff that we found.

This file was created by f1uxin, enjoy!

The redistribution/sharing of these files are NOT allowed, you can share it with a friend but you must not redistribute it and claim it is your own, i work extremely hard on these so people stealing them really upsets me if you do want to redistribute it you can add me on discord "@F1uxin" and we can talk about it

Socials:

My Discord/Discord Server - User: @f1uxin | My Server : https://discord.gg/NmmpgnAgen

Discord Servers: Manifest Manager @ SushiTools https://discord.gg/sushitools / https://discord.gg/N46D8CTPZE 

Discord Servers: Server/Manifest Manager @ ZayTools https://discord.gg/zaytools / https://discord.gg/uAHmFw9AhP

Youtube - https://www.youtube.com/@F1uxin-yt

TikTok - https://www.tiktok.com/@f1uxin

Instagram - https://www.instagram.com/f1uxin/


P.S I AM NOT F1uxin_sells or anything like that everything i show is free, i go by just @F1uxin, F1uxin, used to go by Raid3rV2, and i don't sell anything he may just be using my name or we have close usernames but that IS NOT ME.

Servers cleared for sharing these files

SushiTools - https://discord.gg/sushitools / https://discord.gg/N46D8CTPZE
ZayTools - https://discord.gg/zaytools / https://discord.gg/uAHmFw9AhP
Synapse services - https://discord.gg/BrXWMQnkSa
GOG Pirate - https://discord.gg/tvaupnWrkJ