-- Made by f1uxin, please read the read me TXT file.
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship
addappid(2201320) -- Date Everything!

-- MAIN APP DEPOTS
addappid(2201321, 1, "173bd7627cf18657ea58531a712c028386d6385bfe84eb20b756333989d603d3") -- Depot 2201321
setManifestid(2201321, "1491398690208743097", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3043460) -- Date Everything - Early Bird DLC
addappid(3043470) -- Date Everything - Lavish DLC
