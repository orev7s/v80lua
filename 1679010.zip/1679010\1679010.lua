addappid(1679010)
addappid(1679011,0,"c39d07cf3718bd76f33cf0c8e0286ef06ce680c44fd670abff85ecf345822f09")
setManifestid(1679011,"1102855167777427099")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]