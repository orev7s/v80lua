-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(3076240) -- True Nightmare - Roadside Сafe
-- MAIN APP DEPOTS
addappid(3076241, 1, "afcd43434aacd18423b38725e878fd802a25a9e615fc9cece435ffce929d7156") -- Depot 3076241
setManifestid(3076241, "1561185293933163780", 2705318961)