-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(603850, 1, "6ac925a6a8c26162e907bd1ca86830b899a47214c19569a4be236215fc4a5fce") -- Age of History II
-- MAIN APP DEPOTS
addappid(603851, 1, "03e3821f3ac71152e806701403e0c9252f4839c75291b5b3a585aacd9e962080") -- Age of Civilizations II Content
setManifestid(603851, "2654718545113390213", 477728650)
addappid(603852, 1, "25d7f7c9f3765d54ef8c92a699fe990ee5a27de93489240ee9f20d80a84c6ebe") -- Age of Civilizations II - Win32
setManifestid(603852, "4901373421410482285", 362759517)
addappid(603853, 1, "ed5f7d8ff33e68853445666e40b2b2e17085a515184b7438c527ccf46340effc") -- Age of Civilizations II - Mac
setManifestid(603853, "3901882567425026533", 167715996)
-- SHARED DEPOTS (from other apps)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- OpenAL 2.0.7.0 Redist (Shared from App 228980)
setManifestid(229020, "5799761707845834510", 810085)