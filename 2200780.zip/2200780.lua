-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(2200780) -- My dream setup

-- MAIN APP DEPOTS
addappid(2200781, 1, "29406521ce5331ba5fdd43d43177449ef8464b67e6b6de257c894a5dbdb26cb1") -- Depot 2200781
setManifestid(2200781, "7064180011600605244", 0)
addappid(2200782, 1, "112155b443b5d2147602ac203014c4d4baeb01b241d22704420be8135a38f04a") -- Depot 2200782
setManifestid(2200782, "4455528104888999195", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2637930) -- My Dream Setup - Pets DLC
addappid(2926420) -- My Dream Setup - Bathroom DLC
addappid(2926430) -- My Dream Setup - Kitchen DLC
addappid(3371380) -- My Dream Setup - Garage DLC
