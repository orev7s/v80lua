addappid(1145960)
addappid(1145961,0,"eb19d9c4303dc47b702196c458ac3167859199c53d1d786fe696bd9a8bd273cd")
setManifestid(1145961,"9119154406110597936")
addappid(1145962,0,"8072e8d1c1af7a5c7d5b3d4cd0909ee665c8b9d632f8e16df3b62690e2eb17c0")
setManifestid(1145962,"8357986583237231895")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]