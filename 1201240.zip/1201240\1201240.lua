addappid(1201240)
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228987)
setManifestid(228987,"4302102680580581867")
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229004)
setManifestid(229004,"5220958916987797232")
addappid(229005)
setManifestid(229005,"7992454656023763365")
addappid(229006)
setManifestid(229006,"1784011429307107530")
addappid(1201241,0,"85566eaa31209ac31dde217a058f58e810356a8df255c9a7c4c8b31749858248")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]