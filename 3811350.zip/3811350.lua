-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(3811350)
addappid(3837980)
addappid(3838000)
addappid(3838010)
addappid(3838020)
addappid(3811351,0,"db9426a87dfad02512eec2626bbe370106b1c71b9e3c137ea4a0609370f3111d")
setManifestid(3811351,"6099897891372466385")