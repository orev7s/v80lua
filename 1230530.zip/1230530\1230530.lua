addappid(1230530)
addappid(1230531, 1, "25f3af482734dc6c7e43a9a45c3c959c4c9988a764396d7dace988ef9622b312")
setManifestid(1230531, "2832090510677438804", 0)
addappid(1230532, 1, "063151f238f826db2cc0391307ffd1970c31dcba8bdea7d34043f17023d27725")
setManifestid(1230532, "231660441489474495", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]