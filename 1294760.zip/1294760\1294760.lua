addappid(1294760)
addappid(1294761,1,"8B64986DE50B2544DA769E174EAC8B083DDCA7E9D9BC080B9122A7C4ED0C5627")
setManifestid(1294761,"7964226888408683652",0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]