-- Made By @F1uxin
-- MAIN APPLICATION
addappid(3164500) -- Schedule I

-- MAIN APP DEPOTS
addappid(3164501, 1, "81d0de07788de885787b0519b9dabf51618be6cba9124497decf572ac96624f4") -- Main Game Content (Windows Content)
setManifestid(3164501, "4917957940192610936", 0)
