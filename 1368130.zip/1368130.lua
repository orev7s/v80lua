-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(1368130) -- Park Beyond

-- MAIN APP DEPOTS
addappid(1368131, 1, "944c9fe646bce1f48127a62c82b40fc6f3524264b3b8b8c42d0b574768cee88d") -- Main Game Content (Windows Content)
setManifestid(1368131, "6788976109167749415", 0)

-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2138730) -- Park Beyond Beyond eXtreme - Theme World 
addappid(2138731) -- Park Beyond Beyond the Depths - Theme World
addappid(2138732) -- Park Beyond - Beyond the Skies of Arabia - Theme World
addappid(2138733) -- Park Beyond - Chicken Run Dawn of the Nugget - Theme World
addappid(2138734) --  Park Beyond Annual Pass Bonus Coaster Car Set
addappid(2138735) --  Park Beyond Zombeyond Impossification Set 
addappid(2138736) --  Park Beyond PAC-MAN Impossification Set 
addappid(2138737) -- Park Beyond LITTLE NIGHTMARES II Ride
addappid(2138738) -- Park Beyond ENGLISH GARDEN Set
addappid(2138739) -- Park Beyond Closed Beta Bonus Golden Omnicar
addappid(2138754) -- Park Beyond BEYOND SEAS Set
addappid(2144730) -- Park Beyond Annual Pass 
addappid(3093080) -- Park Beyond Golden Pass
