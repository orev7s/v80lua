addappid(1368130)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1368131,0,"944c9fe646bce1f48127a62c82b40fc6f3524264b3b8b8c42d0b574768cee88d")
setManifestid(1368131,"6788976109167749415")
addappid(1368132)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]