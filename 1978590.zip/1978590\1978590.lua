addappid(1978590)
addappid(1978591,0,"97fd1a955a81c6d401ffd49816ff8ffa4ab5147e00f909d06d946cfdd6204f1d")
setManifestid(1978591,"1246271747967493332")
addappid(1978592)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]