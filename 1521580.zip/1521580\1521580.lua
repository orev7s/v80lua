addappid(1521580)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1521581,0,"4e6182d3021db3ba34b32c18a8fc41f1ea6b19103d0d64f00d70cf98876b76b2")
setManifestid(1521581,"358239648044608692")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]