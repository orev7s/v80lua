-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy

-- MAIN APPLICATION
addappid(911400) -- Assassin's Creed III Remastered

-- MAIN APP DEPOTS
addappid(911401, 1, "c04740de17320ddf2881d8e88424ccb3850b951c06acdf8de1da26decd287cd9") -- AC3ACL Content
setManifestid(911401, "3670596370283469393", 0)

-- SHARED DEPOTS (from other apps)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
setManifestid(1716751, "818295193716041715", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(985980) -- Assassins Creed 3 Remastered - Uplay Activation
