addappid(1605220)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(1605221,0,"d9b810744ceded0de8e527039bd842c9931c76da38fb1683230642fd71842411")
setManifestid(1605221,"8378978086133080433")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]