addappid(1066110)
addappid(1066111,0,"254ef638f159d516ebe5d33c3b10947d76e5380ff2e830dfb4c45b9f2c1dbe89")
setManifestid(1066111,"6361027378521495167")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]