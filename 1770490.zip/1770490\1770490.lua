addappid(1770490)
addappid(1770491,0,"467ee21f59e4c53ffa20ffd40ad676b10491510ca68035cb1e87101de0796346")
setManifestid(1770491,"1138502036414274017")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]