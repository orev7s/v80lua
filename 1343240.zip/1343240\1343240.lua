addappid(1343240)
addappid(1343241, 1, "ad9a8b0ab098a95291acac64ad83e29e116602c5adb0c53f7fb690b853463eca")
setManifestid(1343241, "9214817824678985281", 0)
addappid(2118360, 1, "837e400e70207d8424743048821b734c6bf2764bef515a95ad6a4e2ee4e236ea")
setManifestid(2118360, "4255623278977587501", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]