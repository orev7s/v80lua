addappid(1649950)
addappid(1649952,0,"49c2380d0c7954477872885734ff457ce8d952573a960930a87f60ded2a95f09")
setManifestid(1649952,"7553101435880944353")
addappid(1649951)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]