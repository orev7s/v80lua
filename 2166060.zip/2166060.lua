-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(2166060) -- Amanda the Adventurer

-- MAIN APP DEPOTS
addappid(2166061, 1, "814ece087ba954ca208b3a2aafded05134d3cd5854a6677001596c37b55e1f5e") -- Main Game Content (Windows Content)
setManifestid(2166061, "6931374596618173864", 0)
