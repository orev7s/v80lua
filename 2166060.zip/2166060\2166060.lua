-- Made By @F1uxin
-- MAIN APPLICATION
addappid(2166060) -- Amanda the Adventurer

-- MAIN APP DEPOTS
addappid(2166061, 1, "814ece087ba954ca208b3a2aafded05134d3cd5854a6677001596c37b55e1f5e") -- Main Game Content (Windows Content)
setManifestid(2166061, "6931374596618173864", 0)
