-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪username - f1uxin, on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy / https://discord.gg/m8PxjTwrnv
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(2228490) -- Atomic Owl
-- MAIN APP DEPOTS
addappid(2228491, 1, "4d286fcfa58c99b7c2b019ca0bee2825f92e9439e544a15be1d2e62f185719fd") -- Depot 2228491
setManifestid(2228491, "8700982112008696902", 1841893438)