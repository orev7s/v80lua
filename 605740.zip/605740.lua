-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(605740) -- Flashing Lights

-- MAIN APP DEPOTS
addappid(605741, 1, "95d3d0ace153500ff96a04353c87950fc4420523d33bd980470ba1bcc5513ec2") -- Flashing Lights Content
setManifestid(605741, "5612615984127991878", 0)
addappid(605742, 1, "a8211cb137d2735d7ff465f3f245198f857855a1e31a0ed5d1cbd54f4e795989") -- Flashing Lights Depot MAC
setManifestid(605742, "476368829162412071", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2449260) -- Flashing Lights Pickup Truck Triple Pack (Police, Fire, EMS)
addappid(2649400) -- Flashing Lights - Visor Lights
addappid(2649410) -- Flashing Lights Beast Swat Truck DLC
addappid(2649420) -- Flashing Lights Emergency Response Lightbar Collection
addappid(2649430) -- Flashing Lights Thunder Sport Sedan Pack (Police, Fire, EMS)
addappid(3051230) -- Flashing Lights Interceptor SUV Pack (Police, Fire, EMS)
addappid(3640340) -- Flashing Lights BUCK - Police, Fire, Rescue Pack
