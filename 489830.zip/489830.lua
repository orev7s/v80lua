-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(489830) -- The Elder Scrolls V: Skyrim Special Edition

-- MAIN APP DEPOTS
addappid(489831, 1, "a26da9ff1f2af2345ebfad1bd62bcb9ed1cbe6afcf4ced92d1a5fa944242b825") -- Skyrim Special Edition disk
setManifestid(489831, "8442952117333549665", 0)
addappid(489832, 1, "c6c5e29627073060ccf9fc8c6c9c7ec86dfdf16b51b3d1fbb0a2e7c1ad9f533e") -- Skyrim Special Edition core
setManifestid(489832, "8042843504692938467", 0)
addappid(489833, 1, "7c5e75890b4f59b4be2d3b68c88abad8b23b159a23bf25a00c5c3a4748752f36") -- Skyrim Special Edition exe
setManifestid(489833, "1914580699073641964", 0)
addappid(489834, 1, "eeb89a10bdac7b9b83b6d03cffd9c6225d9041a8130ea52ff0f96b7f6174e857") -- Skyrim Special Edition french
setManifestid(489834, "8562891139598763344", 0)
addappid(489835, 1, "ed764444d4ab7b8d2f98100ddd951659a57f5df3c8825b2d14df99f8ab1b6447") -- Skyrim Special Edition italian
setManifestid(489835, "9152699258833967999", 0)
addappid(489836, 1, "1ebc81b82a20b369c9c0335ed96a206b81b46846f2dc9a9f457e748d1ec48045") -- Skyrim Special Edition german
setManifestid(489836, "2360664012913025776", 0)
addappid(489837, 1, "b2cf2cc8cadda88f33e707b79fb2b95b458553a6d768f7d1ab9ef657a18fa90c") -- Skyrim Special Edition spanish
setManifestid(489837, "8402094395440824039", 0)
addappid(489838, 1, "807c9db0782a0d03abbe9f123179b7428bb952dcb3c127abcb0455d65d772cdd") -- Skyrim Special Edition russian
setManifestid(489838, "3873588632592923754", 0)
addappid(489839, 1, "19028a477ba63d9a671eed7c6590e607370062aa3bf59446cc8b79022ab64de4") -- Skyrim Special Edition polish
setManifestid(489839, "176511637554234126", 0)
addappid(544860, 1, "b0cdbf6da886a9083687985cffde7be07f2183afe615b10af508ff8ded2f8408") -- Skyrim Special Edition chinese
setManifestid(544860, "8476536650815851202", 0)
addappid(544861, 1, "586061c4ba80f7bf1fcf1da170aeffeacdc20869d4d5d622e69c935f42c26630") -- Skyrim Special Edition japanese
setManifestid(544861, "3494476046078906882", 0)

-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(598120) -- The Elder Scrolls V Skyrim Special Edition - Creations
addappid(1746860) -- The Elder Scrolls V Skyrim Anniversary Upgrade
