addappid(1269690)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229007)
setManifestid(229007,"4477590687906973371")
addappid(229012)
setManifestid(229012,"4353723233161159493")
addappid(229020)
setManifestid(229020,"5799761707845834510")
addappid(229030)
setManifestid(229030,"1043465440436835055")
addappid(1269691,0,"696234cf82c6a339615e1f4a1642e0fd261a86eeb90d6420e89a0cbcd04c0676")
setManifestid(1269691,"8091469352490245332")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]