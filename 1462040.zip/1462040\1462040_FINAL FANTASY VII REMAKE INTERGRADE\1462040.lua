addappid(1462040)
addappid(1462041, 1, "4e299a23f9a767cbb2ea9a71d2fd2334b46e66904c51f2478e1b54994e7d33a9")
setManifestid(1462041, "8857088838923627526", 0)
addappid(1462043, 1, "85dd87a3f14448b8659faa0acf1ec19c4213ea1096601adec258a00910b31cbb")
setManifestid(1462043, "1175626494867215330", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]