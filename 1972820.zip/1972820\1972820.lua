addappid(1972820)
addappid(1972821,0,"f50f15a0524c07af487d549b7faf4149207d0e9840b7d01b66c3178e3ee1f434")
setManifestid(1972821,"1221664997515325118")
addappid(1972822,0,"55c19ecae09644af5e2b1474a0792921ad3fdc58be4a4056a66cb9910438675f")
setManifestid(1972822,"550421418880351263")
addappid(1972823,0,"d3434c1c36485ea620f97460da0efd769c55867313f9bf0d1eada4f0dc543012")
setManifestid(1972823,"3787896368882188812")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]