-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(38410) -- Fallout 2

-- MAIN APP DEPOTS
addappid(38411, 1, "aff49414c4988ff4442db9a3c83457bf7bb4f359a8273da808dabaa0da38d7f2") -- fallout 2 content
setManifestid(38411, "4227213224313177632", 0)
addappid(38412, 1, "248ad047e5040b910c8209c65c51264d3c8ae11619c8bef85d88717a9c2a9128") -- Fallout 2 French
setManifestid(38412, "6439038876434951674", 0)
addappid(38413, 1, "cf40d566acc333b23b0c7df962ce5884d4aee236c8d8594e5797be0dfb81d776") -- Fallout 2 German
setManifestid(38413, "8624699516625943175", 0)
addappid(38414, 1, "8a50c6c647ca445d18d455421511a37d090420d715a3ef85e768256f0ff50a01") -- Fallout 2 Depot New Base
setManifestid(38414, "784733385950245239", 0)
addappid(38415, 1, "2e96205233faf6d6277afa08afb17363506de014af1e8c450d925480564fbcc7") -- Fallout 2 Depot New English
setManifestid(38415, "6840570039060968053", 0)
addappid(38416, 1, "b6b272151daf3af00be57df71c61003c2341c25a1d09eeaa16b579b697dcc15f") -- Fallout 2 Depot New French
setManifestid(38416, "2857333952655605966", 0)
addappid(38417, 1, "02ad04f9e2f3bd4b4db301555f5049e8d0a02123894814a9aec6e47439f57eb4") -- Fallout 2 Depot New German
setManifestid(38417, "4403699980111176369", 0)

-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- .NET 4.0 Redist (Shared from App 228980)
setManifestid(229002, "7260605429366465749", 0)
