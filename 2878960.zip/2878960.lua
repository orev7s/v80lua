-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(2878960) -- WWE 2K25

-- MAIN APP DEPOTS
addappid(2878961, 1, "06400ef21bacfd625a917c8964e13740059333d2173dc2496357ef23db97f483") -- Depot 2878961
setManifestid(2878961, "1782663834053980808", 0)

-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "550968249685141759", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3331100) -- WWE 2K25 Wyatt Sicks Pack
addappid(3401590) -- WWE 2K25 Deadman Edition Bonus Pack
addappid(3401600) -- WWE 2K25 MyFACTION Persona Card - The Rock (NoD)
addappid(3401610) -- WWE 2K25 The Bloodline Edition Bonus Pack
addappid(3401620) -- WWE 2K25 WrestleMania 41 Pack
addappid(3401630) -- WWE 2K25 SuperCharger
addappid(3401640) -- WWE 2K25 MyRISE Boost
addappid(3401650) -- WWE 2K25 New Wave Pack
addappid(3401660) -- WWE 2K25 Dunk  Destruction Pack
addappid(3482630) -- WWE 2K25 Season Pass
addappid(3482640) -- WWE 2K25 Ringside Pass
addappid(3482860) -- WWE 2K25 Superstar Mega-Boost
