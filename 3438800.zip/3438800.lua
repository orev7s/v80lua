-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪username - f1uxin, on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy / https://discord.gg/m8PxjTwrnv
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(3438800, 1, "0e70cfe08e6b23238f88be655dedc6ae4ec07589cfbea0443acfe4cb5453c0ea") -- Doodle Empires
-- MAIN APP DEPOTS
addappid(3438801, 1, "d7c3577cfbad3d5beb7a8dc46c1305693679a43e287b97f73599ea233100113b") -- Depot 3438801
setManifestid(3438801, "637196326815590460", 1130861527)