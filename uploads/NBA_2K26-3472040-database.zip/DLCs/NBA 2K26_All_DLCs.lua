addappid(3657590, 1)
addappid(3657600, 1)
addappid(3657610, 1)
addappid(3657620, 1)

--made by v80qk on discord