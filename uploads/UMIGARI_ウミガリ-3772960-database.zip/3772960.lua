----------------------------
addappid(3772960)
addappid(3772961,0,"2cf04aa079347c28e4bd8e9fd4b600d7687adfd37a82df9a34b0e271b1716af0")

--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]
----------------------------