----------------------------
addappid(3762550)
addappid(3762550,1,"19e7f583bc01e2787d93610fb0403c7e7af1c2ea643a1c0b9ee2121559db517e")
addappid(3762551,0,"bd117b3c71f5677047fba24c3718c6f55a4ba03e9c2219df6576e38a44c040fd")

--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]
----------------------------