-- 1645630's Lua and Manifest Created by Morrenus
-- FEROCIOUS
-- Created: December 04, 2025 at 20:35:44 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1645630) -- FEROCIOUS
-- MAIN APP DEPOTS
addappid(1645631, 1, "cd1a9d02b5f7edbe2bfc34b599ec8fa0b46624c0e8fff62c9fbb1c903bfdb2b4") -- Depot 1645631
setManifestid(1645631, "3487169449415699685", 56122429160)