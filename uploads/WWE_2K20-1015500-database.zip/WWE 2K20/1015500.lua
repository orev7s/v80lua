-- 1015500's Lua and Manifest Created by Morrenus
-- WWE 2K20
-- Created: October 01, 2025 at 08:17:29 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 8
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1015500) -- WWE 2K20
-- MAIN APP DEPOTS
addappid(1015501, 1, "2032c14e73518f2ce857dc8ae1cdf69282222545a381378ca0e24e38334846f2") -- Keep Content
setManifestid(1015501, "6798643016666386517", 54443609918)
-- SHARED DEPOTS (from other apps)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1132780) -- WWE 2K20 Accelerator
addappid(1133550) -- WWE 2K20 MyPLAYER KickStart
addappid(1133551) -- WWE 2K20 SmackDown 20th Anniversary Edition
addappid(1146520) -- WWE 2K20 Originals Bump in the Night
addappid(1146521) -- WWE 2K20 2K ORIGINALS WASTELAND WANDERERS
addappid(1146522) -- WWE 2K20 Originals Southpaw Regional Wrestling
addappid(1146523) -- WWE 2K20 2K ORIGINALS EMPIRE OF TOMORROW
addappid(1152560) -- WWE 2K20 Backstage Pass