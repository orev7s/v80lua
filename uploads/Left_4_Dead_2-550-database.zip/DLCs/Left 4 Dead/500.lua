addappid(500, 1)

--made by v80qk on discord