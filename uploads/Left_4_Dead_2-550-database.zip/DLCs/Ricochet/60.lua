addappid(60, 1)

--made by v80qk on discord