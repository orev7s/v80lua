addappid(20, 1)

--made by v80qk on discord