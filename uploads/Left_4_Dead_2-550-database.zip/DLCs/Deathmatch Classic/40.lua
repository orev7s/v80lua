addappid(40, 1)

--made by v80qk on discord