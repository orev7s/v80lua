addappid(30, 1)

--made by v80qk on discord