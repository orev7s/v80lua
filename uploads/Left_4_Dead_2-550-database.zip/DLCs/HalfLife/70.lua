addappid(70, 1)

--made by v80qk on discord