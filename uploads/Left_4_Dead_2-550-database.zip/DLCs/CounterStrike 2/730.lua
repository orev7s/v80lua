addappid(730, 1)

--made by v80qk on discord