addappid(300, 1)

--made by v80qk on discord