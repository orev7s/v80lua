addappid(220, 1)

--made by v80qk on discord