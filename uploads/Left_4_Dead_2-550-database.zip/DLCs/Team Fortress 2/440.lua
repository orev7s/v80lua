addappid(440, 1)

--made by v80qk on discord