addappid(570, 1)

--made by v80qk on discord