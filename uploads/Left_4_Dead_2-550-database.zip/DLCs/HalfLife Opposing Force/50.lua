addappid(50, 1)

--made by v80qk on discord