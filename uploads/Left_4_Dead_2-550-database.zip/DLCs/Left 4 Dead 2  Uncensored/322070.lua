addappid(322070, 1)

--made by v80qk on discord