addappid(400, 1)

--made by v80qk on discord