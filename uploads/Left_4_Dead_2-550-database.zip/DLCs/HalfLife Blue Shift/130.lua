addappid(130, 1)

--made by v80qk on discord