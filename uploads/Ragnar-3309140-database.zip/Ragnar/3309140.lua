-- 3309140's Lua and Manifest Created by Morrenus
-- Ragnar
-- Created: November 30, 2025 at 05:48:34 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3309140) -- Ragnar
-- MAIN APP DEPOTS
addappid(3309142, 1, "db03ce374959f4acdada7579035c518353ae0f1ef03ef938a60b3163ab19309d") -- Depot 3309142
setManifestid(3309142, "5929882590529043027", 18007446393)
addappid(3309143, 1, "427ecd47aa845e422019125221f1f5cbe7b90622567412f521f6245ff77eb88d") -- Depot 3309143
setManifestid(3309143, "6200576319558847089", 18186238524)