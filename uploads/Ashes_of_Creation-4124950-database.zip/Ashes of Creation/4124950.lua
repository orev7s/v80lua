-- 4124950's Lua and Manifest Created by Morrenus
-- Ashes of Creation
-- Created: December 12, 2025 at 08:18:45 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4124950) -- Ashes of Creation
-- MAIN APP DEPOTS
addappid(4124951, 1, "57aa14570ec1e55fda625d0b743b855face3b41ec87f04143bc7784a401b84b8") -- Depot 4124951
setManifestid(4124951, "2868098841486467808", 149837593680)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)