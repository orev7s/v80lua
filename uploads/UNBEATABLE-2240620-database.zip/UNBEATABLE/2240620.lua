-- 2240620's Lua and Manifest Created by Morrenus
-- UNBEATABLE
-- Created: December 09, 2025 at 14:38:57 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(2240620) -- UNBEATABLE
-- MAIN APP DEPOTS
addappid(2240621, 1, "80b19fbd6c9057548e637a2e743cb48d753af68fa08227be8200dc8e3cc33753") -- Depot 2240621
setManifestid(2240621, "8439936538591813180", 34525636029)
-- DLCS WITH DEDICATED DEPOTS
-- UNBEATABLE - Breakout Edition Upgrade (AppID: 3951650)
addappid(3951650)
addappid(3951650, 1, "706689526031d649f39c7ce4ed4c578bfffbc570afae867b5c7464e12b7259ed") -- UNBEATABLE - Breakout Edition Upgrade - Depot 3951650
setManifestid(3951650, "4379137370641358211", 33766292)