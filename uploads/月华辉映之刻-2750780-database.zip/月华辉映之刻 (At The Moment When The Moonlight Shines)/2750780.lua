-- 2750780's Lua and Manifest Created by Morrenus
-- 月华辉映之刻
-- Created: December 10, 2025 at 06:31:25 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2750780) -- 月华辉映之刻
-- MAIN APP DEPOTS
addappid(2750781, 1, "9cadd04d7b31e6009784c7ac33576344329cd56636774e4a5b77e0b2931502b4") -- Depot 2750781
setManifestid(2750781, "7343045952163728535", 7823186590)