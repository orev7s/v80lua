-- 3105890's Lua and Manifest Created by Morrenus
-- PIONER
-- Created: December 17, 2025 at 09:02:36 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 4
-- Total DLCs: 0 (1 excluded)
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(3105890) -- PIONER
-- MAIN APP DEPOTS
addappid(3105891, 1, "41388d8391e1158182588d11836e34b4e997721800c682092454aca81a282acd") -- Depot 3105891
setManifestid(3105891, "8475108272551802320", 100644837941)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Pioner - Deluxe Edition (AppID: 4241040) - missing depot keys
-- addappid(4241040)