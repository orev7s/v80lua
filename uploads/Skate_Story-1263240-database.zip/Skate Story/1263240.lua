-- 1263240's Lua and Manifest Created by Morrenus
-- Skate Story
-- Created: December 08, 2025 at 12:22:20 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1263240) -- Skate Story
-- MAIN APP DEPOTS
addappid(1263241, 1, "72af65204654f278d7a7c9951ca861d535f49b3a65248bdafb2918820e93e1d6") -- Depot 1263241
setManifestid(1263241, "5404951760766501372", 11708551327)
addappid(1263242, 1, "36b34df272a59e83258af05bf2f88c2e868bfb7074bff1b3e0aa412170c1e12e") -- Depot 1263242
setManifestid(1263242, "2288495371626606142", 11997726669)