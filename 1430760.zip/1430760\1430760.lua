addappid(1430760)
addappid(1430761,0,"63fed22ae0423ecd4bfea90e201fc98d953636578f824bbb610442283ad1b8cd")
setManifestid(1430761,"865191799740055950")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]