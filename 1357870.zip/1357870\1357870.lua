addappid(1357870)
addappid(1357871,0,"1c82a6b5aaf883617aa58e6f72873cc7bc1286db03c601fe3817ca8cd288d7bd")
setManifestid(1357871,"317724318893810275")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]