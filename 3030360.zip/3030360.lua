-- Made By @F1uxin
-- MAIN APPLICATION
addappid(3030360) -- Puppet Team

-- MAIN APP DEPOTS
addappid(3030362, 1, "7030120465b819a52103de650970f5cc2e1da5bc3bc4ceb9246eba6b5e63f5a7") -- Game Content (Linux Binaries)
setManifestid(3030362, "3539976087241675074", 0)
