-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(1403310) -- Garden Simulator

-- MAIN APP DEPOTS
addappid(1403311, 1, "21a51d2699f4399ab986e729bf47a2406a756ea5fce3fa65da47c46a157ded87") -- Main Game Content (Windows Content)
setManifestid(1403311, "976096695374462512", 0)
