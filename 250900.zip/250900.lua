-- Made by f1uxin, please read the read me TXT file
-- MAIN APPLICATION
addappid(250900) -- The Binding of Isaac: Rebirth

-- MAIN APP DEPOTS
addappid(250902, 1, "ad8a374561fd8769aac243917372237482caa7a94aafbcdaa45adc4208916b7a") -- Win32
setManifestid(250902, "4994611894646808503", 0)
addappid(250903, 1, "40e55a223f52c70c427117df402eee6152118a11d9c17f28bc849252cde5337b") -- Linux
setManifestid(250903, "367036646469636831", 0)
addappid(250904, 1, "210036fb298fd6b8c2d227c9a803614edb0a6e2d9949968b46321c25d298155d") -- OSX
setManifestid(250904, "1942665726573884808", 0)

-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 0)

-- DLCS WITH DEDICATED DEPOTS
-- The Binding of Isaac Rebirth - Soundtrack (AppID: 322660)
addappid(322660)
addappid(322660, 1, "cc56b394152b0d78bb4d6e147716a463b70ae573e8cf6f2ef28ebe359f97860d") -- The Binding of Isaac Rebirth - Soundtrack - Rebirth, Afterbirth, Afterbirth+ OST
setManifestid(322660, "5499930042188336604", 0)
addappid(322661, 1, "6c8f5e0423cd4e9f34a9ff9b9f4bc95464e3fd93f03bb699be87ec06402cefc0") -- The Binding of Isaac Rebirth - Soundtrack - Repentance OST
setManifestid(322661, "4078660603895799229", 0)

-- The Binding of Isaac Afterbirth (AppID: 401920)
addappid(401920)
addappid(250905, 1, "42e1eb359f37040d6a198d7b0aef616b100b9ac5405667f89c15aeaf217a47ed") -- The Binding of Isaac Afterbirth - Afterbirth Win32
setManifestid(250905, "1709017229885880564", 0)
addappid(250906, 1, "d83d1ccc6ec53ebb8724d9dbaa3fd1b7d417fef3dcf9f9260d5fcd49b3dc771e") -- The Binding of Isaac Afterbirth - Afterbirth Linux
setManifestid(250906, "274330258716671855", 0)
addappid(250907, 1, "748829017a20ec0570ef232ad6b5b12539ebe511fcf85c494ac7856e5015e48a") -- The Binding of Isaac Afterbirth - Afterbirth OSX
setManifestid(250907, "1258401244940465981", 0)

-- The Binding of Isaac Afterbirth (AppID: 570660)
addappid(570660)
addappid(250908, 1, "5a6d9cc4f7864cadb061e3c6f91f8c3f2ee7509f31db0c926f7c4066ff737366") -- The Binding of Isaac Afterbirth - Afterbirth Plus Win32
setManifestid(250908, "7333987924869605149", 0)
addappid(250909, 1, "80ee47ebd3ec21428656ac288e189aeb671034dbed479347ac2b553f822d5899") -- The Binding of Isaac Afterbirth - Afterbirth Plus Linux
setManifestid(250909, "5041024818858406088", 0)
addappid(250910, 1, "6624d0874bc231a99b0f107bd111eaaaac393405c68773a6641e4e82f1232172") -- The Binding of Isaac Afterbirth - Afterbirth Plus OSX
setManifestid(250910, "1079085999450784617", 0)

-- The Binding of Isaac Repentance (AppID: 1426300)
addappid(1426300)
addappid(250911, 1, "91f532dc0f4bd27b98705c41e9c5b1171df5c8254c92409b9faf40bbe8708639") -- The Binding of Isaac Repentance - Repentance Win32
setManifestid(250911, "7652847940910762229", 0)

-- The Binding of Isaac Repentance (AppID: 3353470)
addappid(3353470)
addappid(3353471, 1, "b1b260b7116c50497bfe54b1df79bc30dbca77c3d8d7d2698f96657fdb2829e8") -- The Binding of Isaac Repentance - Depot 3353471
setManifestid(3353471, "976917688041015347", 0)
