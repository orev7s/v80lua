addappid(1177660)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229006)
setManifestid(229006,"1784011429307107530")
addappid(229030)
addappid(1177661,0,"393ba5a9892f5aaa76eaadeeaf4a7aacbb1b3952cf33d3d6bf457e33f8944355")
setManifestid(1177661,"3934650465635911635")
addappid(1412230)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]