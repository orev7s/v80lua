addappid(1291170)
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228989)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1291171,0,"1a3918aa22c50743d5a2748097a8952bd085d245b7a4815b8b6d4b7be5e7b6d2")
setManifestid(1291171,"3131263791700052799")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]