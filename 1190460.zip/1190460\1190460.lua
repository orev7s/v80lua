addappid(1190460)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(1190461,0,"ba4c72812b801fa2b777bbbb0e3bc51cdd4d5a96e9684b8d267d6273eb9d9552")
setManifestid(1190461,"6042070459325609651")
addappid(1258510,0,"f584e505fdec0face5332668d8732e56722854f0a1e3d54e7b8c5a6f40dd165a")
setManifestid(1258510,"8715102423418115543")
addappid(1258610,0,"800379eb2eac3ae22ec9e8da62e69ee31943887000f2b87b1fea64ba208e6f95")
setManifestid(1258610,"2535244775118488795")
addappid(1190464)
addappid(1190465)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]