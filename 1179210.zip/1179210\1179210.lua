addappid(1179210)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1179211,0,"c6ef30beeea1da53720b5c4920b9c7d3c83112860d53632079e274fcbc0c7745")
setManifestid(1179211,"5368213969803102689")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]