addappid(1205970)
addappid(1205971,0,"bda7fa2a1e987629940c3faf629f17a0af5939f54cc244a56b1ac57e29739bbf")
setManifestid(1205971,"3902687917084328989")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]