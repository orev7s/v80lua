-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(2361770)
addappid(2361771,0,"6077dc2b1a88a7ae7a34470113e609a77bfc721374f4b17e20abc2f975ad2d85")
setManifestid(2361771,"7116288504888504901")
addappid(3381250,0,"155147f9c285079d0c8de3a293bb7e0ebc4c5e59763e5eb6f6ddb5a14c37df25")
setManifestid(3381250,"2060539196030722798")