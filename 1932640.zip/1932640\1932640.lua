addappid(1932640)
addappid(1932641,0,"8cbcc48378f983709b2bd2959cf190421f3e54c57008b7a1f81ba6bfd9aad886")
setManifestid(1932641,"6688300156638144929")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]