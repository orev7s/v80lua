addappid(1500820)
addappid(1500821,0,"e9b519e8a400d28cd321a01c70108cfd7380ae3cb0e47ef1e35725a42d64bb22")
setManifestid(1500821,"1776480445129167702")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]