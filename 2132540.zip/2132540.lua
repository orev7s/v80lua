-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(2132540) -- Mr. Run and Jump
-- MAIN APP DEPOTS
addappid(2132541, 1, "c49c494227a67bd11553ccce01dcee64455816e7ce86e402084398df4c26452a") -- Depot 2132541
setManifestid(2132541, "9203555010331955407", 809845194)