-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(3079970) -- Airport X-Ray Simulator

-- MAIN APP DEPOTS
addappid(3079972, 1, "6f8241800e907d0ce1e40888f65e5f11c779bfe313ba840d3334e581fe8ce753") -- Depot 3079972
setManifestid(3079972, "8563554393283104016", 0)
