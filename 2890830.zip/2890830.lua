-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(2890830) -- Streamer Life Simulator 2

-- MAIN APP DEPOTS
addappid(2890831, 1, "f266168cbca0fdbad69d36ca8ed9187480ed8adf90c68090ebea91b92757a77e") -- Main Game Content (Windows Content)
setManifestid(2890831, "7379383359389134719", 0)
