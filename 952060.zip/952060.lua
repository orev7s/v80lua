-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(952060) -- Resident Evil 3

-- MAIN APP DEPOTS
addappid(952061, 1, "59cd6a454139aeaf999cc3dde8aeb2e0c4dd0e1264c9d87bf0a7e702d892e68a") -- E1 Content JPD
setManifestid(952061, "685544654781343042", 0)
addappid(952062, 1, "fdfbc9447d8302b8a7b325ec2bccaa81e77cef9d8289ead20348a702cce53e40") -- E1 Content WW
setManifestid(952062, "8863028453226553691", 0)

-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Resident Evil Resistance - Male Survivor Costume Leon S. Kennedy (AppID: 1108280)
addappid(1108280)
addappid(1108280, 1, "2c80f9e638cea673510ec5562456040bb00c6ef138fb7be77c691ecab6118199") -- Resident Evil Resistance - Male Survivor Costume Leon S. Kennedy - E2_DLC1 Depot
setManifestid(1108280, "118105767515922548", 0)

-- RESIDENT EVIL 3 - Classic Costume Pack (AppID: 1158730)
addappid(1158730)
addappid(952063, 1, "e5e87afc561b9663966c6f3fb6a9de1dac7466dfb32db183fbcfbeb5f011257b") -- RESIDENT EVIL 3 - Classic Costume Pack - E1 DLC
setManifestid(952063, "7504296696893507629", 0)

-- Resident Evil 3 Special Soundtrack (AppID: 1295160)
addappid(1295160)
addappid(1295161, 1, "1b2d845f146b02222cb7b6356e33b08f6ddebd1dd4a80f72a13dca595c653195") -- Resident Evil 3 Special Soundtrack - Resident Evil 3 Special Soundtrack [MP3]
setManifestid(1295161, "5505136496663329306", 0)
addappid(1295162, 1, "6a51fcfe3d19507c47e01b8af456faf19ebb973b8a0ad44aa4fe8283a6a66ae4") -- Resident Evil 3 Special Soundtrack - Resident Evil 3 Special Soundtrack [FLAC]
setManifestid(1295162, "187027341863158419", 0)
addappid(1295163, 1, "ff01056c3ea3e3351ebc34addfcce478f69352fff3aec42833878649decc968c") -- Resident Evil 3 Special Soundtrack - Resident Evil 3 Special Soundtrack [AAC]
setManifestid(1295163, "410713025656098948", 0)
addappid(1295164, 1, "2028ac8dcda1d545c85a4377c099117ce59d6dc8e7bd6f6b7a543b0a28ddaec3") -- Resident Evil 3 Special Soundtrack - バイオハザード RE:3 スペシャル・サウンドトラック [MP3]
setManifestid(1295164, "5948231600898160780", 0)
addappid(1295165, 1, "a2d72fa757340931403176e139f35d9076553663031a45fd70d76875c2c21384") -- Resident Evil 3 Special Soundtrack - バイオハザード RE:3 スペシャル・サウンドトラック [FLAC]
setManifestid(1295165, "8913905599988540896", 0)
addappid(1295166, 1, "f7e6c8bcdc4151485d804f5d3d1b7db7b10ea29fd70f663370eaff3d3a2d1637") -- Resident Evil 3 Special Soundtrack - バイオハザード RE:3 スペシャル・サウンドトラック [AAC]
setManifestid(1295166, "569497974980581891", 0)

-- Resident Evil Resistance - Female Survivor Costume Claire Redfield (AppID: 1295350)
addappid(1295350)
addappid(1295350, 1, "dbe021a1825f0f53da71272f5fd0f4e37669b27d0e00393fcc472b70f515dce7") -- Resident Evil Resistance - Female Survivor Costume Claire Redfield - E2_DLC2 Depot
setManifestid(1295350, "4318883917755845120", 0)

-- Resident Evil 3 - All In-game Rewards Unlock (AppID: 1348140)
addappid(1348140)
addappid(952064, 1, "438a8c22458963cec5059bec6e195c24b9988cf2c2d2a33298db12146597812c") -- Resident Evil 3 - All In-game Rewards Unlock - E1 Unlock DLC
setManifestid(952064, "4916965303803227400", 0)
