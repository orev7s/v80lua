addappid(1001270)
addappid(1001271,0,"840a384558d951071f078063810429d5c2943f4389e02a2b992ad4e6cb001088")
setManifestid(1001271,"1922855744341626144")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]