-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(620) -- Portal 2

-- MAIN APP DEPOTS
addappid(624, 1, "48fcb7e647902c2d9467ef3f4405e1b6308981949705cb2b7489bb3d22aead66") -- portal 2 client binaries
setManifestid(624, "8323957709516641347", 0)
addappid(623, 1, "6a9fe60f83046355da81ea12f8fe895e3f59f1223d1689cc7e1ba327358e99fb") -- portal 2 mac content
setManifestid(623, "2276453204441793614", 0)
addappid(622, 1, "0be76bef0b464b2d58b6ced70c86e608708c18c1204836cb1bb5d209776f8a0e") -- portal 2 win content
setManifestid(622, "5403637970672788159", 0)
addappid(621, 1, "d2718f2424c94832a7112661774d98ffb3d52f454312f543a71418d253100d1d") -- portal 2 common
setManifestid(621, "3111897107378205370", 0)
addappid(625, 1, "d120d4c37faea11be77c787dc48000f297aaf8200a4265969a4f5dbeebc0326c") -- Portal 2 French
setManifestid(625, "1128685895801277145", 0)
addappid(626, 1, "50611154e0550112cb9f9edcc44cf32bb90a7fe8d2f5738f6f24b7ced43cf7c2") -- Portal 2 German
setManifestid(626, "6439173920052159773", 0)
addappid(627, 1, "4ff7fb0bde51bae4f2c7a9bb220fd2da9bd9b3b8210d222c615acf28a8fdd821") -- Portal 2 Spanish
setManifestid(627, "4705364648410025995", 0)
addappid(628, 1, "7f299ff4eec6b9de24869bb482a325b72f792798c87268f03feda25d4f3361c5") -- Portal 2 Russian
setManifestid(628, "1134745004760172192", 0)
addappid(661, 1, "5e338dd8d07e4cda5dfbcc7eb03418d9b1d93192bc20d5aac2174b851b11c1a6") -- Portal 2 linux content
setManifestid(661, "8787172582039049173", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Portal 2 Soundtrack (AppID: 323180)
addappid(323180)
addappid(323184, 1, "e20344b3d3b8542dd688df9c0ea6c68482dabe0d49774a297fc06782acd1d952") -- Portal 2 Soundtrack - Main Content
setManifestid(323184, "7786818608939958730", 0)
addappid(323185, 1, "33658cb0a5a5c9d74b8bb94b2307030da8b8925b41edc06674458a1d094cabba") -- Portal 2 Soundtrack - Main Content
setManifestid(323185, "1560109071176347310", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(650) -- Portal 2 - Gamestop PS3 DLC
addappid(651) -- Portal 2 - Bot Paint Job DLC
addappid(652) -- Portal 2 - Bot Roll Cage DLC
addappid(653) -- Portal 2 - Bot Antenna Topper DLC
addappid(654) -- Portal 2 - Summer 2011 DLC
addappid(669) -- Portal 2 - Sixense Motion Preorder
