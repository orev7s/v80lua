-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(2221920) -- Immortals Fenyx Rising

-- MAIN APP DEPOTS
addappid(2221921, 1, "8275786a67804e966e135b16f69f1645268119c16cfd77f21c6067bcb56a83e8") -- Depot 2221921
setManifestid(2221921, "3031123413831949673", 0)
addappid(2221924, 1, "591f2020ca54e1092d56368756b4f1451320964f23ed1be6097c2a7024cd7280") -- Depot 2221924
setManifestid(2221924, "4175715142077790583", 0)
addappid(2221925, 1, "9a0bb2ad4553ba8307ba1d495e1e90c970ae1168c1dd796537fe4f4b19f7519f") -- Depot 2221925
setManifestid(2221925, "4971002940988183118", 0)
addappid(2221926, 1, "4ae02ea71b8eeec15234a8ac672df21243ce0439b0f08a7f434e339d300e6795") -- Depot 2221926
setManifestid(2221926, "1914799300096293395", 0)

-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "550968249685141759", 0)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
setManifestid(1716751, "818295193716041715", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2222840) -- Immortals Fenyx Rising  A New God 
addappid(2222841) -- Immortals Fenyx Rising  Myths of the Eastern Realm
addappid(2222842) -- Immortals Fenyx Rising  The Lost Gods
addappid(2222843) -- Immortals Fenyx Rising  A New God Ubisoft Activation
addappid(2222844) -- Immortals Fenyx Rising  Myths of the Eastern Realm Ubisoft Activation
addappid(2222845) -- Immortals Fenyx Rising  The Lost Gods Ubisoft Activation
addappid(2222880) -- Immortals Fenyx Rising Gold Edition Ubisoft Activation
addappid(2224320) -- Immortals Fenyx Rising - Season Pass
addappid(2224321) -- Immortals Fenyx Rising - Season Pass Ubisoft Activation
addappid(2236200) -- Immortals Fenyx Rising - Standard Edition Ubisoft Activation
