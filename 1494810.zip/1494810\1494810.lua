addappid(1494810)
addappid(1494811,0,"0a511e83da83f4164929f78b0220da9474d343cbf334e814f37b5731de7196be")
setManifestid(1494811,"8034804025274064638")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]