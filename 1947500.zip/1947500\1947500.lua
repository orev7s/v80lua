addappid(1947500)
addappid(228989)
setManifestid(228989,"1332597174812030948")
addappid(228990)
setManifestid(228990,"5087715316087945828")
addappid(1947501,0,"3e113ec5caeaabe59a05798925fc253f0d1e16b6bd978ab02787883ed500cb4f")
setManifestid(1947501,"8787662584179509461")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]