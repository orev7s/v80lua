addappid(1066890)
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"5087715316087945828")
addappid(1066891,0,"d6f49d09d5511c95e9e8ea45456deb337c87a07d9df1474f781f70dcf3bfae72")
setManifestid(1066891,"6269261092299718758")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]