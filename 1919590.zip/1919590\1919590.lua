addappid(1919590)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"5087715316087945828")
addappid(1919591,0,"9a413d95948077bb749d1ac87416be4b6b0da6b5f64ad460fd8afe1dd4897f1e")
setManifestid(1919591,"5390652279031895565")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]