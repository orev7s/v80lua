-- Made by f1uxin, please read the read me TXT file.
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(530070) -- Train Sim World® 2020

-- MAIN APP DEPOTS
addappid(530071, 1, "52862de2b6f820c9f6dbf99587b1a5aaeb2f14c9ce516c1f7bc6b9288b4d3ac3") -- Train Sim World Content
setManifestid(530071, "4601439357656333302", 0)

-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Train Sim World Great Western Express (AppID: 577350)
addappid(577350)
addappid(577350, 1, "e245258747c5a3d2c271aae9765bc57b434b4dc0ca272d0c50bc4664fc12cbf6") -- Train Sim World Great Western Express - Train Sim World®: Great Western Express (577350) Depot
setManifestid(577350, "7912114707968153008", 0)

-- Train Sim World Main-Spessart Bahn Aschaffenburg - Gemnden Route Add-On (AppID: 577351)
addappid(577351)
addappid(577351, 1, "2b07d4650c9900430a8eab26b6dfe3beb675b00c51ead601baee4393a96bd067") -- Train Sim World Main-Spessart Bahn Aschaffenburg - Gemnden Route Add-On - Train Sim World - DLC 2 (577351) Depot
setManifestid(577351, "8225510536073295297", 0)

-- Train Sim World BR Class 33 Loco Add-On (AppID: 577352)
addappid(577352)
addappid(577352, 1, "a4b62011d28066718e3841ccd06640f041e9e3129d29d4088278d4783e8a58e4") -- Train Sim World BR Class 33 Loco Add-On - Train Sim World - DLC 3 (577352) Depot
setManifestid(577352, "6505075611487760462", 0)

-- Train Sim World Northern Trans-Pennine Manchester - Leeds Route Add-On (AppID: 577353)
addappid(577353)
addappid(577353, 1, "d05577289ce234f1c748788126fe9da0395320bb3337b31a6ab6a02beb11f38c") -- Train Sim World Northern Trans-Pennine Manchester - Leeds Route Add-On - Train Sim World - DLC 4 (577353) Depot
setManifestid(577353, "7466348272566283746", 0)

-- Train Sim World Long Island Rail Road New York - Hicksville Route Add-On (AppID: 577354)
addappid(577354)
addappid(577354, 1, "926f0cab955868852b14fdbfa6ac1fa52d1190a7c74afabfea299a76b149f076") -- Train Sim World Long Island Rail Road New York - Hicksville Route Add-On - Train Sim World - DLC 5 (577354) Depot
setManifestid(577354, "7800597064437574969", 0)

-- Train Sim World Ruhr-Sieg Nord Hagen - Finnentrop Route Add-On (AppID: 577355)
addappid(577355)
addappid(577355, 1, "707ec4f32703115e10e9d54a80f64430fe17b7340fd8d63e6235d05b890f4748") -- Train Sim World Ruhr-Sieg Nord Hagen - Finnentrop Route Add-On - Train Sim World - DLC 6 (577355) Depot
setManifestid(577355, "2407162239600377419", 0)

-- Train Sim World West Somerset Railway Route Add-On (AppID: 577356)
addappid(577356)
addappid(577356, 1, "ed264553fa6540fae901e5975dfc6f5fee46e5ef696ca77398f1be28fd806779") -- Train Sim World West Somerset Railway Route Add-On - Train Sim World - DLC 7 (577356) Depot
setManifestid(577356, "7046484642160724149", 0)

-- Train Sim World Northeast Corridor New York (AppID: 577357)
addappid(577357)
addappid(577357, 1, "a2a14165f027e246079109f5e4ec5a1a6ae31c16bd9e46e98045ef3f90ba7260") -- Train Sim World Northeast Corridor New York - Train Sim World - DLC 8 (577357) Depot
setManifestid(577357, "3053784946563336633", 0)

-- Train Sim World Rapid Transit (AppID: 577358)
addappid(577358)
addappid(577358, 1, "879b5b5757810c281d0e9bf4b93a2d9c90de7a564c6b15e484b9e9f61c197a64") -- Train Sim World Rapid Transit - Train Sim World - DLC 9 (577358) Depot
setManifestid(577358, "5486372883899215906", 0)

-- Train Sim World CSX GP40-2 Loco Add-On (AppID: 577359)
addappid(577359)
addappid(577359, 1, "62ab20cdcb264beb66a747c6afd3733441b0033155dd1eb3aef5f0ac7cb1620f") -- Train Sim World CSX GP40-2 Loco Add-On - Train Sim World - DLC 10 (577359) Depot
setManifestid(577359, "1710206607176814248", 0)

-- Train Sim World DB BR 182 Loco Add-On (AppID: 1010130)
addappid(1010130)
addappid(1010130, 1, "28eabea89b6162bdcb44a432843795088d3cb55edef294e817bbd4c0372b01a0") -- Train Sim World DB BR 182 Loco Add-On - Train Sim World DLC 11 (1010130) Depot
setManifestid(1010130, "4387918565006622389", 0)

-- Train Sim World DB BR 155 Loco Add-On  (AppID: 1010131)
addappid(1010131)
addappid(1010131, 1, "bc6cc359867ef6e698c55cb2de5679e39ea647911a48948531cf7129a969da3d") -- Train Sim World DB BR 155 Loco Add-On  - Train Sim World DLC 12 (1010131) Depot
setManifestid(1010131, "5887037175833712785", 0)

-- Train Sim World BR Class 52 Western Loco Add-On (AppID: 1010132)
addappid(1010132)
addappid(1010132, 1, "af9038d71695fd4cc4cf9742fc74cccac24d7e27b429d0474bb0feb237f36a1a") -- Train Sim World BR Class 52 Western Loco Add-On - Train Sim World DLC 13 (1010132) Depot
setManifestid(1010132, "344883809436378606", 0)

-- Train Sim World BR Heavy Freight Pack Loco Add-On (AppID: 1010133)
addappid(1010133)
addappid(1010133, 1, "88f7104526c868e075f6255b8e6633e8c7297f3e62def97ffac86c0f8ac704d8") -- Train Sim World BR Heavy Freight Pack Loco Add-On - Train Sim World DLC 14 (1010133) Depot
setManifestid(1010133, "6582464873101033327", 0)

-- Train Sim World Tees Valley Line Darlington  Saltburn-by-the-Sea Route Add-On (AppID: 1010134)
addappid(1010134)
addappid(1010134, 1, "e654a13d6680aec6c9c93fdfed90e189589bd3a1dcf399bad0be5620c077c197") -- Train Sim World Tees Valley Line Darlington  Saltburn-by-the-Sea Route Add-On - Train Sim World DLC 15 (1010134) Depot
setManifestid(1010134, "3084368623310347702", 0)

-- Train Sim World Amtrak SW1000R Loco Add-On (AppID: 1010135)
addappid(1010135)
addappid(1010135, 1, "0613cab20e5fbfcf46e826e2dc5daf3d67b834f1360a204f8ea3399594bf7a9e") -- Train Sim World Amtrak SW1000R Loco Add-On - Train Sim World DLC 16 (1010135) Depot
setManifestid(1010135, "4443021133837883578", 0)

-- Train Sim World Peninsula Corridor San Francisco - San Jose Route Add-On (AppID: 1010136)
addappid(1010136)
addappid(1010136, 1, "a6642fec0753ff9c4bc06aa07c222c86087d52b2aaf119787f61db751e97b24b") -- Train Sim World Peninsula Corridor San Francisco - San Jose Route Add-On - Train Sim World DLC 17 (1010136) Depot
setManifestid(1010136, "5116389932683548255", 0)

-- Train Sim World Rhein-Ruhr Osten Wuppertal - Hagen Route Add-On (AppID: 1010137)
addappid(1010137)
addappid(1010137, 1, "92ef76e0024fbb0e6d9415c16e47e4e85ee8e0a204b291643ca4341a5a079f7a") -- Train Sim World Rhein-Ruhr Osten Wuppertal - Hagen Route Add-On - Train Sim World DLC 18 (1010137) Depot
setManifestid(1010137, "505990925783388517", 0)

-- Train Sim World BR Class 31 Loco Add-On (AppID: 1010138)
addappid(1010138)
addappid(1010138, 1, "42cfccc1d65fe08c8411c130b69578f395da864663256d374750d153c4ff9b0d") -- Train Sim World BR Class 31 Loco Add-On - Train Sim World DLC 19 (1010138) Depot
setManifestid(1010138, "5622505541600049746", 0)

-- Train Sim World East Coastway Brighton - Eastbourne  Seaford Route Add-On (AppID: 1010139)
addappid(1010139)
addappid(1010139, 1, "bdda488f25b767b8839d6c6f7b18dea69d8284eeb8a97f17acefcbee57bd3ca3") -- Train Sim World East Coastway Brighton - Eastbourne  Seaford Route Add-On - Train Sim World DLC 20 (1010139) Depot
setManifestid(1010139, "968678968616541394", 0)

-- Train Sim World Canadian National Oakville Subdivision Hamilton - Oakville Route Add-On (AppID: 1113820)
addappid(1113820)
addappid(1113820, 1, "f3403021344805318b0093b59e7c615d94695f0ef15654237c69e6ecb974a4c8") -- Train Sim World Canadian National Oakville Subdivision Hamilton - Oakville Route Add-On - Train Sim World DLC 21 (1113820) Depot
setManifestid(1113820, "4481862775479656323", 0)

-- Train Sim World Caltrain MP36PH-3C Baby Bullet Loco Add-On (AppID: 1113821)
addappid(1113821)
addappid(1113821, 1, "4781c4e2b13cfed56dca9724c8407a26ed6395ae8fc01868e2a75546e89fa184") -- Train Sim World Caltrain MP36PH-3C Baby Bullet Loco Add-On - Train Sim World DLC 22 (1113821) Depot
setManifestid(1113821, "6491069670410015900", 0)

-- Train Sim World Caltrain MP15DC Diesel Switcher Loco Add-On (AppID: 1113822)
addappid(1113822)
addappid(1113822, 1, "164ff1d33b7647dd212c3c5646a5b607305770c8b57e186f4bd41b50fd0e0f77") -- Train Sim World Caltrain MP15DC Diesel Switcher Loco Add-On - Train Sim World DLC 23 (1113822) Depot
setManifestid(1113822, "6093872910916546266", 0)

-- Train Sim World Hauptstrecke Rhein-Ruhr Duisburg - Bochum Route Add-On (AppID: 1113823)
addappid(1113823)
addappid(1113823, 1, "e50d131e98b7fa4b306bfc4b66b931965f90e8a658e698b7393fda6f112fe1ca") -- Train Sim World Hauptstrecke Rhein-Ruhr Duisburg - Bochum Route Add-On - Train Sim World DLC 24 (1113823) Depot
setManifestid(1113823, "3266921803932239782", 0)

-- Train Sim World DB BR 204 Loco Add-On (AppID: 1113824)
addappid(1113824)
addappid(1113824, 1, "0e0e6e32cce2ede84009ad79bedee89fa8d92faa840f4ad1b965645cc661b8fb") -- Train Sim World DB BR 204 Loco Add-On - Train Sim World DLC 25 (1113824) Depot
setManifestid(1113824, "3734437432018165513", 0)

-- Train Sim World LIRR M3 EMU Loco Add-On (AppID: 1255310)
addappid(1255310)
addappid(1255310, 1, "93d6372f11ea1321f03b35994b99ba2889e59a82746929676efbdd4aedf2b505") -- Train Sim World LIRR M3 EMU Loco Add-On - Train Sim World DLC 26 (1255310) Depot
setManifestid(1255310, "3916243114373379215", 0)

-- Train Sim World BR Class 20 Chopper Loco Add-On (AppID: 1255311)
addappid(1255311)
addappid(1255311, 1, "a3b63392bca12e463918fd2f9f346c6daf9cba2c194f95c09231db04a5d70582") -- Train Sim World BR Class 20 Chopper Loco Add-On - Train Sim World DLC 27 (1255311) Depot
setManifestid(1255311, "5211342371722013361", 0)
