addappid(1660080)
addappid(1660082, 1, "b31ceba7551b938f6ee5ac53d92c6bba9c6620164b2dedf36cf80fae8825b17e")
setManifestid(1660082, "8016768789656007908", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]