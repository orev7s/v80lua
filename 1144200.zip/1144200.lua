-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(1144200) -- Ready or Not

-- MAIN APP DEPOTS
addappid(1144201, 1, "b9236894ba071d12dd117ce16220fefeb20574d7c6f7d2170e3113346867f3d6") -- Ready Or Not - Alpha Content
setManifestid(1144201, "6091457157396211072", 0)

-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Ready or Not Official Soundtrack (AppID: 3089910)
addappid(3089910)
addappid(3089911, 1, "ad6e74ede75aba32203a011af40c506a771be84256f15775efce310170c4676c") -- Ready or Not Official Soundtrack - Depot 3089911
setManifestid(3089911, "6229163073173979005", 0)
addappid(3089912, 1, "cd045276bbdda167270fd46f0b129a781e705003f2af095fe71bec217d065b95") -- Ready or Not Official Soundtrack - Depot 3089912
setManifestid(3089912, "1071123769281934173", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1844910) -- Ready or Not Supporter Edition
addappid(3015760) -- Ready or Not Home Invasion
addappid(3174120) -- Ready or Not Dark Waters
