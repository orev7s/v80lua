-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(1130620) -- Aka Manto | 赤マント

-- MAIN APP DEPOTS
addappid(1130621, 1, "413cc73b0863f91a3e1e44733da9846746b58bc1d614d71d418b920ad25cb4e1") -- Aka Manto | 赤マント Content
setManifestid(1130621, "2733476488770922466", 0)
