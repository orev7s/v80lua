-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪username - f1uxin, on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy / https://discord.gg/m8PxjTwrnv
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(547480) -- Carly and the Reaperman

-- MAIN APP DEPOTS
addappid(547481, 1, "dae7ec22fe7def4c873fa6a38f1b076195ae027d9c9864a24ddda568730dc520") -- Carly and the Reaperman Content
setManifestid(547481, "8571021466171618903", 0)
