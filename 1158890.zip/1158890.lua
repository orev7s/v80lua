-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(1158890) -- White Shadows

-- MAIN APP DEPOTS
addappid(1158891, 1, "ef547d439d9eca10e7bd722ae5a3cd3b752d73de5f29d7e17142a7d89909baac") -- Shadow of Steam Content
setManifestid(1158891, "7066078465228785556", 0)
