addappid(2022670)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(229007)
setManifestid(229007,"4477590687906973371")
addappid(2022671,0,"f2c1f41d9127af994a3cd878921ff5b89db85334ee15711d98ecac202e0b2c54")
setManifestid(2022671,"6653124279603243936")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]