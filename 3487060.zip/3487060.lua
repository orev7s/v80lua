addappid(3487060)
addappid(3487061,0,"a45085f2752e82e06b9b112531e9a91d431e75d9ed1a041b26b6e1e498743b39")
setManifestid(3487061,"6574133023651097566")



--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord server : https://discord.gg/sv6EGxCRnC
]]