addappid(1364780)
addappid(1364781, 1, "cfec39716b5a5cae49b52b5c0e01e6db93356ee3df5a0d87590fd811ab6d06e1")
setManifestid(1364781, "5364473620529992204", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]