addappid(1375400)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"5087715316087945828")
addappid(1375401,0,"f362b285b7c5d5b8f4c09c292f4bdd7543e2e396452ef0626b4fd077d378ee5e")
setManifestid(1375401,"3752822090114699608")
addappid(1375403,0,"b5f3d5fea5b0315e0f65aca470810f05b4ff102127eea9341a84d109a8f8274d")
setManifestid(1375403,"2569066263056827564")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]