addappid(1804010)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1804011,0,"9e2dda820fdffc53cc3820a3315777e79e7ce3789f88843cea754bca4b09a897")
setManifestid(1804011,"61109871668933934")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]