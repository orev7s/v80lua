addappid(1369670)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1369671,0,"2997d5be0b53d13cde83335f41136a55c7198a843f319a2e9e3667ef228a1aed")
setManifestid(1369671,"2387756181552268087")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]