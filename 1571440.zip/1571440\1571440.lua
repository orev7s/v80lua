addappid(1571440)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1571441,0,"5af4b12644dccedb81bc1ea50e49f8fb4308bf9e6aabd9f26e209a67bd7880d3")
setManifestid(1571441,"424668838599341022")
addappid(1571442)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]