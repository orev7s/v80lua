-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(38400) -- Fallout

-- MAIN APP DEPOTS
addappid(38401, 1, "816e1429544d54b3d5d7397950732a90584c91bdfb786adb443570149b53ca3f") -- fallout content
setManifestid(38401, "7224698799248053466", 0)
addappid(38402, 1, "2e8b274c691197c522592a866520b3d2d1e0ab9d1413d64eaf4c16b00f16e8f4") -- Fallout French
setManifestid(38402, "6076885954738250009", 0)
addappid(38403, 1, "fc27974c382196d655d34c483528513b6ab0769c46fccfe76c6892f5497118e5") -- Fallout Spanish
setManifestid(38403, "4902450576674075303", 0)
addappid(38404, 1, "9a085b22cf1e134e273410c74d07a6644e74c3863a75defb361085f40bb27580") -- Fallout German
setManifestid(38404, "4243693244722075572", 0)
addappid(38405, 1, "4e4d274c16a9a4b7f66f4eaa42f713946feb4b98211e6c97d45e2b50159eae19") -- Fallout Content new
setManifestid(38405, "4502593246297943417", 0)
addappid(38409, 1, "f43c1a293636be9f09caa5afbfce73b5adc21697304cd5c7c545c4119e9f369c") -- Fallout English New
setManifestid(38409, "3070136178682603522", 0)
addappid(38407, 1, "9cda25075c361f70f49306e02f7cdc4f04d6a805461fad0cfabe7ff25dc68a70") -- Fallout German New
setManifestid(38407, "8914939901970404241", 0)
addappid(38406, 1, "13baaf56fba67d1411bdc5958ec8f15e3d11396a547d11b88cefe426d12eccf2") -- Fallout French New
setManifestid(38406, "2735371789049930811", 0)
addappid(38408, 1, "579958b8e232e928597a40dd185b717e3fc347615bc13890dd6b617b691dcccc") -- Fallout Spanish New
setManifestid(38408, "3845315772300233150", 0)

-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- .NET 4.0 Redist (Shared from App 228980)
setManifestid(229002, "7260605429366465749", 0)
