-- Steam App 2993780 Manifest
-- Name: FANTASY LIFE i: The Girl Who Steals Time
-- Generated: 2025-05-21 18:03:46
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(2993780) -- FANTASY LIFE i: The Girl Who Steals Time

-- MAIN APP DEPOTS
addappid(2993781, 1, "ad98d2baa7c277a9a3d59599e17cb30eb75781386d8c475317d4570b8dc72aaf") -- Main Game Content (Windows Content)
setManifestid(2993781, "4984495488629773441", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3464380) -- FANTASY LIFE i The Girl Who Steals Time  Edition Upgrade (Digital Deluxe)
addtoken(3464380, "13290660664749164908")
