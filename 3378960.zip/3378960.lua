-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(3378960)
addappid(3484230)
addappid(3596880)
addappid(3484241,0,"850583f98b56a2b21b65c877cf536c83830fa54c21f30ce3c6397935f065b2bc")
setManifestid(3484241,"7238494630064099886")
addappid(3378961,0,"02157efe6285cacaa20730d8f0bd83c4b020ec25cd0c75e88ad7ac83465a570a")
setManifestid(3378961,"8610612055954563073")