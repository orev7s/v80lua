addappid(1018010)
addappid(228990)
setManifestid(228990,"5087715316087945828")
addappid(1018011,0,"f369e7edc8f5b3ceafff6f9366fbf8d1b5f3ce2d064444f966315ff1b0cbdf4b")
setManifestid(1018011,"4125351698578021580")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]