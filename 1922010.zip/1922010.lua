-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(1922010) -- Breachers

-- MAIN APP DEPOTS
addappid(1922011, 1, "515868fe0b42e739aec093cc314cd9ecd5aa9ca87e7e94e58211c8104a73dd36") -- Depot 1922011
setManifestid(1922011, "5677933850259479992", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3562130) -- Breachers - Gilded Bundle
addappid(3656450) -- Breachers - Sakura Bundle
addappid(3707360) -- Breachers - Wildstyle Bundle
addappid(3731960) -- Breachers - Chivalry Bundle
addappid(3842440) -- Breachers - Quantum Bundle

-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Breachers - Aquatic Fun Bundle (AppID: 3246660) - missing depot keys
-- addappid(3246660)
-- Breachers - Adrenaline Bundle (AppID: 3246720) - missing depot keys
-- addappid(3246720)
-- Breachers - Horror Bundle (AppID: 3246730) - missing depot keys
-- addappid(3246730)
