-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

addappid(588030)
addappid(588031,0,"8f86e8547e0ff976ae25b0485d10a772f80b80edd6a0223e81425d8b69917c21")
setManifestid(588031,"3901272373605210930")
addappid(588032,0,"7d1ed980030644def80ae52ff407d02bfeaa9c7c413476ed331ee05730fbb10f")
setManifestid(588032,"2313122337171636852")