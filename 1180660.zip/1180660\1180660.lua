addappid(1180660)
addappid(1180661, 1, "72a19a685d8cb6c64f161658219bf9ba99357042dc78c688d5f4045238367e6e")
setManifestid(1180661, "1121084895673538244", 0)
addappid(1238430, 1, "b71e20beeb0a44dea82ac77729b642341ab2258027aa98e2ff2dd572347d026e")
setManifestid(1238430, "8556954704237120738", 0)
addappid(1266670, 1, "f813ea8876461b335086830b177793094f3ec2c29bd1cf3453ee3df66d2c245a")
setManifestid(1266670, "3458796689156191626", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]