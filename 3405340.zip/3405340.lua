-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3405340)
addappid(3405342,0,"0fbab2971279bba685debbfa503e2da7e014fb5066cec822fcda80f9465e304e")
setManifestid(3405342,"4301663095342179654")