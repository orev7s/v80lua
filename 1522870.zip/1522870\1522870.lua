addappid(1522870)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1522871,0,"b787c83a3dbe5e5d088f2a22a71a29a9d6e4d51b0faf1d84b5bee06b8f25b5cd")
setManifestid(1522871,"4300392132672601936")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]