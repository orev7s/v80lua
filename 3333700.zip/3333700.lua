-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy / https://discord.gg/m8PxjTwrnv
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(3333700) -- The Royal Writ
-- MAIN APP DEPOTS
addappid(3333701, 1, "7cfc4b562bfb63fc2622f8752b18d06bb90d2c76f4b90a72542a1aba9c2ed5bb") -- Depot 3333701
setManifestid(3333701, "3444389046701626460", 1492425496)