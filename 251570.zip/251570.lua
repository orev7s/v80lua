-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(251570, 1, "e53177a4e7b3979bb3284352de1dbcf65f8d3b1b57d5d63971906f5b75c53c86") -- 7 Days to Die
-- MAIN APP DEPOTS
addappid(251576, 1, "525d3fda8d2195cf5a8bd10c0c158513d9f870f99a036830287c1465c73c6979") -- Windows 64 Bit
setManifestid(251576, "133976342143448674", 18369303755)
addappid(251577, 1, "53a3478a67db1f8ed8030e845ec1be174a60cea2448401ffd4dda0c4838cbb84") -- Mac
setManifestid(251577, "949611504741668687", 18197886353)
addappid(251578, 1, "4550672ef4a498246530208707b36b490dd3bb73c6b54ba6b832dd48db88f71a") -- Linux Universal
setManifestid(251578, "8287144542041066476", 18359211542)
addappid(251571, 1, "2787b64cd24c9e42a114df4d2559813dc0f63405faa2f7e41cc77e6c3cc67bd0") -- Windows 32 Bit
setManifestid(251571, "8628486239191323866", 0)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3314750) -- The Hoarder Armor Set
addappid(3486400) -- The Marauder Armor Set
addappid(3635260) -- The Desert Armor Set