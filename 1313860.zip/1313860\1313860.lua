addappid(1313860)
addappid(1383804)
addappid(1313861,0,"bdb8cd04893675b1839374668f950b26586f220bc03c0f6f36d8bc9d88ead013")
addappid(1313862,0,"a7309d49fd59e78d18dae998d7a9827ab3c84232aedc54928bcfed73077f20d1")
setManifestid(1313861,"735211253194835338")
setManifestid(1313862,"7345734276839701367")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]