addappid(1352930)
addappid(1352933, 1, "635ee2f2bc1fc63e9517e825b75a27071d3d76dc409ced79c1312892abf7fab0")
setManifestid(1352933, "6383852217150250001", 0)
addappid(1352934, 1, "c6f96a0cdb5e91cd0050d0f81ca21843ae0c384991caa4e3c5eaae9da3e28323")
setManifestid(1352934, "70073793861024026", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]