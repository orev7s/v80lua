addappid(1887400)
addappid(1887401,0,"45bc1461e14ddd35a713fc71483727d019f558488091b54ef249bf00dba5a16b")
setManifestid(1887401,"6293474910867682003")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]