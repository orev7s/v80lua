-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(2716110) -- Jisatsu | 自撮

-- MAIN APP DEPOTS
addappid(2716111, 1, "e4ec7693d317177362b5aea48c8894ed0e59ff2f97dfb4024483ce6b6b9777e3") -- Main Game Content (Windows Content)
setManifestid(2716111, "2860011248486226996", 0)
