-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(250320) -- The Wolf Among Us

-- MAIN APP DEPOTS
addappid(250321, 1, "e5e38d4f2fda3bfeb95e764ebfcc370afacaa55f72869024dd6ba50ece0f87dd") -- The Wolf Among Us Content
setManifestid(250321, "6147470668177541656", 0)
addappid(250322, 1, "eb4a620c32f0feb04b306c03c751adf653202ea438e0869d8868f45a9d510abf") -- The Wolf Among Us Content Mac
setManifestid(250322, "6649087482508273292", 0)
addappid(250332, 1, "7027c89ecd837cb0c4c1f6e04fa6b23ce128bf2f451504676b47623161b95b5b") -- 102 PC
setManifestid(250332, "1413956296749617162", 0)
addappid(250333, 1, "59a55ffcf2c19b6776f5fa59ba247a6106f04bf2a5097cd1fd84876678209dc1") -- 102 MAC
setManifestid(250333, "6923855415390474570", 0)
addappid(250323, 1, "1fe9cd1474f0567e000bef9addb0aefbe051335c5509e6edb3d0f6ec9e4fbdb6") -- 103 PC
setManifestid(250323, "8556907910838177047", 0)
addappid(250324, 1, "9375862c5ca3f96beb8bfe2062328b8e83eac9c4b99b2fc7a09fdc92e250e77d") -- 103 MAC
setManifestid(250324, "1692704989664381685", 0)
addappid(250325, 1, "122889223adbf2bf9f4753a094326993281d9af5c71d49d2219bd44f528d691e") -- 104 PC
setManifestid(250325, "7362769600209296156", 0)
addappid(250326, 1, "361f834316e1401b0af003c9b7c269df26dac6150bfbc37d85a0bd62c19842ab") -- 104 Mac
setManifestid(250326, "7549065213783741563", 0)
addappid(250327, 1, "48fd26b84c20e9ddcd8f18dcbc5d974b5b4aadfb25a98199b77fbbb8bd6399fe") -- 105 PC
setManifestid(250327, "3914222143265912340", 0)
addappid(250328, 1, "8083ff3aa201f26d45c44db637e95c5034cc1025edc264576a1cad5679bdbcd6") -- 105 Mac
setManifestid(250328, "670244090223380792", 0)

-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
