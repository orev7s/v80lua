-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(2796020) -- Refuted Wind

-- MAIN APP DEPOTS
addappid(2796021, 1, "8f6e62f99eeef44ea2a35b8075a08cc007d6506f5a5c1c3034846e866588289c") -- Main Game Content (Windows Content)
setManifestid(2796021, "7564205257771334440", 0)
