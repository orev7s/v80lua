addappid(1316680)
addappid(1316681,1,"5ffddaa8a208d452dbf7149e9c82bfd278682c10b1262d32c0159db65bdf4644")
setManifestid(1316681,"4784211829729680838")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]