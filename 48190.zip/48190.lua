-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy

-- MAIN APPLICATION
addappid(48190) -- Assassin's Creed Brotherhood

-- MAIN APP DEPOTS
addappid(48193, 1, "92734ca4ad50878769fab352e45b48131110f53494ecc4708db34b7e0ce942c1") -- Assassins Creed Brotherhood Mac content
setManifestid(48193, "3500960106426649477", 0)
addappid(48192, 1, "8cabeaf38cd688184bab6bdbbd34d0dbce4c751eaaf7c7f0878847359bc6543a") -- acb_deluxe_content
setManifestid(48192, "8303807335979433554", 0)
addappid(48191, 1, "07b66cd56c14adc4368fc36622308a39eb66af717af87f63a706fb5095cc1058") -- assassins creed brotherhood content
setManifestid(48191, "6641652349099836879", 0)
addappid(48194, 1, "46f9e1c0a5284ed561b7f88c1105921c5be7d5e281a1b4d6436c7ab5420ec029") -- Assassin's Creed Brotherhood WW Depot
setManifestid(48194, "3001580851652474584", 0)
addappid(48199, 1, "5484ca1e7b74d883623916099c96dc87402fcd62247952d2fcef3e18633eadc3") -- Assassin's Creed Brotherhood Korean Depot
setManifestid(48199, "1129412330587023805", 0)
addappid(48200, 1, "74773d98cb00b55c6bf498196ef57756d25f070ab28a25eb5dd8c998930dded6") -- Assassin's Creed Brotherhood SChinese Depot
setManifestid(48200, "883912898399357051", 0)
addappid(48201, 1, "68693fb573b07160d0ea85fb3683c682d46e810a16a0013e22777dea8e4e843d") -- Assassin's Creed Brotherhood TChinese Depot
setManifestid(48201, "4071795358417878418", 0)
addappid(48202, 1, "1cf3d330157141da11d9dc1ffaafaa9b72ad42a1f9418c9d994a916d1a8e5c15") -- Assassin's Creed Brotherhood Polish Depot
setManifestid(48202, "639386459569464708", 0)

-- SHARED DEPOTS (from other apps)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- VC 2005 Redist (Shared from App 228980)
setManifestid(228981, "7613356809904826842", 0)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
setManifestid(228982, "6413394087650432851", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
setManifestid(1716751, "818295193716041715", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(48195) -- Assassins Creed Brotherhood - Standard CD Key
addappid(48196) -- Assassins Creed Brotherhood - Deluxe CD Key
addappid(48197) -- Assassins Creed Brotherhood - Standard CD Key Mac
addappid(48198) -- Assassins Creed Brotherhood - Deluxe CD Key Mac
