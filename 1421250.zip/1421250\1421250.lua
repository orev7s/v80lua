addappid(1421250)
addappid(1421251,1,"26c7441369eb15b5a36a102139161693464b46afa6f77cc7744ea95f920ece2c")
setManifestid(1421251,"217842501280390089")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]