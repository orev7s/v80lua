
-- MAIN APPLICATION
addappid(3400930) -- Guilty as Sock!

-- MAIN APP DEPOTS
addappid(3400931, 1, "b4b077327c865e84c8ff3a5df3db9164977fc05a5fe3af164e0c3789a4f18ce0") -- Main Game Content (Windows Content)
setManifestid(3400931, "7131311488277035776", 0)
