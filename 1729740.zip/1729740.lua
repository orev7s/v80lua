-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1729740)
addappid(1729741, 1, "ae083aff6754925333f345c885acd58509a103503fd7ce6de8abe8b03e9fe4d2")
setManifestid(1729741,"2975965042191885637",0)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")
setManifestid(228989, "3514306556860204959", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
setManifestid(228990, "1829726630299308803", 0)
