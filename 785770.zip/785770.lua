-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(785770) -- Notruf 112 - Die Feuerwehr Simulation 2

-- MAIN APP DEPOTS
addappid(785771, 1, "2c7097ddbc5e503a653700238917cebd42e5cb34f1bd54118c32df3457f45516") -- Schlauchspiel 2 Content
setManifestid(785771, "4938289512580637578", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Notruf 112 - Die Feuerwehr Simulation 2 Freiwillige Feuerwehr (AppID: 1925400)
addappid(1925400)
addappid(1925400, 1, "4cdf171d6b34293f865a586322f149a684b6dcf33a7b92690c63a19cd1ea377c") -- Notruf 112 - Die Feuerwehr Simulation 2 Freiwillige Feuerwehr - Main Content
setManifestid(1925400, "1304350536017398873", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2715800) -- Notruf 112 - Die Feuerwehr Simulation 2 WLF - Das Wechselladerfahrzeug
