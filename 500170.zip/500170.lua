-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(500170) -- Urlaubsflug Simulator – Holiday Flight Simulator

-- MAIN APP DEPOTS
addappid(500171, 1, "31683737d7eed2c010fc5e26be5f0fe96c061e51e8251f0a8573a502274807ad") -- Ready for Take off-A320 Simulator
setManifestid(500171, "5678092774645726075", 0)
