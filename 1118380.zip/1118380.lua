-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1118380)
addappid(1118382,0,"dd7240f8207937ac0803e4c8c6040e7f20892b03f5d71a1465b325be98f77413")
setManifestid(1118382,"1326583840539626459")