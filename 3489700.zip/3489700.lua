-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 / username - f1uxin. On discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my (F1uxins) official server: https://discord.gg/NmmpgnAgen
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(3489700) -- Stellar Blade™
-- MAIN APP DEPOTS
addappid(3489701, 1, "2266ca31f6f2666ebe75906201e72f9398694030ff1c8214aacebcf74dc94ee3") -- Depot 3489701
setManifestid(3489701, "684302053577225658", 62305882807)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Stellar Blade x NieRAutomata (AppID: 3596180)
addappid(3596180)
addappid(3596180, 1, "a55f79607c32a7e24a388464ddc3cfbc91b2dcee6691061bca3fb32d231ccb32") -- Stellar Blade x NieRAutomata - Depot 3596180
setManifestid(3596180, "7141555575842925314", 267941918)
-- Stellar Blade x GODDESS OF VICTORY NIKKE (AppID: 3596190)
addappid(3596190)
addappid(3596190, 1, "1e65f8baa259f487dcdc1d3dce1e198dd23c9f7b77236e4e56fcc9f6b915a449") -- Stellar Blade x GODDESS OF VICTORY NIKKE - Depot 3596190
setManifestid(3596190, "193918182562554770", 25546741)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3596170) -- Stellar Blade Deluxe Pack
addappid(3596200) -- Stellar Blade NIKKE Code Box
addappid(3596210) -- Stellar Blade NIKKE Code Verification
addappid(3596220) -- Stellar Blade Pre-purchase Rewards
addappid(3662250) -- Stellar Blade Tachyon Pack