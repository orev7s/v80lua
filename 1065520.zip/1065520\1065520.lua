addappid(1065520)
addappid(1065521,0,"ebdf69796c66194e13e3eba42c193675f787c3d7e93d878ccbbbd71adfa98da7")
setManifestid(1065521,"3124336389357044872")
addappid(1065522,0,"2b897b355434d8d396d3cae8a4c488b3d6c9188df5daf894a3c01d316f5e5c3a")
setManifestid(1065522,"1010927138433360605")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]