-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(267550) -- The Amazing Spider-Man 2

-- MAIN APP DEPOTS
addappid(267551, 1, "04dd3829762dc4e391c5dc81b1262094cbb8d7810f7017111dd95092ae140f3c") -- Binaries
setManifestid(267551, "6217816470569200398", 0)
addappid(267552, 1, "8a3ced7859d531f58cbb35009e4670b16686745d45f4f7d0f41b996c4834a3b4") -- Content
setManifestid(267552, "8237097105513432045", 0)
addappid(267554, 1, "5588f553e461f38b5c775997aa66909af0035e9991987027a4a1b41e5d8fc9f7") -- Content ENU
setManifestid(267554, "4169879273930013139", 0)
addappid(267555, 1, "4506e6f6907a1693c824eb7a2f08772198fd07c46d923b70dcd6da2a8bbef609") -- Content FRA
setManifestid(267555, "1757749374073337260", 0)
addappid(267556, 1, "961e20547d04b976d4cbf3143737e43bd88d550f808661004722e43c0a9fef1c") -- Content DEU
setManifestid(267556, "672808828550552554", 0)
addappid(267557, 1, "9042443822955c69bc62d33edf174fcfdde75493bd192724ce353834e611f6f0") -- Content ITA
setManifestid(267557, "9139376179169848067", 0)
addappid(267558, 1, "929b559e43f6061338714d43d7d5f214d39a9974091cc731ef37af896dc22f72") -- Content ESP
setManifestid(267558, "8149856904250414620", 0)

-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- .NET 3.5 Redist (Shared from App 228980)
setManifestid(229000, "4622705914179893434", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Amazing Spider-Man 2 - Iron Spider (AppID: 286910)
addappid(286910)
addappid(286910, 1, "5252f5acab6817660b884d9f02a28ac3d9b8862aca62ba7b892b4c9bf22fcff5") -- Amazing Spider-Man 2 - Iron Spider - DLC Iron Spider
setManifestid(286910, "5501426235777094317", 0)

-- Amazing Spider-Man 2 - Cosmic Spider-Man (AppID: 286911)
addappid(286911)
addappid(286911, 1, "b91bcae94baeba7c40e1905f068e21587bd947bad650e26341078acfb6ca42f9") -- Amazing Spider-Man 2 - Cosmic Spider-Man - DLC Cosmic Spider-Man
setManifestid(286911, "928273075209619740", 0)

-- Amazing Spider-Man 2 - Black Suit (AppID: 286912)
addappid(286912)
addappid(286912, 1, "52caa3063f92a027c1511d97c97511558a6222de9e50ec5cbf29baea9e7c0c40") -- Amazing Spider-Man 2 - Black Suit - DLC Black Suit
setManifestid(286912, "563234625403322468", 0)

-- Amazing Spider-Man 2 - Spider-Man Noir (AppID: 286913)
addappid(286913)
addappid(286913, 1, "31952590d414a22d5158f2a3dcc956ed5fcca84a81825f0d0347c28dd605aad7") -- Amazing Spider-Man 2 - Spider-Man Noir - DLC Spider-Man Noir
setManifestid(286913, "1393143416676027006", 0)

-- Amazing Spider-Man 2 - Electro-Proof (AppID: 286914)
addappid(286914)
addappid(286914, 1, "a925a288f9162013bab8c33a848bf5c5f0d700d8329ba256062162a5cf9187db") -- Amazing Spider-Man 2 - Electro-Proof - DLC Electro-Proof
setManifestid(286914, "870872215230150878", 0)

-- Amazing Spider-Man 2 - Ends of the Earth (AppID: 286915)
addappid(286915)
addappid(286915, 1, "f467cc43a6242a65717a255bd43649f32e5c564724275f470ccfcebdb4d80d11") -- Amazing Spider-Man 2 - Ends of the Earth - DLC Ends of the Earth
setManifestid(286915, "3586444822452921394", 0)
