addappid(1707990)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1707991,0,"573a21de5c170e2cab9f3a65540656d19ff87f616d2746c35d4d7e1470ea4923")
setManifestid(1707991,"4518968490371351652")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]