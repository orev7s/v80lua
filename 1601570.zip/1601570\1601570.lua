-- Made By @F1uxin
-- MAIN APPLICATION
addappid(1601570) -- The Alters

-- MAIN APP DEPOTS
addappid(1601571, 1, "0439da537fb9ca417bd1efa7f41890efff942c7cae69a68d72ff61d8b3e2ca8b") -- Main Game Content (Windows Content)
setManifestid(1601571, "5969122513339307891", 0)

-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 0)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "550968249685141759", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3773900) -- The Alters Deluxe Edition Upgrade

-- DLCS EXCLUDED (NO DEPOT KEYS, NO DEDICATED DEPOTS)
-- addappid(3237500) -- The Alters Original Soundtrack (no keys available)
