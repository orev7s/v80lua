addappid(1604240)
addappid(1604241,0,"4f71fc9397ccb0b402980d2bbbfe72d3d6d40a15ea56abc5af827b8abcdaa2fd")
setManifestid(1604241,"7893241917057708621")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]