-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(47810) -- Dragon Age: Origins - Ultimate Edition

-- MAIN APP DEPOTS
addappid(47811, 1, "58cf3d349c0649f97ca5aed4cd4e341076b4ff75a6186983e4cf5b60337680e9") -- dragon age ultimate content
setManifestid(47811, "530690737453855107", 0)
addappid(47812, 1, "8ef7c9ef5552fdff433695f3ca71dbafbe172b3e850caead594040ea27817f9d") -- Dragon Age: Origins - Ultimate Edition English
setManifestid(47812, "1493377730879186203", 0)
addappid(47813, 1, "a5c3c9751b75af08e3c66ee80b9209bdef0006232d4944d4c6a52dbe09fabb55") -- Dragon Age: Origins - Ultimate Edition Italian
setManifestid(47813, "8575557806586953526", 0)
addappid(47814, 1, "02ed4d296b3c2ec5cf6b22952b99a61b16cf6a9bede1d109be60cf690a5ac629") -- Dragon Age: Origins - Ultimate Edition Spanish
setManifestid(47814, "3465804479649898863", 0)
addappid(47816, 1, "f5fda9023a5198150e38326e1b6f6d85079dd67e2b42a078d8f1eff24084fb35") -- Dragon Age: Origins - Ultimate Edition German
setManifestid(47816, "8301284763896437284", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(47815) -- Dragon Age Origins - Ultimate Edition DLC CD Key
