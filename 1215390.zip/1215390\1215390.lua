addappid(1215390)
addappid(1215391,0,"94d913cb61b5cd8d9f0e75d1b2003b0c25004d0633654e4f2ad8bad4b02c331f")
setManifestid(1215391,"8520929547852091835")
addappid(1215392)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]