-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(1149620) -- Gas Station Simulator

-- MAIN APP DEPOTS
addappid(1149621, 1, "1d21f7beeda92128e1267f7eea3c00d440b14678cf3cfe14a169dcea7e12edf1") -- Gas Station Simulator Content
setManifestid(1149621, "465945707191976339", 0)
addappid(1149622, 1, "5318833456ef715b96282071c2916dd84417c4f6a9415de3f0ae5c6228431866") -- Depot 1149622
setManifestid(1149622, "8209806836162189537", 0)

-- SHARED DEPOTS (from other apps)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- PhysX System Software 9.14.0702 (Shared from App 228980)
setManifestid(229033, "2059065101492814639", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Gas Station Simulator - Can Touch This DLC (AppID: 1940030)
addappid(1940030)
addappid(1940030, 1, "0a6183b31d33d942748a804b209c92164d3c822726e740991f2873e8f2b7fefd") -- Gas Station Simulator - Can Touch This DLC - Depot 1940030
setManifestid(1940030, "6929487657672271545", 0)
addappid(1940032, 1, "780b4c505f94867c8dec072ec8a2df451200acc3b430a52b0abb0605fba295bc") -- Gas Station Simulator - Can Touch This DLC - Depot 1940032
setManifestid(1940032, "355801663685834157", 0)
addappid(1940034, 1, "93dfa45eede2d156fe5a935250b520bf52fba604f7187701775eefcd69c91a89") -- Gas Station Simulator - Can Touch This DLC - Depot 1940034
setManifestid(1940034, "9011406718332979228", 0)

-- Gas Station Simulator - Party Time DLC (AppID: 2126170)
addappid(2126170)
addappid(2126170, 1, "bb40410fd736969baa459a221e60a7e83aefe67cd59b62c00109497d3dc18694") -- Gas Station Simulator - Party Time DLC - Depot 2126170
setManifestid(2126170, "4379211872208836296", 0)
addappid(2126171, 1, "e6debb7a8780b5e921ecae8e60c3f19ebce80efcff459a39f2d4181d3833e400") -- Gas Station Simulator - Party Time DLC - Depot 2126171
setManifestid(2126171, "6980290753007590340", 0)
addappid(2126172, 1, "6efbdbd33b5157ebf1b8b3ac1fd975269aea92948a309ab536d20e3135c7b78b") -- Gas Station Simulator - Party Time DLC - Depot 2126172
setManifestid(2126172, "46851970679164192", 0)

-- Gas Station Simulator - Airstrip DLC (AppID: 2137370)
addappid(2137370)
addappid(2137370, 1, "c2b1f158fa3ed61786915df4ddb9b96c82b12af014cbc800b8f56381899e237f") -- Gas Station Simulator - Airstrip DLC - Depot 2137370
setManifestid(2137370, "8757950765286331134", 0)
addappid(2137371, 1, "685c4b4fc21a9eaf46bbac2f9d0ccbf89a7b09a2659b70b8632a9e9ae8c3b3f6") -- Gas Station Simulator - Airstrip DLC - Depot 2137371
setManifestid(2137371, "6401123472977673855", 0)

-- Gas Station Simulator - Tidal Wave DLC (AppID: 2600880)
addappid(2600880)
addappid(2600880, 1, "1e3492c0a87fd4d13473643a89a13ca11e6b53b14cc3379b58786298a54b5d4a") -- Gas Station Simulator - Tidal Wave DLC - Depot 2600880
setManifestid(2600880, "4503728684692043715", 0)
addappid(2600881, 1, "87b59d53b6599af97f35e043fbb59811283a34a92e5c4582bd787ebb30c7065a") -- Gas Station Simulator - Tidal Wave DLC - Depot 2600881
setManifestid(2600881, "290332419482288391", 0)

-- Gas Station Simulator - Car Junkyard DLC (AppID: 2782920)
addappid(2782920)
addappid(2782920, 1, "05e1bc2f942cafd052d92277aa419aeecfa5f362cb8bd4706c8836f4002686d7") -- Gas Station Simulator - Car Junkyard DLC - Depot 2782920
setManifestid(2782920, "347277512407959376", 0)
addappid(2782921, 1, "3a6c339018744ba3b8470a09abb4bcb07bebfee982be94e31eef799777f75b02") -- Gas Station Simulator - Car Junkyard DLC - Depot 2782921
setManifestid(2782921, "7200551433956953046", 0)

-- Gas Station Simulator - Drive-In Cinema DLC (AppID: 3014630)
addappid(3014630)
addappid(3014630, 1, "505eac0ad2793193b10c693e3121593f075636e9bfb9cae6314d1298a1b013ff") -- Gas Station Simulator - Drive-In Cinema DLC - Depot 3014630
setManifestid(3014630, "4046119146568848561", 0)
addappid(3014631, 1, "cbee25c94be32f9bb0cd863ac8b5a0033e30d7f8cf863d4528f49c3e16a671d6") -- Gas Station Simulator - Drive-In Cinema DLC - Depot 3014631
setManifestid(3014631, "307440033986737917", 0)

-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(1992100) -- Gas Station Simulator - Shady Deals DLC (unreleased)
-- addappid(3543920) -- Gas Station Simulator - RV Camp DLC (unreleased)
