addappid(1347430)
addappid(1347431,0,"bfda7d558e3a0b47fc39152cf52af735b97213126d9449c716c86254e19e475f")
setManifestid(1347431,"8621134750851301767")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]