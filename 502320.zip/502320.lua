-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪username - f1uxin, on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy / https://discord.gg/m8PxjTwrnv
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(502320) -- Boulder Dash 30th Anniversary
-- MAIN APP DEPOTS
addappid(502321, 1, "6f203a9014c0a99701cb1751022f9187c2e384711a3b41b013b73e9cd7aec783") -- Boulder Dash 30th Anniversary Windows
setManifestid(502321, "5302888144647826028", 472942997)
addappid(502322, 1, "e2e4d6141dce9fb907339efadad4d67a8636c08345ff6c8a9fb936e0d722d89f") -- Boulder Dash 30th Anniversary OSX
setManifestid(502322, "2386633185602150404", 478477866)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- .NET 3.5 Redist (Shared from App 228980)
setManifestid(229000, "4622705914179893434", 242743889)
-- DLCS WITH DEDICATED DEPOTS
-- Boulder Dash Classic Remix World (AppID: 505450)
addappid(505450)
addappid(505450, 1, "ce00599e1c93bcb34f8747dd6610930d8d0e8c5761d474654275ef58173308c8") -- Boulder Dash Classic Remix World - Boulder Dash Classic World (505450) Depot
setManifestid(505450, "6214601459848402970", 10)
-- Boulder Dash The Bouldering Comp World (AppID: 505451)
addappid(505451)
addappid(505451, 1, "d0c4ef070e24f83c89f3f7ddb9c3d373f1c7987408dfae8b00a54dad400168ab") -- Boulder Dash The Bouldering Comp World - Boulder Dash Liepa World (505451) Depot
setManifestid(505451, "8726424573988707025", 10)