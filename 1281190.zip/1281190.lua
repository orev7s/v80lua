-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(1281190) -- The Shadow Government Simulator

-- MAIN APP DEPOTS
addappid(1281191, 1, "8e51426f41784c14ff9d66b56772235479ecc62da8eaaf469e1caacad4b235b8") -- Main Game Content (Windows Content)
setManifestid(1281191, "7323399554328813083", 0)

-- DLCS EXCLUDED (NO DEPOT KEYS, NO DEDICATED DEPOTS)
-- addappid(1691410) -- The Shadow Government Simulator Soundtrack (no keys available)
