addappid(1302800)
addappid(1302801,0,"49faf9189f206feeac4e224e8ee773bb3bd723ba57909739198da9530009f61b")
setManifestid(1302801,"4385378115089055763")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]