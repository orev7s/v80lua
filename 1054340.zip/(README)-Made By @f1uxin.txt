(It is fine to delete/not add this TXT file into steamtools/whatever you got this inside of).

This file was created by f1uxin, enjoy!

And you should really check out my server (https://discord.gg/NmmpgnAgen), we show all of this manifest and lua stuff and just in general everything about piracy.

The redistribution/sharing of these files are NOT allowed without permission, you can share it with a friend but you must not redistribute it and claim it is your own, i use my own money to get the game to make these, or my IRL friend will buy it and let me use it to help others, so people stealing them really upsets me if you do want to redistribute it you can add me on discord "@F1uxin" and we can talk about it.

Socials:

My Discord/Discord Server - User: @f1uxin | My Server : https://discord.gg/NmmpgnAgen

Discord Servers: Manifest Manager @ SushiTools https://discord.gg/sushitools / https://discord.gg/N46D8CTPZE 

Discord Servers: Server/Manifest Manager @ ZayTools https://discord.gg/zaytools / https://discord.gg/uAHmFw9AhP



Extra Notes:

I AM NOT F1uxin_sells or anything like that everything i show is free, i go by just @F1uxin, F1uxin, used to go by Raid3rV2, and i don't sell anything he may just be using my name or we have close usernames but that IS NOT ME.
