addappid(1643320)
addappid(1643321, 1, "71c29e58911c13991edea02ac06db5f5991e43e52cdcd76c19126d657c4a38e7")
setManifestid(1643321, "1457598843969339551", 0)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a")
setManifestid(229005, "7992454656023763365", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]