-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2777220)
addappid(2777221,0,"9cfab5cea698139b133db1decad53c94cbc9624098866aa9863da26855b6fa8e")
setManifestid(2777221,"5217341684736948911")