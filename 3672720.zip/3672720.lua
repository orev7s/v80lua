-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(3672720) -- Prison Escape Simulator: Dig Out
-- MAIN APP DEPOTS
addappid(3672722, 1, "9b3449633eddd535ba0aa2b2b242cbe7f1bbedf545cec40ef03704ea188b19f7") -- Depot 3672722
setManifestid(3672722, "1661909967745345173", 12666552848)