-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(294100, 1, "44498055cce67eea5d84c5b6bc1bd5ca9e8c988963aea857574277fc217cbad0") -- RimWorld
-- MAIN APP DEPOTS
addappid(294101, 1, "a5f3f4466343e7297b20a43dde9d6b6ed9d0d4230b74689caf5746d11de0367d") -- RimWorld (Windows)
setManifestid(294101, "5263998763028995761", 563022001)
addappid(294104, 1, "db7d2330e8748efe01ff1674580919b72e40879517e378b568533acc2863ec26") -- RimWorld (64-bit)
setManifestid(294104, "4087963488549526433", 573248177)
addappid(294102, 1, "dfa49a9452d912eb031ecd2111c1a9b1331bfe58000b9d68b8d5b646acbd1054") -- RimWorld (Mac)
setManifestid(294102, "868242595913649139", 596856345)
addappid(294103, 1, "a8218a15388519f5ded274def07d1dd1c535e1bfe646eb17463775bf47f63e39") -- RimWorld (Linux)
setManifestid(294103, "3619572650841734897", 573288812)
-- DLCS WITH DEDICATED DEPOTS
-- RimWorld - Royalty (AppID: 1149640)
addappid(1149640)
addappid(1149641, 1, "298db7a9d64ecbc820422e53907ab224611829745e8e4b20a4387efba317bee1") -- RimWorld - Royalty - RimWorld - Merrymaker (Windows)
setManifestid(1149641, "371231375604265157", 60589649)
addappid(1149644, 1, "fafd64b303cda2e9b938ce60e7af4653a574b035d59cccd31be1ff5c2dc8c0ee") -- RimWorld - Royalty - RimWorld - Merrymaker (64-bit)
setManifestid(1149644, "7278319673076312205", 60589649)
addappid(1149642, 1, "14ba0c9d972b57cf45870968dfd396baa35f94d87f117e91e64ba03d25d5d5ad") -- RimWorld - Royalty - RimWorld - Merrymaker (Mac)
setManifestid(1149642, "2456947268565486453", 60589647)
addappid(1149643, 1, "a2065b38cf6723c9cc336f68388389a7b437e4404a9856982d2594a928b49b23") -- RimWorld - Royalty - RimWorld - Merrymaker (Linux)
setManifestid(1149643, "6616312354659609389", 60589650)
-- RimWorld - Ideology (AppID: 1392840)
addappid(1392840)
addappid(294105, 1, "be81976289e837bb2cb5c9858b07b9f72612a69414697f44c5b138fb3041a250") -- RimWorld - Ideology - RimWorld - Kepler (Windows)
setManifestid(294105, "6531690518477186181", 56712520)
addappid(294106, 1, "d1a9518d7b68f46dc53981fe05514f6daa66a3aa125637c13c1535e8cdb8e4b6") -- RimWorld - Ideology - RimWorld - Kepler (64-bit)
setManifestid(294106, "6181157174775603492", 56712520)
addappid(294107, 1, "132106f7d7fd90e2cef97d5a01632ca943c2147afcd166c202d51865cf0786e6") -- RimWorld - Ideology - RimWorld - Kepler (Mac)
setManifestid(294107, "5036624352317407807", 56712518)
addappid(294108, 1, "80efa15b6a1330572a30a52fc0147fd7fecf36ea2e3acfa8d7db1d78f28c2144") -- RimWorld - Ideology - RimWorld - Kepler (Linux)
setManifestid(294108, "7975289273686953125", 56712519)
-- RimWorld - Biotech (AppID: 1826140)
addappid(1826140)
addappid(367683, 1, "eae351654f6795aae5320150c2801aa853cc2e46412b72bccca2fbf3f50af32a") -- RimWorld - Biotech - RimWorld - Euclid (Windows)
setManifestid(367683, "3988344691090891656", 68882160)
addappid(367684, 1, "699e092d84e16c90a62ebfcd68d1c568c4947ae94d538e999fe56e7cc6043942") -- RimWorld - Biotech - RimWorld - Euclid (64-bit)
setManifestid(367684, "3454471079388092441", 68882161)
addappid(367685, 1, "8a4f6b777fb54e2730c7ace0e4f85ddf4fc58ea3607ad94eb9cf01acb2571446") -- RimWorld - Biotech - RimWorld - Euclid (Mac)
setManifestid(367685, "9053524054644195578", 68882156)
addappid(367686, 1, "ddec61094ce592f6db40f3867b99e458ea4ce2af56cb8f62474631b33a96c734") -- RimWorld - Biotech - RimWorld - Euclid (Linux)
setManifestid(367686, "7063560391459304766", 68882161)
-- RimWorld - Anomaly (AppID: 2380740)
addappid(2380740)
addappid(294109, 1, "d670f6ba851c27bd62423853e8dd18d5e32b75393b65bf18914103a0b0db63e9") -- RimWorld - Anomaly - Depot 294109
setManifestid(294109, "7499410590982157116", 103719885)
addappid(294110, 1, "96eea289fb25789e7d7791bcf77e2af4d62eacaa1c05866991b72e75b805069c") -- RimWorld - Anomaly - Depot 294110
setManifestid(294110, "504370822467683738", 103719885)
addappid(294111, 1, "62487ea6d7f63684007a6713749fd8fb14c7955e885aa14cda8c5daa5d930f78") -- RimWorld - Anomaly - Depot 294111
setManifestid(294111, "3224782109777303216", 103719883)
addappid(294112, 1, "69dc90bdbb7c2c47b168606c5b8bde5ab1c6ec88404fa31bfb1faaf2d5c452c3") -- RimWorld - Anomaly - Depot 294112
setManifestid(294112, "1839622569916234121", 103719883)
-- RimWorld - Odyssey (AppID: 3022790)
addappid(3022790)
addappid(294113, 1, "3a667846a7e65282aae8275c6848ede3e0e48b3959c6045ebc0ceff98db49e0a") -- RimWorld - Odyssey - Depot 294113
setManifestid(294113, "3620633316715123478", 90382405)
addappid(294114, 1, "76f5a14f8283fd55fe1b8e0eca01a5408e01b23611e70c2cb92a7e303e835646") -- RimWorld - Odyssey - Depot 294114
setManifestid(294114, "3742326979606266224", 90382405)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(367680) -- RimWorld Name in Game Access
addappid(367681) -- RimWorld Backstory in Game Access
addappid(367682) -- RimWorld Pirate King Access