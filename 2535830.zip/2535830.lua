-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(2535830) -- Squirrel Stapler

-- MAIN APP DEPOTS
addappid(2535831, 1, "e84e32d735a12a291dd0612aab36e5a3eab6de0f0559ef47ebcf6c19feca58a4") -- Main Game Content (Windows Content)
setManifestid(2535831, "8704891717066138156", 0)
