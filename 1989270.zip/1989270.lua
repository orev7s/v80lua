-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪 on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy / https://discord.gg/m8PxjTwrnv
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(1989270) -- Slay the Princess — The Pristine Cut

-- MAIN APP DEPOTS
addappid(1989271, 1, "d28b035c178523e9824d85af2171fc42463e9e7b1c4e1845de83bc0e1e0d9a53") -- Main Game Content (Windows Content)
setManifestid(1989271, "6226378726358942197", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Slay the Princess - Supporters Pack (AppID: 2642210)
addappid(2642210)
addappid(1989273, 1, "17fc5b4ca7f5602fd795e28f59f2b1378f0733bbb7c75142d5cf72becee0b3d7") -- Slay the Princess - Supporters Pack - DLC Content
setManifestid(1989273, "3295542048348174230", 0)
