-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(1057580) -- Shopkeeper Simulator

-- MAIN APP DEPOTS
addappid(1057581, 1, "dfbd523da2b80719c9a5c0de76ceab3033dfbdcae123d82df6852ba73d551a9a") -- Depot 1057581
setManifestid(1057581, "4132446503549378762", 0)
