-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(2324150) -- Neuroshima Hex

-- MAIN APP DEPOTS
addappid(2324151, 1, "3cf60845882cfe04c21b3cb40e17d2351f1cca6a6eff0127531fc9db73c69d30") -- Depot 2324151
setManifestid(2324151, "2954651979570539370", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3587690) -- Neuroshima Hex Army - Neojungle
addappid(3587700) -- Neuroshima Hex Army - Uranopolis
addappid(3587710) -- Neuroshima Hex Army - Sharrash
