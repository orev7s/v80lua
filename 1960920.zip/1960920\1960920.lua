addappid(1960920)
addappid(1960921,0,"afd1e33b8ce98b26096ece7f3e2ff1016580da2365390a4f92b62509fb746f62")
setManifestid(1960921,"9110419762165931394")
addappid(1960922)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]