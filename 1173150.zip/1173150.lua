-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(1173150) -- Goosebumps Dead of Night

-- MAIN APP DEPOTS
addappid(1173151, 1, "2cf1491257d6f4906cdea5f06b615e203975e5685c2d882985a53f3c63dc2007") -- Goosebumps Dead of Night Content
setManifestid(1173151, "1498296457044259148", 0)
