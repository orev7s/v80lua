-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is "f1uxin" on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free!).

-- MAIN APPLICATION
addappid(320300) -- Car Mechanic Simulator 2015

-- MAIN APP DEPOTS
addappid(320301, 1, "98fdac23d05484143a04a5f07b7e527a2fc6bdb3a67fdad7bb3618c258881097") -- Car Mechanic Simulator 2015 Content
setManifestid(320301, "2920688111584517879", 0)
addappid(320302, 1, "f060b1696adfdb346ba2560f90ba8edbd44d77a97966ba45cefde74e428c8b48") -- Car Mechanic Simulator 2015 Windows Executable
setManifestid(320302, "2102677787052895245", 0)
addappid(320303, 1, "050b356a267ad27d3165e65a202ebd97aab78dc3c671e1ffd3a93d6c2e9c85cc") -- Car Mechanic Simulator 2015 Mac
setManifestid(320303, "4506958677448265872", 0)

-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(434900) -- Car Mechanic Simulator 2015 - Bentley
addappid(434901) -- Car Mechanic Simulator 2015 - Maserati
addappid(434910) -- Car Mechanic Simulator 2015 - Mercedes-Benz
addappid(507070) -- Car Mechanic Simulator 2015 - DeLorean
addappid(623150) -- Car Mechanic Simulator 2015 - Car Stripping

-- DLCS EXCLUDED (NO DEPOT KEYS, NO DEDICATED DEPOTS)
-- addappid(361820) -- Car Mechanic Simulator 2015 - Youngtimer (no keys available)
-- addappid(361840) -- Car Mechanic Simulator 2015 - Total Modifications (no keys available)
-- addappid(361841) -- Car Mechanic Simulator 2015 - PickUp  SUV DLC (no keys available)
-- addappid(361842) -- Car Mechanic Simulator 2015 - TraderPack (no keys available)
-- addappid(361843) -- Car Mechanic Simulator 2015 - Performance DLC (no keys available)
-- addappid(372870) -- Car Mechanic Simulator 2015 - Visual Tuning (no keys available)
