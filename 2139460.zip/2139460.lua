-- Made by f1uxin, please read the (README) file and enjoy!
-- P.S. If there is no README file, this file has most likely been stolen the creator of these files is @𓆩𝙁𝟙𝙪𝙭𝙞𝙣𓆪username - f1uxin, on discord, nobody else.
-- If you want to redistribute/share these files, read the README TXT for more info.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy / https://discord.gg/m8PxjTwrnv
-- (We show everything about piracy, including manifest & lua stuff also known as the "Steam method", all for free, Nobody should need to pay for info that is spread and shown for free.)

-- MAIN APPLICATION
addappid(2139460) -- Once Human

-- MAIN APP DEPOTS
addappid(2139461, 1, "78a785be75b7bf5ace231ff22287308bed5800f9afecb4b545a180f7f00b9c11") -- Depot 2139461
setManifestid(2139461, "1649607400486463342", 0)
addappid(2139463, 1, "ad7c624324a12728521ce39b4e13e9a9bd4df554bc77e25484ade5072f77615e") -- Depot 2139463
setManifestid(2139463, "1788602502784959358", 0)

-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "550968249685141759", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3379260) -- Once Human - Double Agent Theme Pack
addappid(3816110) -- Once Human - Ascend Daily Theme Pack
