-- Made By @F1uxin
-- MAIN APPLICATION
addappid(2062690) -- Tour de France 2023

-- MAIN APP DEPOTS
addappid(2062691, 1, "fd2133f8a536b37dd1cd13a68f9ece86f31f5c9ee4fa480af5d84ffb37e1007b") -- Main Game Content (Windows Content)
setManifestid(2062691, "3792795739310293683", 0)

-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "550968249685141759", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
setManifestid(229007, "4477590687906973371", 0)
