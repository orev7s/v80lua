-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(1853200) -- TYRONE vs COPS

-- MAIN APP DEPOTS
addappid(1853201, 1, "39a775fb16aa1add61ddb97c4fa9c07398c229b8758ddb8bc1dddef5940157ba") -- Main Game Content (Windows Content)
setManifestid(1853201, "5764403288141260257", 0)
addappid(1853202, 1, "2ac62fcace20bceeaac76b117518f206f57d91160812e48443ca48aaba20df75") -- Game Content (Linux Binaries)
setManifestid(1853202, "1945948982115388463", 0)

-- DLCS EXCLUDED (NO DEPOT KEYS, NO DEDICATED DEPOTS)
-- addappid(1874460) -- TYRONE vs COPS Golden Blicky (no keys available)
