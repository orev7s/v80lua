addappid(1640300)
addappid(1640301, 1, "0a4a648a90ec7381d779c624da1caf5b9fec4e69b48d0aae04af2a4011dafe29")
setManifestid(1640301, "5695755171632722669", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]