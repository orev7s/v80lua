addappid(1671480)
addappid(1671481,0,"671a737996ab5fae24142fb3ef2f91ce2c41926f43aeb6baf6899b434274f86b")
setManifestid(1671481,"2829148869055917374")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]