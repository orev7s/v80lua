addappid(1273440)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1273441,0,"8378f9c5f0915c3bad49814640ad793a9a9d6562e5609f3b4f5ae304e01f9b1d")
setManifestid(1273441,"1769411161583921312")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]