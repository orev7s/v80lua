addappid(1620340)
addappid(1620341,0,"95908f582152d4aca02b760eafea03c451e47277cfaaabddf0f1fc0c046cfb2c")
setManifestid(1620341,"4227367908492194295")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]