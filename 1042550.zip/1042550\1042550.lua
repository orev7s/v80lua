addappid(1042550)
addappid(228987)
setManifestid(228987,"4302102680580581867")
addappid(228990)
setManifestid(228990,"5087715316087945828")
addappid(1042551,0,"bd80c7bd28d5cacbe5cc2dfafa6a9464b0e7fd8e769b04750ed0892ce11a162e")
setManifestid(1042551,"1711281787115726840")
addappid(1042552,0,"96a03909c7aef73b6e510b6ac8b569f9792d7652e01175a5a374ee275deffda3")
setManifestid(1042552,"6775586209044059578")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]