addappid(1522160)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228989)
setManifestid(228989,"1332597174812030948")
addappid(228990)
setManifestid(228990,"5087715316087945828")
addappid(1522161,0,"30d26b038623eaef752b3ad6c9d1bc8e9bdf859f7f802d5ca54923011edc369c")
setManifestid(1522161,"4220722103960183356")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]