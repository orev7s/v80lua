addappid(1665460)
addappid(1665461,0,"2624d08cc505e348325f11d468d4d89bb07791230ce61d05cb1873d1ae84475d")
addappid(1665462,0,"6468be30e6c14cfb049f40a81b556205bba2e8cfd53daccaf3f4ac04486f2e6b")
setManifestid(1665461,"3823394928728015767")
setManifestid(1665462,"2034366343074945427")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]