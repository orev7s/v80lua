addappid(1574240)
addappid(1574241,0,"24198f4dd13fc1fa93fb7dafc67b633f9d41e7b8c13bcb20fccd46bce08f940f")
setManifestid(1574241,"5754642058671856477")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]