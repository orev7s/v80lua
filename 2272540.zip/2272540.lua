-- Made by f1uxin, please read the read me TXT file
addappid(2272540)
addappid(2272541,0,"a07aa761da92da0deb6a785fac179e2fc66fd3cb9b177051ff9b397b2b966ceb")
setManifestid(2272541,"1901379496018847101")
addappid(3625720)