addappid(13500)
addappid(13501,1,"1927562a78578b21ac7eb2a7ff202060c71870d222e56e4ff4a64eb19c153c85")
setManifestid(13501,"5941015487132604059",3475265993)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]