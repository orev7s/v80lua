-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is.
-- Feel free to join my(F1uxins) official server: https://discord.gg/planetofpiracy

-- MAIN APPLICATION
addappid(2973830) -- Prison Boss Prohibition

-- MAIN APP DEPOTS
addappid(2973831, 1, "121a06c3d642b69345f6880ee9ee860dabbbf2783bd9fef529f10b9b62bfca9a") -- Depot 2973831
setManifestid(2973831, "5199816533150056807", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3751870) -- Prison Boss Prohibition - Prisoner Pack

-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(3859360) -- Prison Boss Prohibition - Mafioso Pack (unreleased)
