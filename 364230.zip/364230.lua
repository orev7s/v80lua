-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(364230) -- Lucius Demake

-- MAIN APP DEPOTS
addappid(364231, 1, "9f33fe7881ffe399789448d49b8d85f2c180c5b8f6ad8caf32630e52470cbfe0") -- Lucius 2D Content
setManifestid(364231, "1830761351429048729", 0)
addappid(364232, 1, "fc2d6bb862275c000ea5b342fb8a10361e2cc7c9510943fdfc09ac07d33f9412") -- Lucius Demake Linux
setManifestid(364232, "6133644693028011487", 0)
