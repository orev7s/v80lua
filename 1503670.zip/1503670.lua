-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(1503670) -- The Caregiver | 終焉介護

-- MAIN APP DEPOTS
addappid(1503671, 1, "94879713ab4aa8c2d51d1f30ce362836adf09a6a95e27c178857d01c0acab3b4") -- Caregiver | 介護士 Content
setManifestid(1503671, "5158567679847214135", 0)
