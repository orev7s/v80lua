-- Made by f1uxin, please read the read me TXT file.
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(2559270) -- Gym Simulator 24

-- MAIN APP DEPOTS
addappid(2559271, 1, "252240bd9ce52dac4ab6e78c116ee82a8cec8e5542292df9e7a171a3fb638f38") -- Main Game Content (Windows Content)
setManifestid(2559271, "625163183945178012", 0)
