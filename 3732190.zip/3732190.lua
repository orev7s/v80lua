-- Made by f1uxin, please read the read me TXT file.
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship
addappid(3732190)
addappid(3732191, 1, "736c8ca12b2ea7547c93293dd11e3ba673ba3a49b5052787df317298a4058795") 
setManifestid(3732191, "8913964692630183469", 0)