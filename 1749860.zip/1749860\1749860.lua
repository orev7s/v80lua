addappid(1749860)
addappid(228989)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1749861,0,"be2a418138404d2f8797c9edbe07b9bbf450d569b5ce59649288a97a78e2178e")
setManifestid(1749861,"4763162003457972741")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]