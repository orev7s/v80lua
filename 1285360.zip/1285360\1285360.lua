addappid(1285360)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1285361,0,"b6058d1783532c314a08e4b93d80c02854abd2bb7ec95148c979cca0684f5ece")
setManifestid(1285361,"8008935226483102662")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]