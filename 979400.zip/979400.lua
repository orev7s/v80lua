-- Made by f1uxin, please read the read me TXT file.
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(979400) -- Last Labyrinth

-- MAIN APP DEPOTS
addappid(979401, 1, "8c596faf6c0d7f9ab81ac3ad31de4b6de19f8339fb6a0553db7e52a5cdf56a1f") -- LastLabyrinth Content
setManifestid(979401, "351070947613463524", 0)
