-- Made by f1uxin, enjoy!
-- Redistribution/sharing of these files is allowed but you must keep everything as is. 
-- Feel free to join my(F1uxins) official server: https://discord.gg/f1uxins-ship

-- MAIN APPLICATION
addappid(1267310) -- Onryo | 怨霊

-- MAIN APP DEPOTS
addappid(1267311, 1, "739dfa3a8ca9993cdc4465094ef3a78238555f53beacbc188da4046451562c35") -- Yurei | 幽霊 Content
setManifestid(1267311, "2743399765097214775", 0)

-- SHARED DEPOTS (from other apps)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- .NET 4.6 Redist (Shared from App 228980)
setManifestid(229005, "7992454656023763365", 0)
