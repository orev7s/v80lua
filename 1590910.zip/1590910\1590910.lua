addappid(1590910)
addappid(1590911, 1, "8e2ba27316a162742cd823bb6a93eca7ed9a19826e1adcb9e5efc4c882505347")
setManifestid(1590911, "2684201667121793780", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]